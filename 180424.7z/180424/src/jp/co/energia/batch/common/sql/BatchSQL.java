/**
 * BatchSQL.java
 * All Rights Reserved.Copyright�@2014,Energia�@Communications.Inc
 */
package jp.co.energia.batch.common.sql;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


/**
 * �o�b�`�����Ŏg�p����SQL���`����N���X�ł��B.
 * <p>
 * Ver.00.00.00 2017/12/28 : R.Hayashi - Original
 */
public final class BatchSQL {
	/** SQL�萔. */
	private static final Map<String, String> SQL_STR;
	/** �p�����[�^. */
	private static final Map<String, String[]> PARAM_ARR;

	static {
		Map<String, String> sqlMap = new HashMap<String, String>();
		Map<String, String[]> paramMap = new HashMap<String, String[]>();

		// FKSB001�p
		// FKSB001_INSERT_007
		sqlMap.put(
				"FKSB001_INSERT_007",
				" INSERT INTO W_SSN_NO_KAIKE_1 ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" PRJ_DEF, "
				+	" WBS_YOS, "
				+	" KAN_CD, "
				+	" SSN_CALSS, "
				+	" GENK_CTR_CD, "
				+	" SEKN_GENK_CTR_CD, "
				+	" FST_SHK_YM, "
				+	" SHK_KIN, "
				+	" FUTKIN, "
				+	" MKO_DATE, "
				+	" GENS_SONS_SUM_KIN, "
				+	" TOKI_EN_SHOKY_SUM_KIN, "
				+	" KAIKE_YND_STA_SHOKY_SUM_KIN, "
				+	" KEKA_SHOKY_KIN, "
				+	" KEKA_SHOKY_KIN_SEIF, "
				+	" ZENKI_EN_TRKZS_KIN, "
				+	" ZENKI_EN_TRKZS_KIN_SEIF "
				+ " ) VALUES ( "
				+    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ? , "
			    +    " ?,  "
			    +    " ?,  "
			    +    " ?,  "
			    +    " ?,  "
			    +    " ?  "
			    + " ) "
			    );
		paramMap.put(
				"FKSB001_INSERT_007",
				new String[] {"SSN_NO", "SSN_HJNO", "PRJ_DEF", "WBS_YOS", "KAN_CD", "SSN_CALSS", "GENK_CTR_CD", "SEKN_GENK_CTR_CD",
						"FST_SHK_YM", "SHK_KIN", "FUTKIN", "MKO_DATE", "GENS_SONS_SUM_KIN", "TOKI_EN_SHOKY_SUM_KIN", "KAIKE_YND_STA_SHOKY_SUM_KIN",
						"KEKA_SHOKY_KIN", "KEKA_SHOKY_KIN_SEIF", "ZENKI_EN_TRKZS_KIN", "ZENKI_EN_TRKZS_KIN_SEIF" }
				);
		// FKSB001_INSERT_001
		sqlMap.put(
				"FKSB001_INSERT_001",
				" INSERT INTO W_SSN_NO_KAIKE_2 ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" PRJ_DEF, "
				+	" WBS_YOS, "
				+	" KAN_CD, "
				+	" SSN_CALSS, "
				+	" GENK_CTR_CD, "
				+	" SEKN_GENK_CTR_CD, "
				+	" FST_SHK_YM, "
				+	" SHK_KIN, "
				+	" FUTKIN, "
				+	" MKO_DATE, "
				+	" GENS_SONS_SUM_KIN, "
				+	" TOKI_EN_SHOKY_SUM_KIN, "
				+	" KAIKE_YND_STA_SHOKY_SUM_KIN, "
				+	" KEKA_SHOKY_KIN, "
				+	" KEKA_SHOKY_KIN_SEIF, "
				+	" ZENKI_EN_TRKZS_KIN, "
				+	" ZENKI_EN_TRKZS_KIN_SEIF "
				+ " ) SELECT "
				+		" T01.SSN_NO, "
				+		" T01.SSN_HJNO, "
				+		" T01.PRJ_DEF, "
				+		" T01.WBS_YOS, "
				+		" T01.KAN_CD, "
				+		" T01.SSN_CALSS, "
				+		" T01.GENK_CTR_CD, "
				+		" T01.SEKN_GENK_CTR_CD, "
				+		" T01.FST_SHK_YM, "
				+		" T01.SHK_KIN, "
				+		" T01.FUTKIN, "
				+		" T01.MKO_DATE, "
				+		" T01.GENS_SONS_SUM_KIN, "
				+		" T01.TOKI_EN_SHOKY_SUM_KIN, "
				+		" T01.KAIKE_YND_STA_SHOKY_SUM_KIN, "
				+		" T01.KEKA_SHOKY_KIN, "
				+		" T01.KEKA_SHOKY_KIN_SEIF, "
				+		" T01.ZENKI_EN_TRKZS_KIN, "
				+		" T01.ZENKI_EN_TRKZS_KIN_SEIF "
				+	" FROM "
				+		" W_SSN_NO_KAIKE_1 T01 "
				+		" LEFT OUTER JOIN W_SSN_NO_KAIKE_2 T02 "
				+		" ON T01.SSN_NO = T02.SSN_NO "
				+		" AND T01.SSN_HJNO = T02.SSN_HJNO "
				+	" WHERE "
				+		" T02.SSN_NO IS NULL "
				);
		paramMap.put(
				"FKSB001_INSERT_001",
				new String[] {}
				);
		// FKSB001_INSERT_002
		sqlMap.put(
				"FKSB001_INSERT_002",
				" INSERT INTO W_SSN_1 ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" SSN_PRJ_DEF, "
				+	" SSN_WBS_YOS, "
				+	" SSN_KAN_CD, "
				+	" SSN_SSN_CALSS, "
				+	" SSN_GENK_CTR_CD, "
				+	" SSN__SEKN_GENK_CTR_CD, "
				+	" SSN_FST_SHK_YM, "
				+	" SSN_SHK_KIN, "
				+	" SSN_FUTKIN, "
				+	" SSN_MKO_DATE, "
				+	" SSN_RENKE_SHRI_DATE, "
				+	" SSN_GENS_SONS_SUM_KIN, "
				+	" SSN_CHOB_GENK_STTS_KBN, "
				+	" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+	" SSN_YND_STA_SHOKY_KIN, "
				+	" SSN_NOW_SHOKY_KIN "
				+ " ) SELECT "
				+		" SSN_NO, "
				+		" SSN_HJNO, "
				+		" SSN_PRJ_DEF, "
				+		" SSN_WBS_YOS, "
				+		" SSN_KAN_CD, "
				+		" SSN_SSN_CALSS, "
				+		" SSN_GENK_CTR_CD, "
				+		" SSN__SEKN_GENK_CTR_CD, "
				+		" SSN_FST_SHK_YM, "
				+		" SSN_SHK_KIN, "
				+		" SSN_FUTKIN, "
				+		" SSN_MKO_DATE, "
				+		" SSN_RENKE_SHRI_DATE, "
				+		" SSN_GENS_SONS_SUM_KIN, "
				+		" SSN_CHOB_GENK_STTS_KBN, "
				+		" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+		" SSN_YND_STA_SHOKY_KIN, "
				+		" SSN_NOW_SHOKY_KIN "
				+	" FROM "
				+		" R_SSN "
				+	" WHERE "
				+		" SSN_RENKE_SHRI_DATE <> ' ' OR "
				+		" SSN_FST_SHK_YM <> ' ' AND "
				+ 		" SSN_SHK_KIN = '0' OR "
				+		" SSN_CHOB_GENK_STTS_KBN IN ('1' , '2') OR "
				+ 		" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN = '1' "
				);
		paramMap.put(
				"FKSB001_INSERT_002",
				new String[] {}
				);
		// FKSB001_SELECT_001
		sqlMap.put(
				"FKSB001_SELECT_001",
				" SELECT "
				+	" T01.SSN_NO, "
				+	" T01.SSN_HJNO, "
				+	" LEFT(T01.PRJ_DEF,6) AS PRJ_DEF, "
				+	" T01.WBS_YOS, "
				+	" T01.KAN_CD, "
				+	" T01.SSN_CALSS, "
				+	" T01.GENK_CTR_CD, "
				+	" T01.SEKN_GENK_CTR_CD, "
				+	" T01.FST_SHK_YM, "
				+	" T01.SHK_KIN, "
				+	" T01.FUTKIN, "
				+	" T01.MKO_DATE, "
				+	" T01.GENS_SONS_SUM_KIN, "
				+	" T01.KAIKE_YND_STA_SHOKY_SUM_KIN, "
				+	" T01.KEKA_SHOKY_KIN, "
				+	" T01.KEKA_SHOKY_KIN_SEIF, "
				+	" T01.ZENKI_EN_TRKZS_KIN, "
				+	" T01.ZENKI_EN_TRKZS_KIN_SEIF "
				+ " FROM "
				+	" W_SSN_NO_KAIKE_2 T01 "
				+ " WHERE NOT EXISTS( "
				+	" SELECT * "
				+	 " FROM W_SSN_1 T02 "
				+	 " WHERE "
				+		" T01.SSN_NO = T02.SSN_NO "
				+		" AND T01.SSN_HJNO = T02.SSN_HJNO "
				+  " ) "
				);
		paramMap.put(
				"FKSB001_SELECT_001",
				new String[] {}
				);
		// FKSB001_INSERT_003
		sqlMap.put(
				"FKSB001_INSERT_003",
				" INSERT INTO W_SSN_2 ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" SSN_PRJ_DEF, "
				+	" SSN_WBS_YOS, "
				+	" SSN_KAN_CD, "
				+	" SSN_SSN_CALSS, "
				+	" SSN_GENK_CTR_CD, "
				+	" SSN__SEKN_GENK_CTR_CD, "
				+	" SSN_FST_SHK_YM, "
				+	" SSN_SHK_KIN, "
				+	" SSN_FUTKIN, "
				+	" SSN_MKO_DATE, "
				+	" SSN_RENKE_SHRI_DATE, "
				+	" SSN_GENS_SONS_SUM_KIN, "
				+	" SSN_CHOB_GENK_STTS_KBN, "
				+	" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+	" SSN_YND_STA_SHOKY_KIN, "
				+	" SSN_NOW_SHOKY_KIN "
				+ " ) VALUES ( "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ' ', "
				+	" ?, "
				+	" '0', "
				+	" '0', "
				+	" ?, "
				+	" ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB001_INSERT_003",
				new String[] {"SSN_NO", "SSN_HJNO", "SSN_PRJ_DEF", "SSN_WBS_YOS", "SSN_KAN_CD", "SSN_SSN_CALSS", "SSN_GENK_CTR_CD", "SSN__SEKN_GENK_CTR_CD",
						"SSN_FST_SHK_YM", "SSN_SHK_KIN", "SSN_FUTKIN", "SSN_MKO_DATE", "SSN_GENS_SONS_SUM_KIN", "SSN_YND_STA_SHOKY_KIN", "SSN_NOW_SHOKY_KIN" }
				);
		// FKSB001_SELECT_002
		sqlMap.put(
				"FKSB001_SELECT_002",
				" SELECT "
				+	" T01.SSN_NO, "
				+	" T01.SSN_HJNO, "
				+	" LEFT(T01.PRJ_DEF,6) AS PRJ_DEF, "
				+	" T01.WBS_YOS, "
				+	" T01.KAN_CD, "
				+	" T01.SSN_CALSS, "
				+	" T01.GENK_CTR_CD, "
				+	" T01.SEKN_GENK_CTR_CD, "
				+	" (CASE WHEN "
				+		" T01.SHK_KIN = '0' "
				+		" AND T01.MKO_DATE = ' ' "
				+		" AND T02.SSN_FST_SHK_YM <> ' ' "
				+		" THEN "
				+			" T02.SSN_FST_SHK_YM "
				+		" ELSE "
				+			" T01.FST_SHK_YM "
				+	" END) AS FST_SHK_YM , "
				+	" T01.SHK_KIN, "
				+	" T01.FUTKIN, "
				+	" T01.MKO_DATE, "
				+	" T01.GENS_SONS_SUM_KIN, "
				+	" T01.KAIKE_YND_STA_SHOKY_SUM_KIN, "
				+	" T01.KEKA_SHOKY_KIN, "
				+	" T01.KEKA_SHOKY_KIN_SEIF, "
				+	" T01.ZENKI_EN_TRKZS_KIN, "
				+	" T01.ZENKI_EN_TRKZS_KIN_SEIF, "
				+	" (CASE WHEN "
				+		" T01.SHK_KIN = '0' "
				+		" AND T01.MKO_DATE = ' ' "
				+		" AND T02.SSN_RENKE_SHRI_DATE <> ' ' "
				+		" THEN "
				+			" T02.SSN_RENKE_SHRI_DATE "
				+		" ELSE "
				+			" ' ' "
				+	" END) AS RENKE_SHRI_DATE, "
				+	" (CASE WHEN "
				+		" T02.SSN_CHOB_GENK_STTS_KBN IN ('1' , '2') "
				+		" THEN "
				+			" T02.SSN_CHOB_GENK_STTS_KBN "
				+		" ELSE "
				+			" '0' "
				+	" END) AS CHOB_GENK_STTS_KBN, "
				+	" (CASE WHEN "
				+		" T02.SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN = '1' "
				+		" THEN "
				+			" T02.SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN "
				+		" ELSE "
				+			" '0' "
				+	" END) AS FUTKIN_GENS_CECJ_SHOKY_ANB_KBN "
				+ " FROM "
				+	" W_SSN_NO_KAIKE_2 T01 "
				+	" INNER JOIN "
				+	" W_SSN_1 T02 "
				+	" ON T01.SSN_NO = T02.SSN_NO "
				+	" AND T01.SSN_HJNO = T02.SSN_HJNO "
				);
		paramMap.put(
				"FKSB001_SELECT_002",
				new String[] {}
				);
		// FKSB001_INSERT_004
		sqlMap.put(
				"FKSB001_INSERT_004",
				" INSERT INTO W_SSN_2 ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" SSN_PRJ_DEF, "
				+	" SSN_WBS_YOS, "
				+	" SSN_KAN_CD, "
				+	" SSN_SSN_CALSS, "
				+	" SSN_GENK_CTR_CD, "
				+	" SSN__SEKN_GENK_CTR_CD, "
				+	" SSN_FST_SHK_YM, "
				+	" SSN_SHK_KIN, "
				+	" SSN_FUTKIN, "
				+	" SSN_MKO_DATE, "
				+	" SSN_RENKE_SHRI_DATE, "
				+	" SSN_GENS_SONS_SUM_KIN, "
				+	" SSN_CHOB_GENK_STTS_KBN, "
				+	" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+	" SSN_YND_STA_SHOKY_KIN, "
				+	" SSN_NOW_SHOKY_KIN "
				+ " ) VALUES ( "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ?, "
				+	" ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB001_INSERT_004",
				new String[] {"SSN_NO", "SSN_HJNO", "SSN_PRJ_DEF", "SSN_WBS_YOS", "SSN_KAN_CD", "SSN_SSN_CALSS", "SSN_GENK_CTR_CD", "SSN__SEKN_GENK_CTR_CD",
						"SSN_FST_SHK_YM", "SSN_SHK_KIN", "SSN_FUTKIN", "SSN_MKO_DATE", "SSN_RENKE_SHRI_DATE", "SSN_GENS_SONS_SUM_KIN", "SSN_CHOB_GENK_STTS_KBN",
						"SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN", "SSN_YND_STA_SHOKY_KIN", "SSN_NOW_SHOKY_KIN" }
				);
		// FKSB001_DELETE_001
		sqlMap.put(
				"FKSB001_DELETE_001",
				" DELETE FROM "
				+	" R_SSN_ZEND "
				);
		paramMap.put(
				"FKSB001_DELETE_001",
				new String[] {}
				);
		// FKSB001_INSERT_005
		sqlMap.put(
				"FKSB001_INSERT_005",
				" INSERT INTO R_SSN_ZEND ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" SSN_PRJ_DEF, "
				+	" SSN_WBS_YOS, "
				+	" SSN_KAN_CD, "
				+	" SSN_SSN_CALSS, "
				+	" SSN_GENK_CTR_CD, "
				+	" SSN__SEKN_GENK_CTR_CD, "
				+	" SSN_FST_SHK_YM, "
				+	" SSN_SHK_KIN, "
				+	" SSN_FUTKIN, "
				+	" SSN_MKO_DATE, "
				+	" SSN_RENKE_SHRI_DATE, "
				+	" SSN_GENS_SONS_SUM_KIN, "
				+	" SSN_CHOB_GENK_STTS_KBN, "
				+	" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+	" SSN_YND_STA_SHOKY_KIN, "
				+	" SSN_NOW_SHOKY_KIN, "
				+	" UPD_USR, "
				+	" UPD_DATE "
				+ " ) SELECT "
				+		" SSN_NO, "
				+		" SSN_HJNO, "
				+		" SSN_PRJ_DEF, "
				+		" SSN_WBS_YOS, "
				+		" SSN_KAN_CD, "
				+		" SSN_SSN_CALSS, "
				+		" SSN_GENK_CTR_CD, "
				+		" SSN__SEKN_GENK_CTR_CD, "
				+		" SSN_FST_SHK_YM, "
				+		" SSN_SHK_KIN, "
				+		" SSN_FUTKIN, "
				+		" SSN_MKO_DATE, "
				+		" SSN_RENKE_SHRI_DATE, "
				+		" SSN_GENS_SONS_SUM_KIN, "
				+		" SSN_CHOB_GENK_STTS_KBN, "
				+		" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+		" SSN_YND_STA_SHOKY_KIN, "
				+		" SSN_NOW_SHOKY_KIN, "
				+		" ?, "
				+		" ? "
				+	" FROM "
				+		" R_SSN "
				);
		paramMap.put(
				"FKSB001_INSERT_005",
				new String[] {"UPD_USR", "UPD_DATE"}
				);
		// FKSB001_INSERT_005_CNT
		sqlMap.put(
				"FKSB001_INSERT_005_CNT",
				" SELECT COUNT(*) AS COUNT "
				+	" FROM R_SSN "
				);
		paramMap.put(
				"FKSB001_INSERT_005_CNT",
				new String[] {}
				);
		// FKSB001_DELETE_002
		sqlMap.put(
				"FKSB001_DELETE_002",
				" DELETE FROM "
				+	" R_SSN "
				);
		paramMap.put(
				"FKSB001_DELETE_002",
				new String[] {}
				);
		// FKSB001_INSERT_006
		sqlMap.put(
				"FKSB001_INSERT_006",
				" INSERT INTO R_SSN ( "
				+	" SSN_NO, "
				+	" SSN_HJNO, "
				+	" SSN_PRJ_DEF, "
				+	" SSN_WBS_YOS, "
				+	" SSN_KAN_CD, "
				+	" SSN_SSN_CALSS, "
				+	" SSN_GENK_CTR_CD, "
				+	" SSN__SEKN_GENK_CTR_CD, "
				+	" SSN_FST_SHK_YM, "
				+	" SSN_SHK_KIN, "
				+	" SSN_FUTKIN, "
				+	" SSN_MKO_DATE, "
				+	" SSN_RENKE_SHRI_DATE, "
				+	" SSN_GENS_SONS_SUM_KIN, "
				+	" SSN_CHOB_GENK_STTS_KBN, "
				+	" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+	" SSN_YND_STA_SHOKY_KIN, "
				+	" SSN_NOW_SHOKY_KIN, "
				+	" UPD_USR, "
				+	" UPD_DATE "
				+ " ) SELECT "
				+		" SSN_NO, "
				+		" SSN_HJNO, "
				+		" SSN_PRJ_DEF, "
				+		" SSN_WBS_YOS, "
				+		" SSN_KAN_CD, "
				+		" SSN_SSN_CALSS, "
				+		" SSN_GENK_CTR_CD, "
				+		" SSN__SEKN_GENK_CTR_CD, "
				+		" SSN_FST_SHK_YM, "
				+		" SSN_SHK_KIN, "
				+		" SSN_FUTKIN, "
				+		" SSN_MKO_DATE, "
				+		" SSN_RENKE_SHRI_DATE, "
				+		" SSN_GENS_SONS_SUM_KIN, "
				+		" SSN_CHOB_GENK_STTS_KBN, "
				+		" SSN_FUTKIN_GENS_CECJ_SHOKY_ANB_KBN, "
				+		" SSN_YND_STA_SHOKY_KIN, "
				+		" SSN_NOW_SHOKY_KIN, "
				+		" ?, "
				+		" ? "
				+	" FROM "
				+		" W_SSN_2 "
				);
		paramMap.put(
				"FKSB001_INSERT_006",
				new String[] {"UPD_USR", "UPD_DATE"}
				);
		// FKSB001_INSERT_006_CNT
		sqlMap.put(
				"FKSB001_INSERT_006_CNT",
				" SELECT COUNT(*) AS COUNT "
				+	" FROM W_SSN_2 "
				);
		paramMap.put(
				"FKSB001_INSERT_006_CNT",
				new String[] {}
				);

		// FKSR002_SELECT_001 SQL
		sqlMap.put(
				"FKSR002_SELECT_001",
				  "SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "DAI_KKSH_NAME, "
			    +    "JUT_KKSH_NAME, "
			    +    "NOTE_MSG, "
			    +    "NOW_DATE, "
			    +    "KYK_NO, "
			    +    "SSN_NO, "
			    +    "GENK_CTR_NAME, "
			    +    "KMK_CD, "
			    +    "KNRI_SBT_NAME, "
			    +    "KYOG_TNK_CMK_KBN_NAME, "
			    +    "WBS_YOS, "
			    +    "WBS_NAME, "
			    +    "KYKS_KBN_NAME, "
			    +    "KAN_CD, "
			    +    "KAN_NAME, "
			    +    "JOSSK_Z_KBN_NAME, "
			    +    "KKT_CD, "
			    +    "KKT_NAME, "
			    +    "TOK_KBN_NAME, "
			    +    "RIT_KIT_NO, "
			    +    "RIT_KIT_DATE, "
			    +    "YOT_CD, "
			    +    "SHKT_SUM_MES, "
			    +    "DNC_KYK_SU, "
			    +    "NXT_KATE_DATE, "
			    +    "KYK_DATE, "
			    +    "AUTO_UPD_SKI, "
			    +    "KYK_KKN_ST, "
			    +    "KYK_KKN_EN, "
			    +    "SHR_SKI_KBN_NAME, "
			    +    "SHR_SBT_NAME, "
			    +    "SHR_KANJ_KMK_CD, "
			    +    "SEK_HIY_HSE_KSH_NAME, "
			    +    "SKK_SBT_NAME, "
			    +    "SKK, "
			    +    "SKK_SHR_KMK, "
			    +    "REK_CTR_NAME, "
			    +    "YKIN_SBT, "
			    +    "KOZ_NO, "
			    +    "FURI_KYKKN, "
			    +    "KOZ_MEGNIN, "
			    +    "KAIKE_KICHO_DATE, "
			    +    "KYYU_MCBN_BUNS, "
			    +    "KYYU_MCBN_BUIB, "
			    +    "KYKSH_ADD_YUB_NO_UP_3, "
			    +    "KYKSH_ADD_YUB_NO_DWN_4, "
			    +    "KYKSH_TDFK_NAME, "
			    +    "KYKSH_OOA_TSH_NAME, "
			    +    "KYKSH_ACM, "
			    +    "KYKSH_CBN, "
			    +    "KYKSH_NAME, "
			    +    "KYKSH_TEL_NO, "
			    +    "CHOB_GENK_ZAN_KIN, "
			    +    "FUTKIN, "
			    +    "GENS_SONS_SUM_KIN_UMU_FLG, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR002WK AS TKSR002WK_1 "
			    + "ORDER BY "
			    +    "TKSR002WK_1.CHOHY_RNO ASC  "
				);
		paramMap.put(
				"FKSR002_SELECT_001",
				new String[] {}
				);

		// FKSR002_SELECT_002 SQL
		sqlMap.put(
				"FKSR002_SELECT_002",
				     "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_1_RNO, "
			    +    "HIN_NAME, "
			    +    "SHR_KANJ_KMK_CD, "
			    +    "HMK_WBS_YOS, "
			    +    "HMK_WBS_NAME, "
			    +    "PAY_PRC, "
			    +    "BU_KBN, "
			    +    "BU_KBN_NAME, "
			    +    "ZEI_KBN_NAME "
			    + "FROM  "
			    +    "TKSR002WK2 AS TKSR002WK2_1 "
			    + "WHERE "
			    +    "TKSR002WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR002WK2_1.CHOHY_RNO ASC , "
			    +    "TKSR002WK2_1.CHOHY_DTL_1_RNO ASC  "
				);
		paramMap.put(
				"FKSR002_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR002_SELECT_003 SQL
		sqlMap.put(
				"FKSR002_SELECT_003",
				 "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_2_RNO, "
			    +    "BKN_NO, "
			    +    "TET_NO_NO, "
			    +    "TDFK_NAME, "
			    +    "OOA_TSH_NAME, "
			    +    "ACM, "
			    +    "BKN_CBN, "
			    +    "SENR_NAME, "
			    +    "DNC_SBT_NAME, "
			    +    "SHKT_HAI_KBN_NAME, "
			    +    "CMK_KOB_KBN_NAME, "
			    +    "CMK_GEK_KBN_NAME, "
			    +    "TCH_KIN, "
			    +    "HSH_TKA, "
			    +    "MES_KOB, "
			    +    "STE_MES "
			    + "FROM  "
			    +    "TKSR002WK3 AS TKSR002WK3_1 "
			    + "WHERE "
			    +    "TKSR002WK3_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR002WK3_1.CHOHY_RNO ASC , "
			    +    "TKSR002WK3_1.CHOHY_DTL_2_RNO ASC  "
				);
		paramMap.put(
				"FKSR002_SELECT_003",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR002_SELECT_004 SQL
		sqlMap.put(
				"FKSR002_SELECT_004",
				 "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_3_RNO, "
			    +    "KRUK_IDO_SBT, "
			    +    "IDO_DATE, "
			    +    "IDO_KKTS_NO, "
			    +    "IDO_KIT_DATE "
			    + "FROM  "
			    +    "TKSR002WK4 AS TKSR002WK4_1 "
			    + "WHERE "
			    +    "TKSR002WK4_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR002WK4_1.CHOHY_RNO ASC , "
			    +    "TKSR002WK4_1.CHOHY_DTL_3_RNO ASC "
				);
		paramMap.put(
				"FKSR002_SELECT_004",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR002_SELECT_005 SQL
		sqlMap.put(
				"FKSR002_SELECT_005",
			    "SELECT "
	    	    +    "CHOHY_RNO, "
	    	    +    "CHOHY_DTL_4_RNO, "
	    	    +    "IDO_DATE, "
	    	    +    "BKO "
	    	    + "FROM  "
	    	    +    "TKSR002WK5 AS TKSR002WK5_1 "
	    	    + "WHERE "
	    	    +    "TKSR002WK5_1.CHOHY_RNO = ? "
	    	    + "ORDER BY "
	    	    +    "TKSR002WK5_1.CHOHY_RNO ASC , "
	    	    +    "TKSR002WK5_1.CHOHY_DTL_4_RNO ASC "
				);
		paramMap.put(
				"FKSR002_SELECT_005",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSB007_DELETE_001
		sqlMap.put(
				"FKSB007_DELETE_001",
				" DELETE FROM W_KTEREN_FURIS "
				+ " WHERE SSN_NO = ? "
				+ " AND SSN_HJNO = ? "
				);
		paramMap.put(
				"FKSB007_DELETE_001",
				new String[] {"SSN_NO_W01", "SSN_HJNO_W01"}
				);

		// FKSB007_DELETE_002
		sqlMap.put(
				"FKSB007_DELETE_002",
				" DELETE FROM R_KTEREN_SHJ "
				+ " WHERE KTEREN_DEL_KBN = '1' "
				+ " AND KTEREN_SHJ_KBN = '1' "
				);
		paramMap.put(
				"FKSB007_DELETE_002",
				new String[] {}
				);

		// FKSB007_SELECT_001
		sqlMap.put(
				"FKSB007_SELECT_001",
				" SELECT "
				+ 	" T01.SSN_SHK_KIN, "
				+ 	" T01.SSN_MKO_DATE, "
				+ 	" T02.KTEREN_SSN_NO, "
				+ 	" T02.KTEREN_WBS_YOS, "
				+ 	" T02.KTEREN_SSN_HJNO, "
				+ 	" T02.HAKK_KSH, "
				+ 	" T02.KTEREN_CMPY_CD, "
				+ 	" T02.KTEREN_CHAK_YOT_DATE, "
				+ 	" T02.KTEREN_KDO_TES_YOT_DATE, "
				+	" LEFT(T02.KTEREN_WBS_YOS,6) AS PRJ_DEF, "
				+ 	" T02.GENK "
				+ " FROM "
				+ 	" (SELECT "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_WBS_YOS, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" CASE "
				+ 			" WHEN KTEREN_GNB_KKSH_CD = '7011331' THEN '7011330' "
				+ 			" ELSE KTEREN_GNB_KKSH_CD "
				+ 		" END AS HAKK_KSH, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_KDO_TES_YOT_DATE, "
				+ 		" SUM (KTEREN_KIN) AS GENK "
				+ 	" FROM "
				+ 		" R_KTEREN_SHJ "
				+ 	" WHERE "
				+ 		" KTEREN_GYOM_KBN = '2' "
				+ 	" AND "
				+ 		" KTEREN_DEL_KBN = '0' "
				+ 	" AND "
				+ 		" KTEREN_SHJ_KBN = '1' "
				+ 	" GROUP BY "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_WBS_YOS, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_KDO_TES_YOT_DATE, "
				+ 		" KTEREN_GNB_KKSH_CD, "
				+ 		" KTEREN_CMPY_CD "
				+ 	" ) T02 "
				+ 	" LEFT OUTER JOIN R_SSN T01 "
				+ 	" ON T01.SSN_NO = T02.KTEREN_SSN_NO "
				+ 	" AND T01.SSN_HJNO = T02.KTEREN_SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_SELECT_001",
				new String[] {}
				);

		// FKSB007_SELECT_002
		sqlMap.put(
				"FKSB007_SELECT_002",
				" SELECT "
				+ 	" T04.SSN_SHK_KIN, "
				+ 	" T04.SSN_MKO_DATE, "
				+ 	" T03.KTEREN_SSN_NO, "
				+ 	" T03.KTEREN_WBS_YOS, "
				+ 	" T03.KTEREN_SSN_HJNO, "
				+ 	" T03.HAKK_KSH, "
				+ 	" T03.KTEREN_CMPY_CD, "
				+ 	" T03.KTEREN_CHAK_YOT_DATE, "
				+ 	" T03.KTEREN_KDO_TES_YOT_DATE, "
				+ 	" T03.KTEREN_TRHK_TYP_SBT, "
				+ 	" T03.GENK, "
				+	" LEFT(T03.KTEREN_WBS_YOS,6) AS PRJ_DEF, "
				+ 	" T03.KTEREN_JOT_KIN "
				+ " FROM "
				+ 	" (SELECT "
				+ 		" T01.KTEREN_SSN_NO, "
				+ 		" T01.KTEREN_WBS_YOS, "
				+ 		" T01.KTEREN_SSN_HJNO, "
				+ 		" T01.HAKK_KSH, "
				+ 		" T01.KTEREN_CMPY_CD, "
				+ 		" T01.KTEREN_CHAK_YOT_DATE, "
				+ 		" T01.KTEREN_KDO_TES_YOT_DATE, "
				+ 		" T01.KTEREN_TRHK_TYP_SBT, "
				+ 		" T01.GENK, "
				+ 		" T02.KTEREN_JOT_KIN "
				+ 	" FROM "
				+ 		" (SELECT "
				+ 			" KTEREN_SSN_NO, "
				+ 			" KTEREN_WBS_YOS, "
				+ 			" KTEREN_SSN_HJNO, "
				+ 			" CASE "
				+ 				" WHEN KTEREN_GNB_KKSH_CD = '7011331' THEN '7011330' "
				+ 				" ELSE KTEREN_GNB_KKSH_CD "
				+ 			" END AS HAKK_KSH, "
				+ 			" KTEREN_CMPY_CD, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_KDO_TES_YOT_DATE, "
				+ 			" KTEREN_TRHK_TYP_SBT, "
				+ 			" SUM (KTEREN_KIN) AS GENK "
				+ 		" FROM "
				+ 			" R_KTEREN_SHJ "
				+ 		" WHERE "
				+ 			" KTEREN_GYOM_KBN = '3' "
				+ 		" AND "
				+ 			" KTEREN_DEL_KBN = '0' "
				+ 		" AND "
				+ 			" KTEREN_SHJ_KBN = '1' "
				+ 		" GROUP BY "
				+ 			" KTEREN_SSN_NO, "
				+ 			" KTEREN_SSN_HJNO, "
				+ 			" KTEREN_WBS_YOS, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_KDO_TES_YOT_DATE, "
				+ 			" KTEREN_GNB_KKSH_CD, "
				+ 			" KTEREN_TRHK_TYP_SBT, "
				+ 			" KTEREN_CMPY_CD "
				+ 		" ) T01 "
				+ 		" INNER JOIN "
				+ 		" (SELECT "
				+ 			" KTEREN_WBS_YOS, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_KDO_TES_YOT_DATE, "
				+ 			" KTEREN_TRHK_TYP_SBT, "
				+ 			" SUM (KTEREN_JOT_KIN) AS KTEREN_JOT_KIN "
				+ 		" FROM "
				+ 			" R_KTEREN_SHJ "
				+ 		" WHERE "
				+ 			" KTEREN_GYOM_KBN = '3' "
				+ 		" AND "
				+ 			" KTEREN_DEL_KBN = '0' "
				+ 		" AND "
				+ 			" KTEREN_SHJ_KBN = '1' "
				+ 		" GROUP BY "
				+ 			" KTEREN_WBS_YOS, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_KDO_TES_YOT_DATE, "
				+ 			" KTEREN_TRHK_TYP_SBT "
				+ 		" ) T02 "
				+ 		" ON T01.KTEREN_WBS_YOS = T02.KTEREN_WBS_YOS "
				+ 		" AND T01.KTEREN_CHAK_YOT_DATE = T02.KTEREN_CHAK_YOT_DATE "
				+ 		" AND T01.KTEREN_KDO_TES_YOT_DATE = T02.KTEREN_KDO_TES_YOT_DATE "
				+ 		" AND T01.KTEREN_TRHK_TYP_SBT = T02.KTEREN_TRHK_TYP_SBT "
				+ 	" ) T03 "
				+ 	" LEFT OUTER JOIN R_SSN T04 "
				+ 	" ON T03.KTEREN_SSN_NO = T04.SSN_NO "
				+ 	" AND T03.KTEREN_SSN_HJNO = T04.SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_SELECT_002",
				new String[] {}
				);

		// FKSB007_SELECT_003
		sqlMap.put(
				"FKSB007_SELECT_003",
				" SELECT "
				+ 	" T01.SSN_SHK_KIN, "
				+ 	" T01.SSN_FUTKIN, "
				+ 	" T01.SSN_MKO_DATE, "
				+ 	" T02.KTEREN_SSN_NO, "
				+ 	" T02.KTEREN_SSN_HJNO, "
				+ 	" T02.KTEREN_FURI_KENME, "
				+ 	" T02.KTEREN_FURIS_SSN_NO, "
				+ 	" T02.KTEREN_FURIS_SSN_HJNO, "
				+ 	" T02.HAKK_KSH, "
				+ 	" T02.KTEREN_CMPY_CD, "
				+ 	" T02.KTEREN_CHAK_YOT_DATE, "
				+ 	" T02.KTEREN_KDO_TES_YOT_DATE, "
				+ 	" T02.GENK "
				+ " FROM "
				+ 	" (SELECT "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" CASE "
				+ 			" WHEN KTEREN_GNB_KKSH_CD = '7011331' THEN '7011330' "
				+ 			" ELSE KTEREN_GNB_KKSH_CD "
				+ 		" END AS HAKK_KSH, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_KDO_TES_YOT_DATE, "
				+ 		" SUM (KTEREN_KIN) AS GENK "
				+ 	" FROM "
				+ 		" R_KTEREN_SHJ "
				+ 	" WHERE "
				+ 		" KTEREN_GYOM_KBN = '5' "
				+ 	" AND "
				+ 		" KTEREN_DEL_KBN = '0' "
				+ 	" AND "
				+ 		" KTEREN_SHJ_KBN = '1' "
				+ 	" GROUP BY "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_GNB_KKSH_CD, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_KDO_TES_YOT_DATE "
				+ 	" ) T02	 "
				+ 	" LEFT OUTER JOIN R_SSN T01 "
				+ 	" ON T01.SSN_NO = T02.KTEREN_SSN_NO "
				+ 	" AND T01.SSN_HJNO = T02.KTEREN_SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_SELECT_003",
				new String[] {}
				);

		// FKSB007_SELECT_004
		sqlMap.put(
				"FKSB007_SELECT_004",
				" SELECT "
				+ 	" T01.FURIS_SSN_NO "
				+ " FROM "
				+ 	" W_KTEREN_ERR_FURIS_1 T01 "
				+ 	" LEFT OUTER JOIN "
				+ 	" (SELECT "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" KTEREN_HAKK_KSH, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_KDO_TES_YOT_DATE, "
				+ 		" SUM (KTEREN_JOT_KIN) AS JOT_KIN, "
				+ 		" SUM (KTEREN_KIN) AS GENK "
				+ 	" FROM "
				+ 		" R_KTEREN_SHJ "
				+ 	" WHERE "
				+ 		" KTEREN_GYOM_KBN = '4' "
				+ 	" AND "
				+ 		" KTEREN_DEL_KBN = '0' "
				+ 	" AND "
				+ 		" KTEREN_SHJ_KBN = '1' "
				+ 	" GROUP BY "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_HAKK_KSH, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_KDO_TES_YOT_DATE "
				+ 	" ) T02	 "
				+ 	" ON T01.SSN_NO = T02.KTEREN_SSN_NO "
				+ 	" AND T01.SSN_HJNO = T02.KTEREN_SSN_HJNO "
				+ " WHERE "
				+ 	" T02.KTEREN_FURIS_SSN_NO IS NULL "
				);
		paramMap.put(
				"FKSB007_SELECT_004",
				new String[] {}
				);

		// FKSB007_SELECT_005
		sqlMap.put(
				"FKSB007_SELECT_005",
				" SELECT "
				+ 	" T01.SSN_SHK_KIN, "
				+ 	" T01.SSN_MKO_DATE, "
				+ 	" T02.KTEREN_SSN_NO, "
				+ 	" T02.KTEREN_SSN_HJNO, "
				+ 	" T02.KTEREN_FURI_KENME, "
				+ 	" T02.KTEREN_FURIS_SSN_NO, "
				+ 	" T02.KTEREN_FURIS_SSN_HJNO, "
				+ 	" T02.HAKK_KSH, "
				+ 	" T02.KTEREN_CMPY_CD, "
				+ 	" T02.KTEREN_CHAK_YOT_DATE, "
				+ 	" T02.KTEREN_KDO_TES_YOT_DATE, "
				+ 	" T02.KTEREN_JOT_KIN, "
				+ 	" T02.GENK, "
				+ 	" T02.ERR_INF "
				+ " FROM "
				+ 	" (SELECT "
				+ 		" T03.KTEREN_SSN_NO, "
				+ 		" T03.KTEREN_SSN_HJNO, "
				+ 		" T03.KTEREN_FURI_KENME, "
				+ 		" T03.KTEREN_FURIS_SSN_NO, "
				+ 		" T03.KTEREN_FURIS_SSN_HJNO, "
				+ 		" T03.HAKK_KSH, "
				+ 		" T03.KTEREN_CMPY_CD, "
				+ 		" T03.KTEREN_CHAK_YOT_DATE, "
				+ 		" T03.KTEREN_KDO_TES_YOT_DATE, "
				+ 		" T03.KTEREN_JOT_KIN, "
				+ 		" T03.GENK, "
				+ 		" T04.ERR_INF "
				+ 	" FROM "
				+ 		" (SELECT "
				+ 			" KTEREN_SSN_NO, "
				+ 			" KTEREN_SSN_HJNO, "
				+ 			" KTEREN_FURI_KENME, "
				+ 			" KTEREN_FURIS_SSN_NO, "
				+ 			" KTEREN_FURIS_SSN_HJNO, "
				+ 			" CASE "
				+ 			" WHEN KTEREN_GNB_KKSH_CD = '7011331' THEN '7011330' "
				+ 			" ELSE KTEREN_GNB_KKSH_CD "
				+ 			" END AS HAKK_KSH, "
				+ 			" KTEREN_CMPY_CD, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_KDO_TES_YOT_DATE, "
				+ 			" SUM (KTEREN_JOT_KIN) AS KTEREN_JOT_KIN, "
				+ 			" SUM (KTEREN_KIN) AS GENK "
				+ 		" FROM "
				+ 			" R_KTEREN_SHJ "
				+ 		" WHERE "
				+ 			" KTEREN_GYOM_KBN = '4' "
				+ 		" AND "
				+ 			" KTEREN_DEL_KBN = '0' "
				+ 		" AND "
				+ 			" KTEREN_SHJ_KBN = '1' "
				+ 		" GROUP BY "
				+ 			" KTEREN_SSN_NO, "
				+ 			" KTEREN_SSN_HJNO, "
				+ 			" KTEREN_FURIS_SSN_NO, "
				+ 			" KTEREN_FURIS_SSN_HJNO, "
				+ 			" KTEREN_CHAK_YOT_DATE, "
				+ 			" KTEREN_GNB_KKSH_CD, "
				+ 			" KTEREN_CMPY_CD, "
				+ 			" KTEREN_FURI_KENME, "
				+ 			" KTEREN_KDO_TES_YOT_DATE "
				+ 		" ) T03 "
				+ 		" LEFT OUTER JOIN W_KTEREN_ERR_FURIS_1 T04 "
				+ 		" ON T03.KTEREN_FURIS_SSN_NO = T04.FURIS_SSN_NO "
				+ 		" AND T03.KTEREN_FURIS_SSN_HJNO = T04.FURIS_SSN_HJNO "
				+ 	" WHERE "
				+ 		" T04.FURIS_SSN_NO IS NULL "
				+ 	" )T02 "
				+ 	" LEFT OUTER JOIN  R_SSN T01 "
				+ 	" ON T01.SSN_NO = T02.KTEREN_SSN_NO "
				+ 	" AND T01.SSN_HJNO = T02.KTEREN_SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_SELECT_005",
				new String[] {}
				);

		// FKSB007_SELECT_006
		sqlMap.put(
				"FKSB007_SELECT_006",
				" SELECT "
				+ 	" T01.KTEREN_CMPY_CD, "
				+ 	" T01.SSN_NO, "
				+ 	" T01.SSN_HJNO, "
				+ 	" T01.FURIS_SSN_NO, "
				+ 	" T01.FURIS_SSN_HJNO, "
				+ 	" T01.FURI_KENME, "
				+ 	" T01.WBS_YOS, "
				+ 	" T01.CHAK_YOT_DATE, "
				+ 	" T01.GENK, "
				+ 	" T01.YOT_DATE, "
				+ 	" T01.HAKK_KSH, "
				+ 	" T02.ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_FURIS T01 "
				+ 	" INNER JOIN W_KTEREN_ERR_FURIM_2 T02 "
				+ 	" ON T01.FURIS_SSN_NO = T02.FURIS_SSN_NO "
				+ 	" AND T01.FURIS_SSN_HJNO = T02.FURIS_SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_SELECT_006",
				new String[] {}
				);

		// FKSB007_SELECT_007
		sqlMap.put(
				"FKSB007_SELECT_007",
				" SELECT "
				+ 	" T01.FURIS_SSN_NO "
				+ " FROM "
				+ 	" W_KTEREN_FURIS T01 "
				+ 	" LEFT OUTER JOIN W_KTEREN_FURIM T02 "
				+ 	" ON T01.FURIS_SSN_NO = T02.FURIS_SSN_NO "
				+ 	" AND T01.FURIS_SSN_HJNO = T02.FURIS_SSN_HJNO "
				+ 	" AND T01.CHAK_YOT_DATE = T02.CHAK_YOT_DATE "
				+ 	" AND T01.HAKK_KSH = T02.HAKK_KSH "
				+ " WHERE "
				+ 	" T02.FURIS_SSN_NO IS NULL "
				);
		paramMap.put(
				"FKSB007_SELECT_007",
				new String[] {}
				);

		// FKSB007_SELECT_008
		sqlMap.put(
				"FKSB007_SELECT_008",
				" SELECT "
				+ 	" T01.FURIS_SSN_NO "
				+ " FROM "
				+ 	" W_KTEREN_FURIM T01 "
				+ 	" LEFT OUTER JOIN W_KTEREN_FURIS T02 "
				+ 	" ON T01.FURIS_SSN_NO = T02.FURIS_SSN_NO "
				+ 	" AND T01.FURIS_SSN_HJNO = T02.FURIS_SSN_HJNO "
				+ 	" AND T01.CHAK_YOT_DATE = T02.CHAK_YOT_DATE "
				+ 	" AND T01.HAKK_KSH = T02.HAKK_KSH "
				+ " WHERE "
				+ 	" T02.FURIS_SSN_NO IS NULL "
				);
		paramMap.put(
				"FKSB007_SELECT_008",
				new String[] {}
				);

		// FKSB007_SELECT_009
		sqlMap.put(
				"FKSB007_SELECT_009",
				" SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH, "
				+ 	" ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_ERR "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH, "
				+ 	" ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_ERR_FURIS_1 "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH, "
				+ 	" ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_ERR_FURIS_2 "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH, "
				+ 	" ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_ERR_FURIM_1 "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH, "
				+ 	" ERR_INF "
				+ " FROM "
				+ 	" W_KTEREN_ERR_FURIM_2 "
				);
		paramMap.put(
				"FKSB007_SELECT_009",
				new String[] {}
				);

		// FKSB007_SELECT_010
		sqlMap.put(
				"FKSB007_SELECT_010",
				" SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH "
				+ " FROM "
				+ 	" W_KTEREN_JKK "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH "
				+ " FROM "
				+ 	" W_KTEREN_JOT "
				+ " UNION "
				+ " SELECT "
				+ 	" GYOM_KBN, "
				+ 	" KTEREN_CMPY_CD, "
				+ 	" SSN_NO, "
				+ 	" SSN_HJNO, "
				+ 	" FURIS_SSN_NO, "
				+ 	" FURIS_SSN_HJNO, "
				+ 	" TRHK_TYP_SBT, "
				+ 	" PRJ_DEF, "
				+ 	" FURI_KENME, "
				+ 	" WBS_YOS, "
				+ 	" CHAK_YOT_DATE, "
				+ 	" GENK, "
				+ 	" YOT_DATE, "
				+ 	" KURIN_KBN_NOT, "
				+ 	" JOT_KIN, "
				+ 	" HAKK_KSH "
				+ " FROM "
				+ 	" W_KTEREN_FURI "
				);
		paramMap.put(
				"FKSB007_SELECT_010",
				new String[] {}
				);

		// FKSB007_INSERT_001
		sqlMap.put(
				"FKSB007_INSERT_001",
				" INSERT INTO W_KTEREN_JKK ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH "
				+ " ) VALUES ( "
				+ " '2', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " 'X', "
				+ " '0', "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_001",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "PRJ_DEF", "WBS_YOS", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH"}
				);

		// FKSB007_INSERT_002
		sqlMap.put(
				"FKSB007_INSERT_002",
				" INSERT INTO W_KTEREN_ERR ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " ) VALUES ( "
				+ " '2', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " 'X', "
				+ " '0', "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_002",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "PRJ_DEF", "WBS_YOS", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH", "ERR_INF"}
				);

		// FKSB007_INSERT_003
		sqlMap.put(
				"FKSB007_INSERT_003",
				" INSERT INTO W_KTEREN_JOT ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH "
				+ " ) VALUES ( "
				+ " '3', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " 'X', "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_003",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "TRHK_TYP_SBT", "PRJ_DEF", "WBS_YOS", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "JOT_KIN", "HAKK_KSH"}
				);

		// FKSB007_INSERT_004
		sqlMap.put(
				"FKSB007_INSERT_004",
				" INSERT INTO W_KTEREN_ERR ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " ) VALUES ( "
				+ " '3', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " 'X', "
				+ " ?, "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_004",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "TRHK_TYP_SBT", "PRJ_DEF", "WBS_YOS", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "JOT_KIN", "HAKK_KSH", "ERR_INF"}
				);

		// FKSB007_INSERT_005
		sqlMap.put(
				"FKSB007_INSERT_005",
				" INSERT INTO W_KTEREN_FURIS ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH "
				+ " ) VALUES ( "
				+ " '5', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " '0', "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_005",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "FURIS_SSN_NO", "FURIS_SSN_HJNO", "FURI_KENME", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH"}
				);

		// FKSB007_INSERT_006
		sqlMap.put(
				"FKSB007_INSERT_006",
				" INSERT INTO W_KTEREN_ERR_FURIS_1 ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " ) VALUES ( "
				+ " '5', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " '0', "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_006",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "FURIS_SSN_NO", "FURIS_SSN_HJNO", "FURI_KENME", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH", "ERR_INF"}
				);

		// FKSB007_INSERT_007
		sqlMap.put(
				"FKSB007_INSERT_007",
				" INSERT INTO W_KTEREN_ERR_FURIM_1 ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " )SELECT "
				+ 	" '5', "
				+ 	" T01.KTEREN_CMPY_CD, "
				+ 	" T01.KTEREN_SSN_NO, "
				+ 	" T01.KTEREN_SSN_HJNO, "
				+ 	" T01.KTEREN_FURIS_SSN_NO, "
				+ 	" T01.KTEREN_FURIS_SSN_HJNO, "
				+ 	" ' ', "
				+ 	" ' ', "
				+ 	" T01.KTEREN_FURI_KENME, "
				+ 	" ' ', "
				+ 	" T01.KTEREN_CHAK_YOT_DATE, "
				+ 	" T01.GENK, "
				+ 	" T01.KTEREN_KDO_TES_YOT_DATE, "
				+ 	" ' ', "
				+ 	" '0', "
				+ 	" T01.HAKK_KSH, "
				+ 	" T02.ERR_INF "
				+ " FROM "
				+ 	" (SELECT "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" CASE "
				+ 			" WHEN KTEREN_GNB_KKSH_CD = '7011331' THEN '7011330' "
				+ 			" ELSE KTEREN_GNB_KKSH_CD "
				+ 		" END AS HAKK_KSH, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_KDO_TES_YOT_DATE, "
				+ 		" SUM (KTEREN_JOT_KIN) AS KTEREN_JOT_KIN, "
				+ 		" SUM (KTEREN_KIN) AS GENK "
				+ 	" FROM "
				+ 		" R_KTEREN_SHJ "
				+ 	" WHERE "
				+ 		" KTEREN_GYOM_KBN = '4' "
				+ 	" AND "
				+ 		" KTEREN_DEL_KBN = '0' "
				+ 	" AND "
				+ 		" KTEREN_SHJ_KBN = '1' "
				+ 	" GROUP BY "
				+ 		" KTEREN_SSN_NO, "
				+ 		" KTEREN_SSN_HJNO, "
				+ 		" KTEREN_FURIS_SSN_NO, "
				+ 		" KTEREN_FURIS_SSN_HJNO, "
				+ 		" KTEREN_CHAK_YOT_DATE, "
				+ 		" KTEREN_GNB_KKSH_CD, "
				+ 		" KTEREN_CMPY_CD, "
				+ 		" KTEREN_FURI_KENME, "
				+ 		" KTEREN_KDO_TES_YOT_DATE "
				+ 	" ) T01 "
				+ 	" INNER JOIN W_KTEREN_ERR_FURIS_1 T02 "
				+ 	" ON  T01.KTEREN_FURIS_SSN_NO = T02.FURIS_SSN_NO "
				+ 	" AND T01.KTEREN_FURIS_SSN_HJNO = T02.FURIS_SSN_HJNO "
				);
		paramMap.put(
				"FKSB007_INSERT_007",
				new String[] {}
				);

		// FKSB007_INSERT_008
		sqlMap.put(
				"FKSB007_INSERT_008",
				" INSERT INTO W_KTEREN_FURIM ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH "
				+ " ) VALUES ( "
				+ " '4', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " '0', "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_008",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "FURIS_SSN_NO", "FURIS_SSN_HJNO", "FURI_KENME", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH"}
				);

		// FKSB007_INSERT_009
		sqlMap.put(
				"FKSB007_INSERT_009",
				" INSERT INTO W_KTEREN_ERR_FURIM_2 ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " ) VALUES ( "
				+ " '4', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " '0', "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_009",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "FURIS_SSN_NO", "FURIS_SSN_HJNO", "FURI_KENME", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH", "ERR_INF"}
				);

		// FKSB007_INSERT_010
		sqlMap.put(
				"FKSB007_INSERT_010",
				" INSERT INTO W_KTEREN_ERR_FURIS_2 ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH, "
				+ " ERR_INF "
				+ " ) VALUES ( "
				+ " '5', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " ' ', "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ?, "
				+ " ' ', "
				+ " '0', "
				+ " ?, "
				+ " ? "
				+ " ) "
				);
		paramMap.put(
				"FKSB007_INSERT_010",
				new String[] {"KTEREN_CMPY_CD", "SSN_NO", "SSN_HJNO", "FURIS_SSN_NO", "FURIS_SSN_HJNO", "FURI_KENME", "WBS_YOS", "CHAK_YOT_DATE", "GENK", "YOT_DATE", "HAKK_KSH", "ERR_INF"}
				);

		// FKSB007_INSERT_011
		sqlMap.put(
				"FKSB007_INSERT_011",
				" INSERT INTO W_KTEREN_FURI ( "
				+ " GYOM_KBN, "
				+ " KTEREN_CMPY_CD, "
				+ " SSN_NO, "
				+ " SSN_HJNO, "
				+ " FURIS_SSN_NO, "
				+ " FURIS_SSN_HJNO, "
				+ " TRHK_TYP_SBT, "
				+ " PRJ_DEF, "
				+ " FURI_KENME, "
				+ " WBS_YOS, "
				+ " CHAK_YOT_DATE, "
				+ " GENK, "
				+ " YOT_DATE, "
				+ " KURIN_KBN_NOT, "
				+ " JOT_KIN, "
				+ " HAKK_KSH "
				+ " )SELECT "
				+ 	" T02.GYOM_KBN, "
				+ 	" T02.KTEREN_CMPY_CD, "
				+ 	" T02.SSN_NO, "
				+ 	" T02.SSN_HJNO, "
				+ 	" T02.FURIS_SSN_NO, "
				+ 	" T02.FURIS_SSN_HJNO, "
				+ 	" T02.TRHK_TYP_SBT, "
				+ 	" T02.PRJ_DEF, "
				+ 	" T02.FURI_KENME, "
				+ 	" T02.WBS_YOS, "
				+ 	" T02.CHAK_YOT_DATE, "
				+ 	" T02.GENK, "
				+ 	" T02.YOT_DATE, "
				+ 	" T02.KURIN_KBN_NOT, "
				+ 	" T02.JOT_KIN, "
				+ 	" T02.HAKK_KSH "
				+ " FROM "
				+ 	" W_KTEREN_FURIS T01 "
				+ 	" INNER JOIN W_KTEREN_FURIM T02 "
				+ 	" ON T01.FURIS_SSN_NO = T02.FURIS_SSN_NO "
				+ 	" AND T01.FURIS_SSN_HJNO = T02.FURIS_SSN_HJNO "
				+ 	" AND T01.CHAK_YOT_DATE = T02.CHAK_YOT_DATE "
				+ 	" AND T01.HAKK_KSH = T02.HAKK_KSH "
				);
		paramMap.put(
				"FKSB007_INSERT_011",
				new String[] {}
				);

		// FKSB016�p
		// FKSB0016_UPDATE_001
		sqlMap.put(
				"FKSB016_UPDATE_001",
				" UPDATE "
				+     " R_KYKSH T01 "
				+ " SET "
				+     " KYKSH_TDFK_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.KYKSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.KYKSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.KYKSH_TDFK_NAME), "
				+     " KYKSH_OOA_TSH_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.VILLAGE_SECTION_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.KYKSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.KYKSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.KYKSH_OOA_TSH_NAME), "
				+     " KYKSH_ACM = COALESCE (( "
				+             " SELECT "
				+                 " T02.CITY_BLOCK_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.KYKSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.KYKSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.KYKSH_ACM), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.KYKSH_NO IN ( "
				+             " SELECT "
				+                 " T03.KYKSH_NO "
				+             " FROM "
				+                 " R_KYKSH T03 "
				+             " WHERE "
				+                 " T03.KYKSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.KYKSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.KYKSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_001",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_002
		sqlMap.put(
				"FKSB016_UPDATE_002",
				" UPDATE "
				+     " R_KYKSH T01 "
				+ " SET "
				+     " KYKSH_TDFK_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.MUNICIPALITY_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.KYKSH_TDFK_NAME = (T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI) "
				+             " AND T01.KYKSH_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.KYKSH_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.KYKSH_TDFK_CD), "
				+     " KYKSH_OOA_TSH_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.LOCATION_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.KYKSH_TDFK_NAME = (T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI) "
				+             " AND T01.KYKSH_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.KYKSH_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.KYKSH_OOA_TSH_CD), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.KYKSH_NO IN ( "
				+             " SELECT "
				+                 " T03.KYKSH_NO "
				+             " FROM "
				+                 " R_KYKSH T03 "
				+             " WHERE "
				+                 " T03.KYKSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.KYKSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.KYKSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_002",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_003
		sqlMap.put(
				"FKSB016_UPDATE_003",
				" UPDATE "
				+     " R_KYKSH T01 "
				+ " SET "
				+     " SHR_TDFK_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.SHR_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.SHR_OOA_TSH_NAME_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.SHR_TDFK_NAME), "
				+     " SHR_ADD_OOA_TSH_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.VILLAGE_SECTION_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.SHR_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.SHR_OOA_TSH_NAME_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.SHR_ADD_OOA_TSH_NAME), "
				+     " SHR_ADD_ACM = COALESCE (( "
				+             " SELECT "
				+                 " T02.CITY_BLOCK_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.SHR_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.SHR_OOA_TSH_NAME_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.SHR_ADD_ACM), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.KYKSH_NO IN ( "
				+             " SELECT "
				+                 " T03.KYKSH_NO "
				+             " FROM "
				+                 " R_KYKSH T03 "
				+             " WHERE "
				+                 " T03.KYKSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.KYKSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.KYKSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_003",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_004
		sqlMap.put(
				"FKSB016_UPDATE_004",
				" UPDATE "
				+     " R_KYKSH T01 "
				+ " SET "
				+     " SHR_TDFK_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.MUNICIPALITY_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.SHR_TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.SHR_ADD_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.SHR_ADD_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.SHR_TDFK_CD), "
				+     " SHR_OOA_TSH_NAME_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.LOCATION_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.SHR_TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.SHR_ADD_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.SHR_ADD_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.SHR_OOA_TSH_NAME_CD), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.KYKSH_NO IN ( "
				+             " SELECT "
				+                 " T03.KYKSH_NO "
				+             " FROM "
				+                 " R_KYKSH T03 "
				+             " WHERE "
				+                 " T03.KYKSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.KYKSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.KYKSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_004",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB016_UPDATE_004_CNT
		sqlMap.put(
				"FKSB016_UPDATE_004_CNT",
				" SELECT "
				+     " COUNT(*) "
				+ " FROM "
				+     " R_KYKSH T01 "
				+ " WHERE "
				+     " T01.KYKSH_NO IN ( "
				+         " SELECT "
				+             " T03.KYKSH_NO "
				+         " FROM "
				+             " R_KYKSH T03 "
				+         " WHERE "
				+             " T03.KYKSH_TDFK_CD <> '99999' "
				+         " AND "
				+             " RIGHT (T03.KYKSH_TDFK_CD, 3) <> '000' "
				+             " AND "
				+             " RIGHT (T03.KYKSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+     " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_004_CNT",
				new String[] {}
				);

		// FKSB0016_UPDATE_005
		sqlMap.put(
				"FKSB016_UPDATE_005",
				" UPDATE "
				+     " R_BKN T01 "
				+ " SET "
				+     " TDFK_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.BKN_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.TDFK_NAME), "
				+     " OOA_TSH_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.VILLAGE_SECTION_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.BKN_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OOA_TSH_NAME), "
				+     " BKN_ACM = COALESCE (( "
				+             " SELECT "
				+                 " T02.CITY_BLOCK_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.BKN_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.BKN_ACM), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.BKN_NO IN ( "
				+             " SELECT "
				+                 " T03.BKN_NO "
				+             " FROM "
				+                 " R_BKN T03 "
				+             " WHERE "
				+                 " T03.TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.BKN_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_005",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_006
		sqlMap.put(
				"FKSB016_UPDATE_006",
				" UPDATE "
				+     " R_BKN T01 "
				+ " SET "
				+     " TDFK_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.MUNICIPALITY_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.BKN_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.TDFK_CD), "
				+     " BKN_OOA_TSH_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.LOCATION_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.BKN_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.BKN_OOA_TSH_CD), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.BKN_NO IN ( "
				+             " SELECT "
				+                 " T03.BKN_NO "
				+             " FROM "
				+                 " R_BKN T03 "
				+             " WHERE "
				+                 " T03.TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.BKN_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_006",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_006_CNT
		sqlMap.put(
				"FKSB016_UPDATE_006_CNT",
				" SELECT "
				+     " COUNT(*) "
				+ " FROM "
				+     " R_BKN T01 "
				+ " WHERE "
				+     " T01.BKN_NO IN ( "
				+         " SELECT "
				+             " T03.BKN_NO "
				+         " FROM "
				+             " R_BKN T03 "
				+         " WHERE "
				+             " T03.TDFK_CD <> '99999' "
				+         " AND "
				+             " RIGHT (T03.TDFK_CD, 3) <> '000' "
				+             " AND "
				+             " RIGHT (T03.BKN_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+     " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_006_CNT",
				new String[] {}
				);

		// FKSB0016_UPDATE_007
		sqlMap.put(
				"FKSB016_UPDATE_007",
				" UPDATE "
				+     " R_BKN T01 "
				+ " SET "
				+     " OLD_SYSH_TDFK_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.OLD_SYSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.OLD_SYSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OLD_SYSH_TDFK_NAME), "
				+     " OLD_SYSH_OOA_TSH_NAME = COALESCE (( "
				+             " SELECT "
				+                 " T02.VILLAGE_SECTION_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.OLD_SYSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.OLD_SYSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OLD_SYSH_OOA_TSH_NAME), "
				+     " OLD_SYSH_ACM = COALESCE (( "
				+             " SELECT "
				+                 " T02.CITY_BLOCK_KANJI "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.OLD_SYSH_TDFK_CD = T02.MUNICIPALITY_CD "
				+             " AND T01.OLD_SYSH_OOA_TSH_CD = T02.LOCATION_CD "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OLD_SYSH_ACM), "
				+     " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.BKN_NO IN ( "
				+             " SELECT "
				+                 " T03.BKN_NO "
				+             " FROM "
				+                 " R_BKN T03 "
				+             " WHERE "
				+                 " T03.OLD_SYSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.OLD_SYSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.OLD_SYSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_007",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_008
		sqlMap.put(
				"FKSB016_UPDATE_008",
				" UPDATE "
				+     " R_BKN T01 "
				+ " SET "
				+     " OLD_SYSH_TDFK_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.MUNICIPALITY_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.OLD_SYSH_TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.OLD_SYSH_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.OLD_SYSH_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OLD_SYSH_TDFK_CD), "
				+     " OLD_SYSH_OOA_TSH_CD = COALESCE (( "
				+             " SELECT "
				+                 " T02.LOCATION_CD "
				+             " FROM "
				+                 " R_ADDRESS T02 "
				+             " WHERE "
				+                 " T01.OLD_SYSH_TDFK_NAME = T02.PREFECTURE_KANJI || ' ' || T02.CITY_COUNTY_MUNICIPALITY_KANJI "
				+             " AND T01.OLD_SYSH_OOA_TSH_NAME = T02.VILLAGE_SECTION_KANJI "
				+             " AND T01.OLD_SYSH_ACM = T02.CITY_BLOCK_KANJI "
				+             " AND "
				+                 " LEFT (T02.LOCATION_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T02.LOCATION_CD, 3) = '000' "
				+         " ), T01.OLD_SYSH_OOA_TSH_CD), "
				+      " UPD_USR = ?, "
				+     " UPD_DATE = ? "
				+     " WHERE "
				+         " T01.BKN_NO IN ( "
				+             " SELECT "
				+                 " T03.BKN_NO "
				+             " FROM "
				+                 " R_BKN T03 "
				+             " WHERE "
				+                 " T03.OLD_SYSH_TDFK_CD <> '99999' "
				+             " AND "
				+                 " RIGHT (T03.OLD_SYSH_TDFK_CD, 3) <> '000' "
				+                 " AND "
				+                 " RIGHT (T03.OLD_SYSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+         " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_008",
				new String[] {"UPD_USR", "UPD_DATE"}
				);

		// FKSB0016_UPDATE_008_CNT
		sqlMap.put(
				"FKSB016_UPDATE_008_CNT",
				" SELECT "
				+     " COUNT(*) "
				+ " FROM "
				+     " R_BKN T01 "
				+ " WHERE "
				+     " T01.BKN_NO IN ( "
				+         " SELECT "
				+             " T03.BKN_NO "
				+         " FROM "
				+             " R_BKN T03 "
				+         " WHERE "
				+             " T03.OLD_SYSH_TDFK_CD <> '99999' "
				+         " AND "
				+             " RIGHT (T03.OLD_SYSH_TDFK_CD, 3) <> '000' "
				+             " AND "
				+             " RIGHT (T03.OLD_SYSH_OOA_TSH_CD, 3) NOT BETWEEN '851' AND '899' "
				+     " ) "
				);
		paramMap.put(
				"FKSB016_UPDATE_008_CNT",
				new String[] {}
				);


		 /** COMMON_40_1 SQL .*/
		sqlMap.put(
				"COMMON_40_1",
	            "SELECT "
	                    +    "KBN_NAME "
	                    + "FROM  "
	                    +    "R_KBN AS R_KBN_1 "
	                    + "WHERE "
	                    +    "R_KBN_1.KBN_SBT_CD = ? AND "
	                    +    "R_KBN_1.KBN_CD = ? ");

	    /** COMMON_40_1 �p�����[�^��` .*/
		paramMap.put("COMMON_40_1", new String[]{"KBN_SBT_CD_W01", "KBN_CD_W01"});

		 /** COMMON_55_1 SQL .*/
		sqlMap.put(
			"COMMON_55_1",
	        "SELECT "
	        +    "MAX(TOK_NO) AS TOK_NO "
	        + "FROM  "
	        +	 "( "
	        +		"SELECT "
	        +			"TOK_NO "
	        +		"FROM  "
	        +			"BACK_LOGWK AS BACK_LOGWK_1 "
	        +		"UNION ALL "
	        +		"SELECT "
	        +			"TOK_NO "
	        +		"FROM  "
	        +			"R_DAI_CRE_KEY AS R_DAI_CRE_KEY_1"
	        +       "UNION ALL "
	        +		"SELECT "
	        +			"TOK_NO "
	        +		"FROM  "
	        +			"R_UPD_RRK AS R_UPD_RRK_1 "
	        +		"UNION ALL "
	        +		"SELECT "
	        +			"KTEREN_TOK_NO AS TOK_NO "
	        +		"FROM "
	        +			"R_KTEREN_SHJ AS R_KTEREN_SHJ_1 "
	        +	") SUB_1 "
	        + "WHERE "
	        +    "substr(SUB_1.TOK_NO,1,22) = ?");

	    /** COMMON_55_1 �p�����[�^��` .*/
		paramMap.put("COMMON_55_1", new String[]{"TOK_NO_W01"});

		/** COMMON_61_1 SQL .*/
		sqlMap.put(
			"COMMON_61_1",
            "SELECT "
                    +    "CHOHY_PASS, "
                    +    "FILE_NAME "
                    + "FROM  "
                    +    "R_CHOHY AS R_CHOHY_1 "
                    + "WHERE "
                    +    "R_CHOHY_1.CHOHY_ID = ? ");

	    /** COMMON_61_1 �p�����[�^��` .*/
		paramMap.put("COMMON_61_1", new String[]{"CHOHY_ID_W01"});


	    /** COMMON_62_1 SQL .*/
		sqlMap.put(
		"COMMON_62_1",
        " INSERT INTO R_CRE_CHOHY ("
                +     " CRE_CHOHY_RNO,  "
                +     " CHOHY_ID,  "
                +     " CHOHY_PASS,  "
                +     " TOK_DATE,  "
                +     " PRE_PRINT_DATE,  "
                +     " JGSH_CD, "
                +     " SFSK_CD, "
                +     " CHOHY_SBT,  "
                +     " STTS_KBN,  "
                +     " UPD_USR,  "
                +     " UPD_DATE "
                + " ) VALUES ( "
                +     " NEXTVAL ('SEQ_CRE_CHOHY_RNO'),  "
                +     " ?, "
                +     " ?, "
                +     " ?, "
                +     " ' ', "
                +     " ?, "
                +     " ?, "
                +     " ?, "
                +     " '0', "
                +     " ?, "
                +     " ?) ");

	    /** COMMON_61_1 �p�����[�^��` .*/
		paramMap.put("COMMON_62_1", new String[]{"CHOHY_ID", "CHOHY_PASS", "TOK_DATE", "JGSH_CD", "SFSK_CD", "CHOHY_SBT", "UPD_USR", "UPD_DATE"});

		/** COMMON_67_1 SQL .*/
		sqlMap.put(
		"COMMON_67_1",
        "SELECT "
                +    "JGSH_CD "
                + "FROM  "
                +    "R_JGSH "
                + "WHERE "
                +    " JGSH_NAME = ? ");

    /** COMMON_61_1 �p�����[�^��` .*/
	paramMap.put("COMMON_67_1", new String[]{"JGSH_NAME_W01"});




		// ********************************************/
	    /* ���[�쐬                                   */
	    // ********************************************/
		// FKSR001_SEL_001
		sqlMap.put(
				"FKSR001_SEL_001",
				" SELECT "
				+     " CHOHY_RNO, "
				+     " SFSK_CD, "
				+     " SFSK_NAME, "
				+     " DAI_KKSH_NAME, "
				+     " GNB_KKSH_NAME, "
				+     " JUT_KKSH_NAME, "
				+     " NOTE_MSG, "
				+     " NOW_DATE, "
				+     " SYU_NO, "
				+     " BKN_NO, "
				+     " SSN_NO, "
				+     " GENK_CTR_NAME, "
				+     " SETB_KMK_NAME, "
				+     " WBS_YOS, "
				+     " WBS_NAME, "
				+     " KAN_CD, "
				+     " KAN_NAME, "
				+     " KKT_CD, "
				+     " KKT_NAME, "
				+     " DHY_KKT_NAME_CD, "
				+     " DHY_KKT_NAME, "
				+     " KNRI_SBT_NAME, "
				+     " TET_NO, "
				+     " CMK_KOB, "
				+     " CMK_GEK, "
				+     " SHK_JIY, "
				+     " TCH_SHK_DATE, "
				+     " RIT_KIT_NO, "
				+     " RIT_KIT_DATE, "
				+     " SHK_KIN, "
				+     " KYKS_KBN_NAME, "
				+     " JOSSK_Z_KBN_NAME, "
				+     " TKISS_KBN_NAME, "
				+     " YOT, "
				+     " TKI_DATE, "
				+     " MTKIT_RYU, "
				+     " TSK_YOT, "
				+     " SYU_KENCH, "
				+     " YEK, "
				+     " KAS, "
				+     " JOSO, "
				+     " MES_KOB, "
				+     " MES_JOSSK, "
				+     " TDFK_NAME, "
				+     " OOA_TSH_NAME, "
				+     " ACM, "
				+     " BKN_CBN, "
				+     " OLD_SHYU_SHA_TDFK_NAME, "
				+     " OLD_SYSH_OOA_TSH_NAME, "
				+     " OLD_SYSH_ACM, "
				+     " OLD_SYSH_CBN, "
				+     " OLD_SYSH_NAME, "
				+     " KYYU_MCBN_BUNS, "
				+     " KYYU_MCBN_BUIB, "
				+     " HKSU, "
				+     " KAIKE_KICHO_DATE, "
				+     " CHOB_GENK_ZAN_KIN, "
				+     " FUTKIN, "
				+     " GENS_SONS_SUM_KIN, "
				+     " CMPY_NAME, "
				+     " SNH_KBN "
				+ " FROM "
				+     " TKSR001WK AS TKSR001WK_1 "
				+ " ORDER BY "
				+     " TKSR001WK_1.CHOHY_RNO ASC "
				);
		paramMap.put(
				"FKSR001_SEL_001",
				new String[] {}
				);

		// FKSR001_SEL_002
		sqlMap.put(
				"FKSR001_SEL_002",
				" SELECT "
				+     " CHOHY_DTL_1_RNO, "
				+     " SYU_NO, "
				+     " WBS_YOS, "
				+     " WBS_NAME, "
				+     " SSN_NO, "
				+     " DAI_KKSH_NAME, "
				+     " GNB_KKSH_NAME, "
				+     " SETB_KMK_NAME, "
				+     " SNH_KBN, "
				+     " KAN_CD, "
				+     " KAN_NAME, "
				+     " GENK_CTR_NAME, "
				+     " MES_KOB, "
				+     " MES_JOSSK "
				+ " FROM "
				+     " TKSR001WK2 AS TKSR001WK2_1 "
				+ " WHERE "
				+     " TKSR001WK2_1.CHOHY_RNO = ? "
				+ " ORDER BY "
				+     " TKSR001WK2_1.CHOHY_RNO ASC, "
				+     " TKSR001WK2_1.CHOHY_DTL_1_RNO ASC "
				);
		paramMap.put(
				"FKSR001_SEL_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR001_SEL_003
		sqlMap.put(
				"FKSR001_SEL_003",
				" SELECT "
				+     " CHOHY_RNO, "
				+     " CHOHY_DTL_2_RNO, "
				+     " KYK_NO, "
				+     " KYKSH_ADD_YUB_NO_UP_3, "
				+     " KYKSH_ADD_YUB_NO_DWN_4, "
				+     " KYKSH_TDFK_NAME, "
				+     " KYKSH_OOA_TSH_NAME, "
				+     " KYKSH_ACM, "
				+     " KYKSH_CBN, "
				+     " KYKSH_NAME, "
				+     " KYKSH_TEL_NO, "
				+     " KAST_SUM_MES "
				+ " FROM "
				+     " TKSR001WK3 AS TKSR001WK3_1 "
				+ " WHERE "
				+     " TKSR001WK3_1.CHOHY_RNO = ? "
				+ " ORDER BY "
				+     " TKSR001WK3_1.CHOHY_RNO ASC, "
				+     " TKSR001WK3_1.CHOHY_DTL_2_RNO ASC "
				);
		paramMap.put(
				"FKSR001_SEL_003",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR001_SEL_004
		sqlMap.put(
				"FKSR001_SEL_004",
				" SELECT "
				+     " CHOHY_RNO, "
				+     " CHOHY_DTL_3_RNO, "
				+     " IDO_SBT, "
				+     " IDO_DATE, "
				+     " IDO_KKTS_NO, "
				+     " IDO_KIT_DATE "
				+ " FROM "
				+     " TKSR001WK4 AS TKSR001WK4_1 "
				+ " WHERE "
				+     " TKSR001WK4_1.CHOHY_RNO = ? "
				+ " ORDER BY "
				+     " TKSR001WK4_1.CHOHY_RNO ASC, "
				+     " TKSR001WK4_1.CHOHY_DTL_3_RNO ASC "
				);
		paramMap.put(
				"FKSR001_SEL_004",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR001_SEL_005
		sqlMap.put(
				"FKSR001_SEL_005",
				" SELECT "
				+     " CHOHY_RNO, "
				+     " CHOHY_DTL_4_RNO, "
				+     " IDO_DATE, "
				+     " BKO "
				+ " FROM "
				+     " TKSR001WK5 AS TKSR001WK5_1 "
				+ " WHERE "
				+     " TKSR001WK5_1.CHOHY_RNO = ? "
				+ " ORDER BY "
				+     " TKSR001WK5_1.CHOHY_RNO ASC, "
				+     " TKSR001WK5_1.CHOHY_DTL_4_RNO ASC "
				);
		paramMap.put(
				"FKSR001_SEL_005",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR008_SELECT_001
				sqlMap.put(
				"FKSR008_SELECT_001",
				 "SELECT "
				    +    "R_SYU_TCH_1.SYU_NO, "
				    +    "R_SYU_TCH_1.BKN_NO, "
				    +    "R_SYU_TCH_1.SYU_TCH_HOSHI, "
				    +    "V_SFSK_CMPY_1.CMPY_NAME "
				    + " FROM  "
				    +    "R_SYU_TCH AS R_SYU_TCH_1 "
				    +    "INNER JOIN (// ** �ڍא݌v�����Q�� ** //) "
				    +        "V_SFSK_CMPY AS V_SFSK_CMPY_1 ON  "
				    +    "    R_SYU_TCH_1.DAI_KKSH_CD = V_SFSK_CMPY_1.JGSH_CD "
				    + " WHERE "
				    +    "R_SYU_TCH_1.SYU_NO = ? AND "
				    +    "R_SYU_TCH_1.BKN_NO = ? "
				    );
				paramMap.put(
					"FKSR008_SELECT_001",
					new String[] {"SYU_NO_W01", "BKN_NO_W01"}
					);

		// FKSR008_SELECT_002
		sqlMap.put(
			"FKSR008_SELECT_002",
		    "SELECT "
		       + "V_KYK.KYK_NO,"
			   //+ "V_KYK.HOSHI,"
		       + "R_KYK_BKN.BKN_NO , "
		       + "V_SFSK_CMPY.CMPY_NAME "
		       + "FROM  "
		       + "   V_KYK "
		       + "	INNER JOIN V_SFSK_CMPY ON "
		       + "		V_SFSK_CMPY.JGSH_CD = V_KYK.DAI_KKSH_CD "
		       + "	INNER JOIN R_KYK_BKN ON "
		       + "	  V_KYK.KYK_NO = R_KYK_BKN.KYK_NO "
		       + "WHERE "
		       + "   V_KYK.KYK_NO = ? "
		       + "  AND R_KYK_BKN.BKN_NO = ? "
			);
			paramMap.put(
				"FKSR008_SELECT_002",
				new String[] {"KYK_NO_W01", "BKN_NO_W01"}
				);

		// FKSR009
		// FKSR009_SELECT_001
		sqlMap.put(
			"FKSR009_SELECT_001",
	        " SELECT "
	        + "     TKS.CHOHY_RNO "
	        + "     , TKS.SFSK_CD "
	        + "     , TKS.SFSK_NAME "
	        + "     , TKS.NOW_DATE "
	        + "     , TKS.DAI_KKSH_NAME "
	        + "     , TKS.JUT_KKSH_NAME "
	        + "     , TKS.SHKT_KIN_SU "
	        + "     , TKS.SHKT_KIN "
	        + "     , TKS.FURI_SUM "
	        + "     , TKS.CMPY_NAME "
	        + " FROM "
	        + "     TKSR009WK TKS "
	        + " ORDER BY "
	        + "     TKS.CHOHY_RNO "
	        );
		paramMap.put(
	        "FKSR009_SELECT_001",
	        new String[] {}
	        );

		// FKSR009_SELECT_002
		sqlMap.put(
			"FKSR009_SELECT_002",
	        " SELECT "
	        + "     TKS2.CHOHY_RNO "
	        + "     , TKS2.CHOHY_DTL_1_RNO "
	        + "     , TKS2.CHK "
	        + "     , TKS2.NOTE_MSG "
	        + "     , TKS2.KYK_NO "
	        + "     , TKS2.SETB_KMK_CD "
	        + "     , TKS2.YOT "
	        + "     , TKS2.WBS_YOS "
	        + "     , TKS2.KAN_NAME "
	        + "     , TKS2.KKT_NAME "
	        + "     , TKS2.SHR_DATE "
	        + "     , TKS2.SHR_SBT_NAME "
	        + "     , TKS2.SHR_SKI_NAME "
	        + "     , TKS2.SHR_TSH_KKN_ST "
	        + "     , TKS2.SHR_TSH_KKN_EN "
	        + "     , TKS2.QUES_NO "
	        + "     , TKS2.YUB_NO "
	        + "     , TKS2.KYKSH_TDFK_NAME "
	        + "     , TKS2.KYKSH_OOA_TSH_NAME "
	        + "     , TKS2.KYKSH_ACM "
	        + "     , TKS2.KYKSH_CBN "
	        + "     , TKS2.KYKSH_NAME "
	        + "     , TKS2.KYKKN_NAME "
	        + "     , TKS2.YKIN_SBT "
	        + "     , TKS2.KOZ_NO "
	        + "     , TKS2.KOZ_MEGNIN "
	        + " FROM "
	        + "     TKSR009WK2 TKS2 "
	        + " WHERE "
	        + "     TKS2.CHOHY_RNO = ? "
	        + " ORDER BY "
	        + "     TKS2.CHOHY_RNO "
	        + "     , TKS2.CHOHY_DTL_1_RNO "
	        );
		paramMap.put(
	        "FKSR009_SELECT_002",
	        new String[] {"CHOHY_RNO_W01"}
	        );

		// FKSR009_SELECT_003
		sqlMap.put(
			"FKSR009_SELECT_003",
	        " SELECT "
	        + "     TKS3.CHOHY_RNO "
	        + "     , TKS3.CHOHY_DTL_1_RNO "
	        + "     , TKS3.CHOHY_DTL_2_RNO "
	        + "     , TKS3.HIN_NAME "
	        + "     , TKS3.SHR_KANJ_KMK_CD "
	        + "     , TKS3.ZEI_KBN_NAME "
	        + "     , TKS3.BU_KBN_NAME "
	        + "     , TKS3.PAY_PRC "
	        + "     , TKS3.HMK_WBS_YOS "
	        + "     , TKS3.HMK_WBS_NAME "
	        + " FROM "
	        + "     TKSR009WK3 TKS3 "
	        + " WHERE "
	        + "     TKS3.CHOHY_RNO = ? "
	        + "     AND TKS3.CHOHY_DTL_1_RNO = ? "
	        + " ORDER BY "
	        + "     TKS3.CHOHY_RNO "
	        + "     , TKS3.CHOHY_DTL_1_RNO "
	        + "     , TKS3.CHOHY_DTL_2_RNO "
	        );
		paramMap.put(
	        "FKSR009_SELECT_003",
	        new String[] {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"}
	        );

		// FKSR010
		// FKSR010_SELECT_001
		sqlMap.put(
				"FKSR010_SELECT_001",
				" SELECT "
		        + "     TKS.CHOHY_RNO "
		        + "     , TKS.SFSK_CD "
		        + "     , TKS.SFSK_NAME "
		        + "     , TKS.NOW_DATE "
		        + "     , TKS.DAI_KKSH_NAME "
		        + "     , TKS.JUT_KKSH_NAME "
		        + "     , TKS.SHKT_KIN_SU "
		        + "     , TKS.SHKT_KIN "
		        + "     , TKS.FURI_SUM "
		        + "     , TKS.CMPY_NAME "
		        + " FROM "
		        + "     TKSR010WK TKS "
		        + " ORDER BY "
		        + "     TKS.CHOHY_RNO "
				);
		paramMap.put(
				"FKSR010_SELECT_001",
				new String[] {}
				);

		// FKSR010_SELECT_002
		sqlMap.put(
				"FKSR010_SELECT_002",
				" SELECT "
		        + "     TKS2.CHOHY_RNO "
		        + "     , TKS2.CHOHY_DTL_1_RNO "
		        + "     , TKS2.CHK "
		        + "     , TKS2.NOTE_MSG "
		        + "     , TKS2.KYK_NO "
		        + "     , TKS2.SETB_KMK_CD "
		        + "     , TKS2.YOT "
		        + "     , TKS2.WBS_YOS "
		        + "     , TKS2.KAN_NAME "
		        + "     , TKS2.KKT_NAME "
		        + "     , TKS2.SHR_DATE "
		        + "     , TKS2.SHR_SBT_NAME "
		        + "     , TKS2.SHR_SKI_NAME "
		        + "     , TKS2.SHR_TSH_KKN_ST "
		        + "     , TKS2.SHR_TSH_KKN_EN "
		        + "     , TKS2.YUB_NO "
		        + "     , TKS2.KYKSH_TDFK_NAME "
		        + "     , TKS2.KYKSH_OOA_TSH_NAME "
		        + "     , TKS2.KYKSH_ACM "
		        + "     , TKS2.KYKSH_CBN "
		        + "     , TKS2.KYKSH_NAME "
		        + "     , TKS2.KYKKN_NAME "
		        + "     , TKS2.YKIN_SBT "
		        + "     , TKS2.KOZ_NO "
		        + "     , TKS2.KOZ_MEGNIN "
		        + " FROM "
		        + "     TKSR010WK2 TKS2 "
		        + " WHERE "
		        + "     TKS2.CHOHY_RNO = ? "
		        + " ORDER BY "
		        + "     TKS2.CHOHY_RNO "
		        + "     , TKS2.CHOHY_DTL_1_RNO "
				);
		paramMap.put(
				"FKSR010_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR010_SELECT_003
		sqlMap.put(
				"FKSR010_SELECT_003",
				" SELECT "
		        + "     TKS3.CHOHY_RNO "
		        + "     , TKS3.CHOHY_DTL_1_RNO "
		        + "     , TKS3.CHOHY_DTL_2_RNO "
		        + "     , TKS3.HIN_NAME "
		        + "     , TKS3.SHR_KANJ_KMK_CD "
		        + "     , TKS3.ZEI_KBN_NAME "
		        + "     , TKS3.BU_KBN_NAME "
		        + "     , TKS3.PAY_PRC "
		        + "     , TKS3.HMK_WBS_YOS "
		        + "     , TKS3.HMK_WBS_NAME "
		        + " FROM "
		        + "     TKSR010WK3 TKS3 "
		        + " WHERE "
		        + "     TKS3.CHOHY_RNO = ? "
		        + "     AND TKS3.CHOHY_DTL_1_RNO = ? "
		        + " ORDER BY "
		        + "     TKS3.CHOHY_RNO "
		        + "     , TKS3.CHOHY_DTL_1_RNO "
		        + "     , TKS3.CHOHY_DTL_2_RNO "
				);
		paramMap.put(
				"FKSR010_SELECT_003",
				new String[] {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"}
				);

		// FKSR012_SELECT_001
		sqlMap.put(
				"FKSR012_SELECT_001",
			    "SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "NOW_DATE, "
			    +    "DAI_KKSH_NAME, "
			    +    "JUT_KKSH_NAME, "
			    +    "SHKT_KIN_SU, "
			    +    "SHKT_KIN, "
			    +    "FURI_SUM, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR012WK AS TKSR012WK_1 "
			    + "ORDER BY "
			    +    "TKSR012WK_1.CHOHY_RNO ASC  "
		    );
		paramMap.put(
				"FKSR012_SELECT_001",
				new String[] {}
				);

		// FKSR012_SELECT_002
		sqlMap.put(
				"FKSR012_SELECT_002",
			    "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_1_RNO, "
			    +    "CHK, "
			    +    "NOTE_MSG_1, "
			    +    "NOTE_MSG_2, "
			    +    "NOTE_MSG_3, "
			    +    "KYK_NO, "
			    +    "SETB_KMK_CD, "
			    +    "YOT, "
			    +    "WBS_YOS, "
			    +    "KAN_NAME, "
			    +    "KKT_NAME, "
			    +    "NYK_DATE, "
			    +    "NYK_SBT_NAME, "
			    +    "NYK_SKI_NAME, "
			    +    "NYK_TSH_KKN_ST, "
			    +    "NYK_TSH_KKN_EN, "
			    +    "YUB_NO, "
			    +    "KYKSH_TDFK_NAME, "
			    +    "KYKSH_OOA_TSH_NAME, "
			    +    "KYKSH_ACM, "
			    +    "KYKSH_CBN, "
			    +    "KYKSH_NAME, "
			    +    "KYK_DATE, "
			    +    "KYK_KKN_ST, "
			    +    "KYK_KKN_EN, "
			    +    "KAST_SUM_MES, "
			    +    "DNC_KYK_SU "
			    + "FROM  "
			    +    "TKSR012WK2 AS TKSR012WK2_1 "
			    + "WHERE "
			    +    "TKSR012WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR012WK2_1.CHOHY_RNO ASC , "
			    +    "TKSR012WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );
		paramMap.put(
				"FKSR012_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
			);

		// FKSR012_SELECT_003
		sqlMap.put(
				"FKSR012_SELECT_003",
			    "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_1_RNO, "
			    +    "CHOHY_DTL_2_RNO, "
			    +    "HIN_NAME, "
			    +    "UKE_KANJ_KMK_CD, "
			    +    "ZEI_KBN_NAME, "
			    +    "BU_KBN_NAME, "
			    +    "NYK_KIN, "
			    +    "HMK_WBS_YOS, "
			    +    "HMK_WBS_NAME "
			    + "FROM  "
			    +    "TKSR012WK3 AS TKSR012WK3_1 "
			    + "WHERE "
			    +    "TKSR012WK3_1.CHOHY_RNO = ? AND "
			    +    "TKSR012WK3_1.CHOHY_DTL_1_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR012WK3_1.CHOHY_RNO ASC , "
			    +    "TKSR012WK3_1.CHOHY_DTL_1_RNO ASC , "
			    +    "TKSR012WK3_1.CHOHY_DTL_2_RNO ASC  "
		    );
		paramMap.put(
				"FKSR012_SELECT_003",
				new String[] {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"}
			);

		// FKSR013_SELECT_001
		sqlMap.put(
				"FKSR013_SELECT_001",
				"SELECT "
		        +     "CHOHY_RNO, "
		        +     "SFSK_CD, "
		        +     "SFSK_NAME, "
		        +     "DAI_KKSH_NAME, "
		        +     "JUT_TCH_KKSH_NAME, "
		        +     "NOW_DATE, "
		        +     "CMPY_NAME, "
		        +     "SSN_TANI, "
		        +     "SETB_KMK_NAME "
		        + "FROM "
		        +     "TKSR013WK AS TKSR013WK_1 "
		        + "ORDER BY "
		        +     "TKSR013WK_1.CHOHY_RNO ASC "
				);

		paramMap.put(
				"FKSR013_SELECT_001",
				new String[] {}
				);

		// FKSR013_SELECT_002
		sqlMap.put(
				"FKSR013_SELECT_002",
				  "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_1_RNO, "
			    +    "KAN_CD, "
			    +    "KAN_NAME, "
			    +    "SSN_NO, "
			    +    "SSN_HJNO, "
			    +    "GENK_CTR, "
			    +    "ETC_KNR_UMU, "
			    +    "SHK_Y, "
			    +    "YOCH_CHOB_GENK_ZAN_KIN, "
			    +    "YOCH_FUTKIN, "
			    +    "YOCH_GENS_SONS_SUM_KIN, "
			    +    "KEIR_CHOB_GENK_ZAN_KIN, "
			    +    "KEIR_FUTKIN, "
			    +    "KEIR_GENS_SONS_SUM_KIN, "
			    +    "SHOG_KEKK_CHOB_GENK_ZAN_KIN, "
			    +    "SHOG_KEKK_FUTKIN, "
			    +    "SHOG_KEKK_GENS_SONS_SUM_KIN, "
			    +    "SHOG_KEKK_NOW_SHOKY_SUM_KIN, "
			    +    "KAN_SUM_KOB_MES, "
			    +    "KAN_SUM_JOSSK_MES, "
			    +    "YOCH_NOW_SHOKY_SUM_KIN, "
			    +    "KEIR_NOW_SHOKY_SUM_KIN, "
			    +    "SUM_FLG "
			    + "FROM  "
			    +    "TKSR013WK2 AS TKSR013WK2_1 "
			    + "WHERE "
			    +    "TKSR013WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR013WK2_1.CHOHY_RNO ASC , "
			    +    "TKSR013WK2_1.CHOHY_DTL_1_RNO ASC  "
				);

		paramMap.put(
				"FKSR013_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR015 SQLs START
		/** FKSR015_SELECT_001: ͯ�ް�����̎擾.*/
		sqlMap.put(
			"FKSR015_SELECT_001",
		    "SELECT "
		    +    "CHOHY_RNO, "
		    +    "SFSK_CD, "
		    +    "SFSK_NAME, "
		    +    "DAI_KKSH_NAME, "
		    +    "GNB_KKSH_NAME, "
		    +    "TRHK_TYP_SBT_NAME, "
		    +    "SEKN_GENK_CTR_NAME, "
		    +    "NOW_DATE, "
		    +    "CMPY_NAME "
		    + "FROM "
		    +    "TKSR015WK AS TKSR015WK_1 "
		    + "ORDER BY "
		    +    "TKSR015WK_1.CHOHY_RNO ASC ");

		paramMap.put("FKSR015_SELECT_001", new String[] {});

		/** FKSR015_SELECT_002 SQL .*/
		// ** �ڍא݌v�����Q�� (�ЗL�y�n�����̎擾) ** //
		sqlMap.put(
			"FKSR015_SELECT_002",
			"SELECT "
			+    "CHOHY_RNO, "
			+    "SYU_SYKY_KBN, "
			+    "HTDN_KBN, "
			+    "BULD_KOZ_KBN, "
			+    "BULD_TO_SU, "
			+    "BULD_MES, "
			+    "KSHUS_TO_SU, "
			+    "KSHUS_MES "
			+ "FROM  "
			+    "TKSR015WK2 AS TKSR015WK2_1 "
			+ "WHERE "
			+    "TKSR015WK2_1.CHOHY_RNO = ? "
			+ "ORDER BY "
			+    "TKSR015WK2_1.CHOHY_RNO ASC , "
			+    "TKSR015WK2_1.SYU_SYKY_KBN ASC , "
			+    "TKSR015WK2_1.HTDN_KBN ASC , "
			+    "TKSR015WK2_1.BULD_KOZ_KBN ASC  ");

		paramMap.put("FKSR015_SELECT_002", new String[] {"CHOHY_RNO_W01"});
		// FKSR015 SQLs END

		// FKSR016_SELECT_001
		sqlMap.put(
				"FKSR016_SELECT_001",
			    "SELECT "
	    	    +    "CHOHY_RNO, "
	    	    +    "SFSK_CD, "
	    	    +    "SFSK_NAME, "
	    	    +    "DAI_KKSH_NAME, "
	    	    +    "GNB_KKSH_NAME, "
	    	    +    "SETB_KMK_NAME, "
	    	    +    "NOW_DATE, "
	    	    +    "CMPY_NAME "
	    	    + "FROM  "
	    	    +    "TKSR016WK AS TKSR016WK_1 "
	    	    + "ORDER BY "
	    	    +    "TKSR016WK_1.CHOHY_RNO ASC "
				);

		paramMap.put(
				"FKSR016_SELECT_001",
				new String[] {}
				);

		// FKSR016_SELECT_002
		sqlMap.put(
				"FKSR016_SELECT_002",
			    "SELECT "
	    	    +    "CHOHY_DTL_1_RNO, "
	    	    +    "KYK_NO, "
	    	    +    "KNRI_SBT_NAME, "
	    	    +    "KYK_DATE, "
	    	    +    "AUTO_UPD_SKI, "
	    	    +    "KYK_KKN_ST, "
	    	    +    "KYK_KKN_EN, "
	    	    +    "NXT_KATE_DATE, "
	    	    +    "KKT_CD, "
	    	    +    "KAN_CD, "
	    	    +    "WBS_YOS, "
	    	    +    "KKT_NAME, "
	    	    +    "KAN_NAME, "
	    	    +    "WBS_NAME, "
	    	    +    "KYKSH_NAME, "
	    	    +    "KYKSH_ADD_YUB_NO_UP_3, "
	    	    +    "KYKSH_ADD_YUB_NO_DWN_4, "
	    	    +    "KYKSH_TDFK_NAME, "
	    	    +    "KYKSH_OOA_TSH_NAME, "
	    	    +    "KYKSH_ACM, "
	    	    +    "KYKSH_CBN "
	    	    + "FROM  "
	    	    +    "TKSR016WK2 AS TKSR016WK2_1 "
	    	    + "WHERE "
	    	    +    "TKSR016WK2_1.CHOHY_RNO = ? "
	    	    + "ORDER BY "
	    	    +    "TKSR016WK2_1.CHOHY_DTL_1_RNO ASC  "
				);

		paramMap.put(
				"FKSR016_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR017
		// FKSR017_SELECT_001
		sqlMap.put(
				"FKSR017_SELECT_001",
				" SELECT "
		        + "     TKS.CHOHY_RNO "
		        + "     , TKS.SFSK_CD "
		        + "     , TKS.SFSK_NAME "
		        + "     , TKS.SSN_TANI_1 "
		        + "     , TKS.SSN_TANI_2 "
		        + "     , TKS.DAI_KKSH_NAME "
		        + "     , TKS.SETB_KMK_NAME "
		        + "     , TKS.NOW_DATE "
		        + "     , TKS.CMPY_NAME "
		        + " FROM "
		        + "     TKSR017WK TKS"
		        + " ORDER BY "
		        + "     TKS.CHOHY_RNO "
				);
		paramMap.put(
				"FKSR017_SELECT_001",
				new String[] {}
				);

		// FKSR017_SELECT_002
		sqlMap.put(
				"FKSR017_SELECT_002",
				" SELECT "
		        + "     TKS2.KAN_CD "
		        + "     , TKS2.KAN_NAME "
		        + "     , TKS2.SSN_NO "
		        + "     , TKS2.SSN_HJNO "
		        + "     , TKS2.GENK_CTR "
		        + "     , TKS2.BKN_NO "
		        + "     , TKS2.SYU_NO "
		        + "     , TKS2.UD_SU "
		        + "     , TKS2.KAIKE_KICHO_DATE "
		        + "     , TKS2.IDO_DATE "
		        + "     , TKS2.IDO_SBT_NAME "
		        + "     , TKS2.CHOB_GENK_ZAN_KIN "
		        + "     , TKS2.FUTKIN_GENS_SONS_UMU "
		        + "     , TKS2.SUM_FLG "
		        + " FROM "
		        + "     TKSR017WK2 TKS2 "
		        + " WHERE "
		        + "     TKS2.CHOHY_RNO = ? "
		        + " ORDER BY "
		        + "     TKS2.CHOHY_DTL_1_RNO "
				);
		paramMap.put(
				"FKSR017_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// FKSR018 SQLs - START
		/** FKSR018_SELECT_001: ͯ�ް�����̎擾.*/
		sqlMap.put(
			"FKSR018_SELECT_001",
		    "SELECT "
		    +    "CHOHY_RNO, "
		    +    "SFSK_CD, "
		    +    "SFSK_NAME, "
		    +    "DAI_KKSH_NAME, "
		    +    "GNB_KKSH_NAME, "
		    +    "JUT_TCH_KKSH_NAME, "
		    +    "SETB_KMK_NAME, "
		    +    "NOW_DATE, "
		    +    "CMPY_NAME "
		    + " FROM "
		    +    " TKSR018WK AS TKSR018WK_1 ");

		paramMap.put("FKSR018_SELECT_001", new String[] {});

		/** FKSR018_SELECT_002: ���ו����̎擾.*/
		sqlMap.put(
			"FKSR018_SELECT_002",
		    "SELECT "
			+    "KKT_CD, "
			+    "KAN_CD, "
			+    "WBS_YOS, "
			+    "KKT_NAME, "
			+    "KAN_NAME, "
			+    "WBS_NAME, "
			+    "TET_NO, "
			+    "CMK_NAME, "
			+    "KNR_SU, "
			+    "JITI_CHOS_DATE, "
			+    "MES_KOB, "
			+    "MES_JOSSK, "
			+    "TDFK_NAME, "
			+    "OOA_TSH_NAME, "
			+    "BKN_ACM, "
			+    "BKN_CBN, "
			+    "IJO_UMU_KBN, "
			+    "SCH_NAIY "
			+ "FROM  "
			+    "TKSR018WK2 AS TKSR018WK2_1 "
			+ "WHERE "
			+    "TKSR018WK2_1.CHOHY_RNO = ? "
			+ "ORDER BY "
			+    "TKSR018WK2_1.CHOHY_DTL_1_RNO ASC ");

		paramMap.put("FKSR018_SELECT_002", new String[] {"CHOHY_RNO_W01"});
		// FKSR018 SQLs - END

		// TKSR019_SELECT_001
		sqlMap.put(
				"TKSR019_SELECT_001",
			    "SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "REK_CTR_CD, "
			    +    "DAI_KKSH_NAME, "
			    +    "GNB_KKSH_NAME, "
			    +    "KJO_YM, "
			    +    "FURI_YM, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR019WK AS TKSR019WK_1 "
			    + "ORDER BY "
			    +    "TKSR019WK_1.CHOHY_RNO ASC  "
		    );
		paramMap.put(
				"TKSR019_SELECT_001",
				new String[] {}
				);

		// TKSR019_SELECT_002
		sqlMap.put(
				"TKSR019_SELECT_002",
			    "SELECT "
			    +    "KYK_NO, "
			    +    "KESSN_SERI_YM_1, "
			    +    "KESSN_SERI_YM_2, "
			    +    "PREHR_HIY_KJO_KIN, "
			    +    "PREHR_HIY_FRMD_KIN, "
			    +    "SHR_KANJ_KMK_CD, "
			    +    "SHR_KANJ_KMK_CD_2, "
			    +    "UKE_KANJ_KMK_CD, "
			    +    "UKE_KANJ_KMK_CD_2, "
			    +    "SHR_DATE, "
			    +    "PAY_PRC, "
			    +    "SHR_TSH_KKN_ST, "
			    +    "SHR_TSH_KKN_EN, "
			    +    "SUM_FLG "
			    + "FROM  "
			    +    "TKSR019WK2 AS TKSR019WK2_1 "
			    + "WHERE "
			    +    "TKSR019WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR019WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );
		paramMap.put(
				"TKSR019_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
			);
		// FKSR020_SELECT_001
		sqlMap.put(
				"FKSR020_SELECT_001",
			    "SELECT "
	    	    +    "CHOHY_RNO, "
	    	    +    "SFSK_CD, "
	    	    +    "SFSK_NAME, "
	    	    +    "REK_CTR_NAME, "
	    	    +    "DAI_KKSH_NAME, "
	    	    +    "GNB_KKSH_NAME, "
	    	    +    "KJO_YM, "
	    	    +    "FURI_YM, "
	    	    +    "NOW_DATE, "
	    	    +    "CMPY_NAME "
	    	    + "FROM  "
	    	    +    "TKSR020WK AS TKSR020WK_1 "
	    	    + "ORDER BY "
	    	    +    "TKSR020WK_1.CHOHY_RNO ASC  "
				);
		paramMap.put(
				"FKSR020_SELECT_001",
				new String[] {}
				);

		// FKSR020_SELECT_002
		sqlMap.put(
				"FKSR020_SELECT_002",
			    "SELECT "
	    	    +    "CHOHY_DTL_1_RNO, "
	    	    +    "KYK_NO, "
	    	    +    "KESSN_SERI_YM_1, "
	    	    +    "KESSN_SERI_YM_2, "
	    	    +    "NHR_HIY_KJO_KIN, "
	    	    +    "NHR_HIY_FRMD_KIN, "
	    	    +    "SHR_KANJ_KMK_CD, "
	    	    +    "SHR_KANJ_KMK_CD_2, "
	    	    +    "UKE_KANJ_KMK_CD, "
	    	    +    "UKE_KANJ_KMK_CD_2, "
	    	    +    "SHR_DATE, "
	    	    +    "PAY_PRC, "
	    	    +    "SHR_TSH_KKN_ST, "
	    	    +    "SHR_TSH_KKN_EN, "
	    	    +    "SUM_FLG "
	    	    + "FROM  "
	    	    +    "TKSR020WK2 AS TKSR020WK2_1 "
	    	    + "WHERE "
	    	    +    "TKSR020WK2_1.CHOHY_RNO = ? "
	    	    + "ORDER BY "
	    	    +    "TKSR020WK2_1.CHOHY_RNO ASC , "
	    	    +    "TKSR020WK2_1.CHOHY_DTL_1_RNO ASC  "
				);

		paramMap.put(
				"FKSR020_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);


		// TKSR021_SELECT_001
		sqlMap.put(
			"TKSR021_SELECT_001",
			"SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "GNB_KKSH_NAME, "
			    +    "DAI_KKSH_NAME, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR021WK AS TKSR021WK_1 "
			    + "ORDER BY "
			    +    "TKSR021WK_1.CHOHY_RNO ASC  "
				);
		paramMap.put(
				"TKSR021_SELECT_001",
				new String[] {}
				);

		// TKSR021_SELECT_002
		sqlMap.put(
		  "TKSR021_SELECT_002",
		  "SELECT "
		    +    "KYK_NO, "
		    +    "SETB_KMK_NAME, "
		    +    "YOT_NAME, "
		    +    "KAN_NAME, "
		    +    "WBS_NAME, "
		    +    "UKB_DATE, "
		    +    "SHR_SBT_NAME, "
		    +    "SHR_SKI_NAME, "
		    +    "UKB_TSH_KKN_ST, "
		    +    "UKB_TSH_KKN_EN, "
		    +    "SHR_KMK, "
		    +    "KYOG_TNK_KBN, "
		    +    "SHKT_SUM_MES, "
		    +    "TND_KYOG_TNK, "
		    +    "TND_SHKT_KIN, "
		    +    "YKND_KYOG_TNK, "
		    +    "YKND_SHKT_SHO, "
		    +    "UKB_AIT_NAME, "
		    +    "KYKKN_NAME, "
		    +    "YKIN_SBT, "
		    +    "KOZ_NO, "
		    +    "KOZ_MEGNIN, "
		    +    "KYKSH_ADD_YUB_NO_UP_3, "
		    +    "KYKSH_ADD_YUB_NO_DWN_4, "
		    +    "KYKSH_TDFK_NAME, "
		    +    "KYKSH_OOA_TSH_NAME, "
		    +    "KYKSH_ACM, "
		    +    "KYKSH_CBN "
		    + "FROM  "
		    +    "TKSR021WK2 AS TKSR021WK2_1 "
		    + "WHERE "
		    +    "TKSR021WK2_1.CHOHY_RNO = ? "
		    + "ORDER BY "
		    +    "TKSR021WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );
		paramMap.put(
				"TKSR021_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// TKSR022_SELECT_001
		sqlMap.put(
			"TKSR022_SELECT_001",
			 "SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "GNB_KKSH_NAME, "
			    +    "DAI_KKSH_NAME, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR022WK AS TKSR022WK_1 "
			    + "ORDER BY "
			    +    "TKSR022WK_1.CHOHY_RNO ASC  "
			);
		paramMap.put(
				"TKSR022_SELECT_001",
				new String[] {}
				);

		// TKSR022_SELECT_002
		sqlMap.put(
		  "TKSR022_SELECT_002" ,
		  "SELECT "
			    +    "KYK_NO, "
			    +    "SETB_KMK_NAME, "
			    +    "YOT_NAME, "
			    +    "KAN_NAME, "
			    +    "WBS_NAME, "
			    +    "UKB_DATE, "
			    +    "SHR_SBT_NAME, "
			    +    "SHR_SKI_NAME, "
			    +    "UKB_TSH_KKN_ST, "
			    +    "UKB_TSH_KKN_EN, "
			    +    "SHR_KMK, "
			    +    "KYOG_TNK_KBN, "
			    +    "KYOG_TNK_KBN_NAME, "
			    +    "SHKT_SUM_MES, "
			    +    "ZNND_KYOG_TNK, "
			    +    "ZNND_SHKT_KIN, "
			    +    "TND_KYOG_TNK, "
			    +    "TND_SHKT_KIN, "
			    +    "UKB_AIT_NAME, "
			    +    "KYKKN_NAME, "
			    +    "YKIN_SBT, "
			    +    "KOZ_NO, "
			    +    "KOZ_MEGNIN, "
			    +    "KYKSH_ADD_YUB_NO_UP_3, "
			    +    "KYKSH_ADD_YUB_NO_DWN_4, "
			    +    "KYKSH_TDFK_NAME, "
			    +    "KYKSH_OOA_TSH_NAME, "
			    +    "KYKSH_ACM, "
			    +    "KYKSH_CBN "
			    + "FROM  "
			    +    "TKSR022WK2 AS TKSR022WK2_1 "
			    + "WHERE "
			    +    "TKSR022WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR022WK2_1.CHOHY_DTL_1_RNO ASC  "
				);
		paramMap.put(
				"TKSR022_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		// TKSR023_SEL_001
		sqlMap.put(
				"TKSR023_SEL_001",
			    "SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME "
			    + "FROM  "
			    +    "TKSR023WK AS TKSR023WK_1 "
		    );
		paramMap.put(
				"TKSR023_SEL_001",
				new String[] {}
			);

		// TKSR023_SEL_002
		sqlMap.put(
				"TKSR023_SEL_002",
				"SELECT "
			    +    "BKN_NO, "
			    +    "KYK_NO, "
			    +    "KBT, "
			    +    "SHYU, "
			    +    "KYK, "
			    +    "UPD, "
			    +    "TDFK_CD, "
			    +    "OLD_SYSH_TDFK_CD, "
			    +    "KYKSH_TDFK_CD, "
			    +    "BKN_OOA_TSH_CD, "
			    +    "OLD_SYSH_OOA_TSH_CD, "
			    +    "KYKSH_OOA_TSH_CD, "
			    +    "TDFK_NAME, "
			    +    "OOA_TSH_NAME, "
			    +    "OLD_SYSH_OOA_TSH_NAME, "
			    +    "KYKSH_OOA_TSH_NAME, "
			    +    "BKN_ACM, "
			    +    "OLD_SYSH_ACM, "
			    +    "KYKSH_ACM, "
			    +    "KYKSH_ADD_YUB_NO_UP_3, "
			    +    "KYKSH_ADD_YUB_NO_DWN_4 "
			    + "FROM  "
			    +    "TKSR023WK2 AS TKSR023WK2_1 "
			    + "WHERE "
			    +    "TKSR023WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR023WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );
		paramMap.put(
				"TKSR023_SEL_002",
				new String[] {"CHOHY_RNO_W01"}
			);

		// TKSR024_SELECT_001 SQL
		// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
		sqlMap.put(
		"TKSR024_SELECT_001",
		"SELECT "
		    +    "CHOHY_RNO, "
		    +    "SFSK_CD, "
		    +    "SFSK_NAME, "
		    +    "NOW_DATE, "
		    +    "CMPY_NAME "
		    + "FROM  "
		    +    "TKSR024WK AS TKSR024WK_1 "
		    + "ORDER BY "
		    +    "TKSR024WK_1.CHOHY_RNO ASC  "
		    );
		paramMap.put(
				"TKSR024_SELECT_001",
				new String[] {}
			);
		/** TKSR024_SELECT_002 SQL .*/
		// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
		sqlMap.put(
		    "TKSR024_SELECT_002 ",
		    "SELECT "
			    +    "BKN_NO, "
			    +    "KYK_NO, "
			    +    "KBT, "
			    +    "SHYU, "
			    +    "KYK, "
			    +    "UPD, "
			    +    "ERR_MSG, "
			    +    "TDFK_CD, "
			    +    "BKN_OOA_TSH_CD, "
			    +    "TDFK_NAME, "
			    +    "OOA_TSH_NAME, "
			    +    "ACM, "
			    +    "SSE_IM_ADD "
			    + "FROM  "
			    +    "TKSR024WK2 AS TKSR024WK2_1 "
			    + "WHERE "
			    +    "TKSR024WK2_1.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +    "TKSR024WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );

		paramMap.put(
				"TKSR024_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);

		/** TKSR025_SELECT_001 SQL .*/
		// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
		sqlMap.put(
		"TKSR025_SELECT_001 ",
		    "SELECT "
		    +    "CHOHY_RNO, "
		    +    "SFSK_CD, "
		    +    "SFSK_NAME, "
		    +    "NOW_DATE, "
		    +    "CMPY_NAME "
		    + "FROM  "
		    +    "TKSR025WK AS TKSR025WK_1 "
		    );
		paramMap.put(
				"TKSR025_SELECT_001",
				new String[] {}
				);
		/** TKSR025_SELECT_002 SQL .*/
		// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
		sqlMap.put(
			"TKSR025_SELECT_002 ",
		    "SELECT "
		    +    "FURIS_SSN_NO, "
		    +    "FURIS_SSN_HJNO, "
		    +    "FURIM_SSN_NO, "
		    +    "WBS_YOS, "
		    +    "WBS_NAME, "
		    +    "FURI_KENME, "
		    +    "TRHK_S_TYP_SBT_CD, "
		    +    "TRHK_S_TYP_SBT, "
		    +    "YOT_DATE, "
		    +    "KO_KIN, "
		    +    "KDO_TES_YOT_DATE, "
		    +    "JOT_KO_KIN, "
		    +    "GYOM_KBN_NAME, "
		    +    "FURIM_SSN_HJNO, "
		    +    "YOT_NAIY, "
		    +    "ERR_INF "
		    + "FROM  "
		    +    "TKSR025WK2 AS TKSR025WK2_1 "
		    + "WHERE "
		    +    "TKSR025WK2_1.CHOHY_RNO = ? "
		    + "ORDER BY "
		    +    "TKSR025WK2_1.CHOHY_DTL_1_RNO ASC  "
		    );

		paramMap.put(
				"TKSR025_SELECT_002",
				new String[] {"CHOHY_RNO_W01"}
				);
		//
		sqlMap.put(
		  "TKSR026_SELECT_001",
		  "SELECT "
		    +    "CHOHY_RNO, "
		    +    "SFSK_CD, "
		    +    "SFSK_NAME, "
		    +    "NOW_DATE, "
		    +    "CMPY_NAME "
		    +"FROM  "
		    +    "TKSR026WK AS TKSR026WK_1 "
		    );
		paramMap.put(
				"TKSR026_SELECT_001",
				new String[] {}
				);
		//TKSR026_SELECT_002
				sqlMap.put(
					"TKSR026_SELECT_002",
					"SELECT "
				    +    "SSN_NO, "
				    +    "SSN_HJNO, "
				    +    "PRJ_DEF, "
				    +    "WBS_YOS, "
				    +    "WBS_TXT, "
				    +    "SETB_KAN_CD, "
				    +    "SETB_KAN_NAME, "
				    +    "GENK_CTR_CD, "
				    +    "GENK_CTR_NAME, "
				    +    "SSN_CALSS, "
				    +    "FST_SHK_DATE, "
				    +    "CTSH_KBN_1, "
				    +    "CTSH_KBN_NAME_1, "
				    +    "CTSH_KBN_2, "
				    +    "CTSH_KBN_NAME_2, "
				    +    "SHK_KIN_SUM_KIN, "
				    +    "TOS_ENJ_SUM_KIN, "
				    +    "KANJ_KNK "
				    +"FROM  "
				    +    "TKSR026WK2 AS TKSR026WK2_1 "
				    +"WHERE "
				    +    "TKSR026WK2_1.CHOHY_RNO = ? "
				    +"ORDER BY "
				    +    "TKSR026WK2_1.CHOHY_DTL_1_RNO ASC  "
					);
				paramMap.put(
						"TKSR026_SELECT_002",
						new String[] {"CHOHY_RNO_W01"}
						);
		// FKSR027
		// FKSR027_SELECT_001 SQL
		sqlMap.put(
		        "FKSR027_SELECT_001",
			    " SELECT "
			    +     " TKS.CHOHY_RNO, "
			    +     " TKS.SFSK_CD, "
			    +     " TKS.SFSK_NAME, "
			    +     " TKS.NOW_DATE, "
			    +     " TKS.CMPY_NAME "
			    + " FROM  "
			    +      " TKSR027WK AS TKS "
			    + " ORDER BY "
			    +      " TKS.CHOHY_RNO ASC "
		        );
		paramMap.put(
		        "FKSR027_SELECT_001",
		        new String[] {}
		        );

		// FKSR027_SELECT_002 SQL
		sqlMap.put(
		        "FKSR027_SELECT_002",
			    "SELECT "
			    +     "TKS2.CMPY_CD, "
			    +     "TKS2.CTY_CD, "
			    +     "TKS2.CTY_NAME, "
			    +     "TKS2.TCH_NO, "
			    +     "TKS2.IDO_DATE, "
			    +     "TKS2.IDO_SBT, "
			    +     "TKS2.CMK_KOB_NAME, "
			    +     "TKS2.CMK_GEK_NAME, "
			    +     "TKS2.YOT_CD, "
			    +     "TKS2.YOT_NAME, "
			    +     "TKS2.KMK_CD, "
			    +     "TKS2.KMK_NAME, "
			    +     "TKS2.MES_JOSSK, "
			    +     "TKS2.MES_KOB, "
			    +     "TKS2.SHK_KIN, "
			    +     "TKS2.SHK_Y, "
			    +     "TKS2.TKI_DATE, "
			    +     "TKS2.OOA_TSH_NAME, "
			    +     "TKS2.BKN_ACM, "
			    +     "TKS2.BNCH, "
			    +     "TKS2.TSK_H_UP_YOT_STE_CD, "
			    +     "TKS2.TSK_UP_YOT_STE, "
			    +     "TKS2.TCH_SHK_JIY_CD, "
			    +     "TKS2.TCH_SHK_JIY_NAME, "
			    +     "TKS2.KIT_NO, "
			    +     "TKS2.KIT_DATE, "
			    +     "TKS2.KAN_KENME_CD, "
			    +     "TKS2.TET_NO, "
			    +     "TKS2.OLD_SYSH_TDFK_NAME, "
			    +     "TKS2.OLD_SHYU_SHA__SKGCS_NAME, "
			    +     "TKS2.OLD_SYSH_OOA_TSH_NAME, "
			    +     "TKS2.OLD_SYSH_ACM, "
			    +     "TKS2.OLD_SHYU_SHA_BNCH, "
			    +     "TKS2.OLD_SYSH_NAME, "
			    +     "TKS2.TCH_IDO_NOTC_BKO "
			    + "FROM  "
			    +     "TKSR027WK2 AS TKS2 "
			    + "WHERE "
			    +     "TKS2.CHOHY_RNO = ? "
			    + "ORDER BY "
			    +     "TKS2.CHOHY_DTL_1_RNO ASC "
		        );

		// FKSR027_SELECT_002 �p�����[�^��`
		paramMap.put(
		        "FKSR027_SELECT_002",
		        new String[] {"CHOHY_RNO_W01"}
		        );

		// FKSR028_SELECT_001
		sqlMap.put(
				"FKSR028_SELECT_001",
				"SELECT "
			    +    "CHOHY_RNO, "
			    +    "SFSK_CD, "
			    +    "SFSK_NAME, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME, "
			    +    "CMPY_CD, "
			    +    "GENK_CTR, "
			    +    "GENK_CTR_CD, "
			    +    "SEKN_GENK_CTR, "
			    +    "SEKN_GENK_CTR_CD, "
			    +    "SSN_GRP_NAME, "
			    +    "SSN_GRP_CD, "
			    +    "SSN_NO, "
			    +    "SSN_HJNO, "
			    +    "FST_SHK_DATE, "
			    +    "ZENBB_KBN, "
			    +    "KDO_TES_YOT_DATE, "
			    +    "SHKO_YOT_DATE, "
			    +    "IDO_SBT, "
			    +    "PRJ_DEF, "
			    +    "PRJ_DEF_NAME, "
			    +    "KOJ_KENME, "
			    +    "KMK_CD, "
			    +    "KMK_NAME, "
			    +    "BU_KBN, "
			    +    "MES, "
			    +    "SZC_CD, "
			    +    "SZC_NAME, "
			    +    "BKN_CBN, "
			    +    "KAN_CD, "
			    +    "KAN_NAME, "
			    +    "SHIYO_KOZ, "
			    +    "SSN_TXT, "
			    +    "CMPY_NAME_DTL "
			    + "FROM  "
			    +    "TKSR028WK AS TKSR028WK_1 "
			    + "ORDER BY "
			    +    "TKSR028WK_1.CHOHY_RNO ASC  "
				);
		paramMap.put(
		        "FKSR028_SELECT_001",
		        new String[] {"CHOHY_RNO_W01"}
		        );

		// FKSR029_SELECT_001
		sqlMap.put(
				"FKSR029_SELECT_001",
				 "SELECT "
			    +    "CHOHY_RNO, "
			    +    "NOW_DATE, "
			    +    "CMPY_NAME, "
			    +    "DAI_KKSH_NAME, "
			    +    "JUT_KKSH_NAME, "
			    +    "KYKSH_ADD_YUB_NO_UP_3, "
			    +    "KYKSH_ADD_YUB_NO_DWN_4, "
			    +    "KYKSH_TDFK_NAME, "
			    +    "KYKSH_OOA_TSH_NAME, "
			    +    "KYKSH_ACM, "
			    +    "KYKSH_CBN, "
			    +    "KYKSH_NAME, "
			    +    "KYKSH_TEL_NO, "
			    +    "SEY_MES_SUM, "
			    +    "SEY_TNC_SUM, "
			    +    "SHKT_KIN_SUM "
			    + "FROM  "
			    +    "TKSR029WK AS TKSR029WK_1 "
			    + "ORDER BY "
			    +    "TKSR029WK_1.CHOHY_RNO ASC  "
			 );

		paramMap.put(
		        "FKSR029_SELECT_001",
		        new String[] {}
		        );

		// FKSR029_SELECT_002
		sqlMap.put(
				"FKSR029_SELECT_002",
				 "SELECT "
			    +    "CHOHY_RNO, "
			    +    "CHOHY_DTL_1_RNO, "
			    +    "KYK_NO, "
			    +    "SETB_KMK_NAME, "
			    +    "YOT_NAME, "
			    +    "KAN_NAME, "
			    +    "KKT_NAME, "
			    +    "SEY_SBT_NAME, "
			    +    "NEW_KYKA_NO, "
			    +    "NEW_KYKA_DATE, "
			    +    "TFST_KYKA_NO, "
			    +    "TFST_KYKA_DATE, "
			    +    "KYKA_KKN_STA, "
			    +    "KYKA_KKN_END, "
			    +    "BKN_NO, "
			    +    "CMK, "
			    +    "J2_SEY_KBN_NAME, "
			    +    "SEY_BSY_DHY_BKN, "
			    +    "SZC_1, "
			    +    "SZC_2, "
			    +    "SZC_3, "
			    +    "SZC_4, "
			    +    "SZC_5, "
			    +    "ETC_SU, "
			    +    "SHR_DATE, "
			    +    "SHR_SBT_NAME, "
			    +    "SHR_SKI, "
			    +    "SHR_TSH_KKN_ST, "
			    +    "SHR_TSH_KKN_EN, "
			    +    "SEY_KIN, "
			    +    "SHR_KANJ_KMK_NAME, "
			    +    "HMK_WBS, "
			    +    "HMK_WBS_NAME, "
			    +    "BU_KBN_NAME "
			    + "FROM  "
			    +    "TKSR029WK2 AS TKSR029WK2_1 "
			    + "ORDER BY "
			    +    "TKSR029WK2_1.CHOHY_DTL_1_RNO ASC  "
				);

		paramMap.put(
		        "FKSR029_SELECT_002",
		        new String[] {}
		        );


	    SQL_STR = Collections.unmodifiableMap(sqlMap);
		PARAM_ARR = Collections.unmodifiableMap(paramMap);
	};

	// ********************************************/
	/* Singleton�i�s�v�ȃC���X�^���X�̐������֎~�j                   */
	// ********************************************/
	/** Singleton�p�C���X�^���X�ێ��̈�. */
	private static BatchSQL sqlObj = new BatchSQL();

	/**
	 * BatchSQL�R���X�g���N�^.
	 */
	private BatchSQL() {
	}

	/**
	 * �C���X�^���X�擾���\�b�h.
	 * @return �C���X�^���X
	 */
	public static BatchSQL getInstance() {
		return sqlObj;
	}

	/**
	 * SQL��������擾���܂��B.
	 * @param name SQL���ʎq
	 * @return SQL������
	 */
	public String getSQLStatement(String name) {
		String statement = (String) SQL_STR.get(name);
		return statement;
	}

	/**
	 * SQL�p�����[�^�I�u�W�F�N�g���擾���܂��B.
	 * @param name SQL���ʎq
	 * @return SQL�p�����[�^�z��
	 */
	public String[] getParamObject(String name) {
		String[] param = (String[]) PARAM_ARR.get(name);
		return param;
	}
}
