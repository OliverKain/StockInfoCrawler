/**
 * FKSR008.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.batch.FKSR;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.energia.batch.common.dao.CommonDAO;
import jp.co.energia.batch.common.module.CommonModule;
import jp.co.energia.batch.common.util.StringUtil;
import jp.co.energia.batch.constants.Constants;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �ЗL�䒠���[�쐬�p�N���X�ł��B.
 * Ver.00.00.00 2018/3/22 : Y.Tani - Original
 */
public class FKSR008 {

	/** ���[ID�i�䒠�⎆�j. */
    public static final String REPORT_ID = "FKSR008";

    public static final String CHOHY_ID = "08";
	/** �R���X�g���N�^. */
	public FKSR008() { };

	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @throws Exception ��O
	 */
	public void makePintFile(CommonDAO dao) throws Exception {
		//���[�쐬�����iyyyyMMddHHmmss�j�擾
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());
		//���[�o�^�����iyyyyMMddHHmmssSSS�j�擾
		String trkTime = (new SimpleDateFormat(Constants.DATE_FMT_YYYYMMDDHHMMSSSSS)).format(new Date());

		List<Map<String, Object>> syuList = dao.getQueryResult(null, "FKSR008_SELECT_002");
		List<Map<String, Object>> listParams = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < syuList.size(); i++) {
			Map<String, Object> beanParam = new HashMap<String, Object>();
			beanParam.putAll(getHeaderData(syuList, i));
			beanParam.putAll(getDetailData(syuList, i));
			listParams.add(beanParam);
		}

		//���[�i�[�t�H���_�����݂��Ȃ��ꍇ�쐬
		CommonModule.createFolder(Constants.CHOHY_DIR_PATH + File.separator + "sfskCd" + File.separator + "kkshCd" + File.separator + REPORT_ID + File.separator + timeStr);

		//�o�͐�t�H���_
		String outFolder = Constants.CHOHY_DIR_PATH + File.separator + "sfskCd" + File.separator + "kkshCd" + File.separator + REPORT_ID + File.separator + timeStr;
		// �o�͐�t�@�C�����w�肷��B
		String outFile = outFolder + File.separator + getFileID(timeStr);
		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = Constants.TEMPLATE_DIR_PATH + File.separator + Constants.TEMPLATE_MAP.get(REPORT_ID);

		JasperPrint jasper = JasperFillManager.fillReport(
				templateFileName,
				new HashMap<String, Object>(),
				new JRBeanCollectionDataSource(listParams));
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		//DB�o�^
		Map<String, Object> repInfo = new HashMap<String, Object>();
		repInfo.put("CHOHY_ID", REPORT_ID);
		repInfo.put("CHOHY_PASS", outFile + ".pdf");
		repInfo.put("TOK_DATE", trkTime);
		repInfo.put("KKSH_CD", "1111");
		repInfo.put("SFSK_CD", "2222");
		repInfo.put("CHOHY_SBT", CHOHY_ID);
		repInfo.put("BATCH_ID", "FKSR08");
		CommonModule.creMakeRep(dao, repInfo);
	}

	/**
	 * �w�b�_�\�����e���擾���܂��B.
	 * @param syuList �ЗL�䒠���
	 * @param lineNum lineNum
	 * @return �w�b�_�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getHeaderData(List<Map<String, Object>> syuList, int lineNum) throws Exception {
		Map<String, Object> headerMap = new HashMap<String, Object>();
		Map<String, Object> sfskMap = syuList.get(lineNum);
		headerMap.put("FKSR008_001",  StringUtil.formatDate(new Date(), Constants.DATE_FORMAT_YYYYMMDD));
		headerMap.put("FKSR008_002", sfskMap.get("BKN_NO"));
		headerMap.put("FKSR008_003", sfskMap.get("KYK_NO"));
		// TODO FKSR008_SELECT_002 not select SYU_NO
		//headerMap.put("FKSR008_004", sfskMap.get("SYU_NO"));
		return headerMap;

	}

	/**
	 * �d���Ǘ����ו\�����e���擾���܂��B.
	 * @param syuList �ЗL�䒠���
	 * @param lineNum lineNum
	 * @return �d���Ǘ����ו\�����e���擾���܂��B.
	 * @throws Exception ��O
	 */
	private Map<String, Object> getDetailData(List<Map<String, Object>> syuList, int lineNum) throws Exception {
		Map<String, Object> detailChfkKnrData = new HashMap<String, Object>();
		//TODO FKSR008_SELECT_002 not select HOSHI
//		String str = (syuList.get(lineNum).get("SYU_TCH_HOSHI")).toString();
//		String strsyu = "";
//		for (int i = 0; i < str.length(); i++ ) {
//			if ((i > 0) && (i % 30 == 0)) {
//				strsyu += "\r\n" + str.charAt(i);
//			} else {
//				strsyu += str.charAt(i);
//			}
//		}
//		detailChfkKnrData.put("FKSR008_005" , strsyu);
		detailChfkKnrData.put("FKSR008_006" , syuList.get(lineNum).get("CMPY_NAME"));
		return detailChfkKnrData;
	}

	/**
	 * �t�@�C��ID���쐬���܂��B.
	 * @param time ���[�쐬����
	 * @return �t�@�C��ID
	 */
	private String getFileID(String time) {
		String fileId = REPORT_ID + time;
		return fileId;
	}

}

