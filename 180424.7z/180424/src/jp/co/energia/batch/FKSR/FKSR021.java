/**
 * FKSR0021.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.batch.FKSR;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.energia.batch.common.dao.CommonDAO;
import jp.co.energia.batch.common.module.CommonModule;
import jp.co.energia.batch.constants.Constants;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �ЗL�䒠���[�쐬�p�N���X�ł��B.
 * Ver.00.00.00 2018/04/18 : Nhimtt - Original
 */
public class FKSR021 {

	/**�����_�ȉ��Q���t�H�[�}�b�g.*/
	private static final String FORMAT_1 = "###,###,###,##0";

	/**�����_�ȉ��Q���t�H�[�}�b�g.*/
	private static final String FORMAT_2 = "#,###,##0";

	/**�����_�ȉ��Q���t�H�[�}�b�g.*/
	private static final String FORMAT_3 = "#,###,##0.00";

	/**���׍ő�s���i�P�y�[�W�ځj.*/
	private static final int RECORD_PAGE = 8;

	/** �Ȗ�_�敪��ʃR�[�h. */
	private static final String KYOG_KBN = "110";

	/** ���[ID�i�x�����׈ꗗ�\�j. */
	private static final String REPORT_ID = "FKSR021";

	/** ���[���. */
	private static final String CHOHY_SBT = "21";
	/** �R���X�g���N�^. */
	public FKSR021() { };


	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @param param param
	 * @throws Exception ��O
	 */
	public void makePintFile(CommonDAO dao, Map<String, Object> param ) throws Exception {
		//���[�쐬�����iyyyyMMddHHmmss�j�擾
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());
		//���[�o�^�����iyyyyMMddHHmmssSSS�j�擾
		String trkTime = (new SimpleDateFormat(Constants.DATE_FMT_YYYYMMDDHHMMSSSSS)).format(new Date());

		List<Map<String, Object>> syuList = dao.getQueryResult(null, "TKSR021_SELECT_001");
		param.put("CHOHY_RNO_W01", syuList.get(0).get("CHOHY_RNO"));
		List<Map<String, Object>> tksr021wk2 = dao.getQueryResult(param, "TKSR021_SELECT_002");
		List<Map<String, Object>> listParams = new ArrayList<Map<String, Object>>();

		int totalPage = ((tksr021wk2.size() - 1) / RECORD_PAGE) + 1;
		// ���ݕ�
		int currentPage = 1;

		if (syuList.size() > 0 && tksr021wk2.size() > 0) {
			//�Ǘ��ӏ��R�[�h
			String kkshCd = CommonModule.getKkshCd(dao, syuList.get(0).get("DAI_KKSH_NAME").toString());

			// �y���ו��z �ő�8�s
			for (int i = 0; i < tksr021wk2.size(); i++) {
				// Header
				Map<String, Object> beanParam = new HashMap<String, Object>();
				if (i % (RECORD_PAGE) == 0) {
					if (i > 0) {
						currentPage += 1;
					}
					beanParam.putAll(getHeaderData(syuList, totalPage, currentPage));
				}
				// Detail
				beanParam.putAll(getDetailData(dao, tksr021wk2, i));
				// Summary
				beanParam.putAll(getSummaryData(tksr021wk2));
				// Footer
				beanParam.putAll(getFooterData(syuList));
				listParams.add(beanParam);
			}
		// �o�͐�t�H���_
		String outFolder = Constants.CHOHY_DIR_PATH + File.separator + REPORT_ID + File.separator + timeStr;
		// ���[�i�[�t�H���_�����݂��Ȃ��ꍇ�쐬
		CommonModule.createFolder(outFolder);

		// �o�͐�t�@�C�����w�肷��B
		String outFile = outFolder + File.separator + getFileID(timeStr, kkshCd);
		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = Constants.TEMPLATE_DIR_PATH + File.separator + Constants.TEMPLATE_MAP.get(REPORT_ID);

		// �o�̓t�@�C��������ɍ쐬�ł��Ă��邱�ƁB
		JasperPrint jasper = JasperFillManager.fillReport(templateFileName, new HashMap<String, Object>(), new JRBeanCollectionDataSource(listParams));
		// ����C���[�W��PDF�t�@�C���ɏo�͂���B
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		//DB�o�^
		Map<String, Object> repInfo = new HashMap<String, Object>();
		repInfo.put("CHOHY_ID", REPORT_ID);
		repInfo.put("CHOHY_PASS", outFile + ".pdf");
		repInfo.put("TOK_DATE", trkTime);
		repInfo.put("KKSH_CD", "1111");
		repInfo.put("SFSK_CD", "2222");
		repInfo.put("CHOHY_SBT", "08");
		repInfo.put("BATCH_ID", CHOHY_SBT);
		CommonModule.creMakeRep(dao, repInfo);
		}
	}

	/**
	 * �w�b�_�\�����e���擾���܂��B.
	 * @param syuList �ЗL�䒠���
	 * @param totalPage �񍐏����̃y�[�W�̍��v
	 * @param currentPage �񍐏����̌��݂̃y�[�W
	 * @return �w�b�_�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getHeaderData(List<Map<String, Object>> syuList, int totalPage, int currentPage) throws Exception {
		Map<String, Object> headerMap = new HashMap<String, Object>();
		Map<String, Object> map = syuList.get(0);
		headerMap.put("FKSR021_001", map.get("SFSK_CD"));
		headerMap.put("FKSR021_002", map.get("SFSK_NAME"));
		headerMap.put("FKSR021_003", map.get("GNB_KKSH_NAME"));
		headerMap.put("FKSR021_004", map.get("DAI_KKSH_NAME"));
		headerMap.put("FKSR021_005", CommonModule.formatJPKanjiMonth(CommonModule.cnvStr(map.get("NOW_DATE"))));
		headerMap.put("FKSR021_006", String.valueOf(currentPage));
		headerMap.put("FKSR021_007", String.valueOf(totalPage));
		return headerMap;

	}

	/**
	 * ���Ǘ����ו\�����e���擾���܂��B.
	 * @param dao DAO
	 * @param listData �d���Ǘ����
	 * @param lineNum ���C���ԍ�
	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getDetailData(CommonDAO dao, List<Map<String, Object>> listData, int lineNum) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();
		Map<String, Object> map = listData.get(lineNum);

		String kanName = (map.get("KAN_NAME")).toString();
		String wbsname = (map.get("WBS_NAME")).toString();
		String kykshTdfkName = ( map.get("KYKSH_TDFK_NAME")).toString();

		detailData.put("FKSR021_101", map.get("KYK_NO"));
		detailData.put("FKSR021_102", map.get("SETB_KMK_NAME"));
		detailData.put("FKSR021_103", map.get("YOT_NAME"));
		detailData.put("FKSR021_104", kanName + wbsname);
		detailData.put("FKSR021_105", CommonModule.formatJPEijiYMD(map.get("UKB_DATE").toString()));
		detailData.put("FKSR021_106", map.get("SHR_SBT_NAME"));
		detailData.put("FKSR021_107", map.get("SHR_SKI_NAME"));
		detailData.put("FKSR021_108", CommonModule.formatJPEijiYMD(map.get("UKB_TSH_KKN_ST").toString()));
		detailData.put("FKSR021_109", CommonModule.formatJPEijiYMD(map.get("UKB_TSH_KKN_EN").toString()));
		detailData.put("FKSR021_110", map.get("SHR_KMK"));
		detailData.put("FKSR021_111", CommonModule.getKbn(dao, KYOG_KBN, ((String) (map.get("KYOG_TNK_KBN")))));
		detailData.put("FKSR021_112", CommonModule.decimalFormat(
				new BigDecimal(map.get("SHKT_SUM_MES").toString()), FORMAT_3));
		detailData.put("FKSR021_113", CommonModule.decimalFormat(
				new BigDecimal(map.get("TND_KYOG_TNK").toString()), FORMAT_2));
		detailData.put("FKSR021_114", CommonModule.decimalFormat(
				new BigDecimal(map.get("TND_SHKT_KIN").toString()), FORMAT_1));
		detailData.put("FKSR021_115", CommonModule.decimalFormat(
				new BigDecimal(map.get("YKND_KYOG_TNK").toString()), FORMAT_2));
		detailData.put("FKSR021_116", CommonModule.decimalFormat(
				new BigDecimal(map.get("YKND_SHKT_SHO").toString()), FORMAT_1));
		detailData.put("FKSR021_117", map.get("UKB_AIT_NAME"));
		detailData.put("FKSR021_118", map.get("KYKKN_NAME"));
		detailData.put("FKSR021_119", map.get("YKIN_SBT"));
		detailData.put("FKSR021_120", map.get("KOZ_NO"));
		detailData.put("FKSR021_121", map.get("KOZ_MEGNIN"));
		detailData.put("FKSR021_122", map.get("KYKSH_ADD_YUB_NO_UP_3"));
		detailData.put("FKSR021_123", map.get("KYKSH_ADD_YUB_NO_DWN_4"));
		detailData.put("FKSR021_124", kykshTdfkName.substring(0, 4));
		detailData.put("FKSR021_125", kykshTdfkName.substring(4, 16));
		detailData.put("FKSR021_126", map.get("KYKSH_OOA_TSH_NAME"));
		detailData.put("FKSR021_127", map.get("KYKSH_ACM"));
		detailData.put("FKSR021_128", map.get("KYKSH_CBN"));
		return detailData;
	}

	/**
	 * �t�b�^�\�����e���擾���܂��B.
	 * @param listData ���t����
	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFooterData(List<Map<String, Object>> listData) throws Exception {
		Map<String, Object> footerMap = new HashMap<String, Object>();
		Map<String, Object> map = listData.get(0);
		footerMap.put("FKSR021_301", map.get("CMPY_NAME"));
		return footerMap;
	}

	/**
	 * �t�b�^�\�����e���擾���܂��B.
	 * @param listData ���t����
	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getSummaryData(List<Map<String, Object>> listData) throws Exception {
		Map<String, Object> summaryMap = new HashMap<String, Object>();
		BigDecimal totalTndShktKin = new BigDecimal(BigInteger.ZERO);
		BigDecimal totalYkndShktSho = new BigDecimal(BigInteger.ZERO);

		for (int i = 0; i < listData.size(); i++) {
			BigDecimal tndShktKin = new BigDecimal(listData.get(i).get("TND_SHKT_KIN").toString());
			totalTndShktKin = totalTndShktKin.add(tndShktKin);
			BigDecimal ykndShktSho = new BigDecimal(listData.get(i).get("YKND_SHKT_SHO").toString());
			totalYkndShktSho = totalYkndShktSho.add(ykndShktSho);
		}
		summaryMap.put("FKSR021_201", CommonModule.decimalFormat(totalTndShktKin, FORMAT_1));
		summaryMap.put("FKSR021_202", CommonModule.decimalFormat(totalYkndShktSho, FORMAT_1));
		summaryMap.put("FKSR021_203", CommonModule.decimalFormat(totalYkndShktSho.subtract(totalTndShktKin), FORMAT_1));
		return summaryMap;
	}

	/**
	 * �t�@�C��ID���쐬���܂��B.
	 * �t�@�C��ID = ���[ID_���t(�N���������b)
	 * @param time ���[�쐬����
	 * @param kkshCd kkshCd
	 * @return �t�@�C��ID
	 */
	private String getFileID(String time, String kkshCd ) {
		String fileId = REPORT_ID + "_" + time + "_" + kkshCd;
		return fileId;
	}

}

