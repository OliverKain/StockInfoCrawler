/**
 * CheckSQL.java
 * All Rights Reserved.Copyright�@2017,Energia�@Communications.Inc
 */
package jp.co.energia.apl.common.sql;

import jp.co.enecom.framework.dao.AbstractSQLObject;
import jp.co.enecom.framework.dao.SQLObjectInterface;

/**
 * �`�F�b�N�����Ŏg�p����SQL���`����N���X�ł��B.
 * <p>
 * Ver.00.00.00 2017/12/25 : S.Akashi - Original
 */
public final class CheckSQL extends AbstractSQLObject {

	// ********************************************/
	/* Singleton�i�s�v�ȃC���X�^���X�̐������֎~�j*/
	// ********************************************/
	/** Singleton�p�C���X�^���X�ێ��̈�. */
	private static SQLObjectInterface sqlObj = new CheckSQL();

	/**
	 * CheckSQL�R���X�g���N�^.
	 */
	private CheckSQL() {
		super();
	}

	/** E0006_SEL_001 SQL .*/
	public static final String SQL_$E0006_SEL_001 =
	  "SELECT "
	  +  "USR_ID "
	  + "FROM  "
	  +  "R_RIYO_USR AS R_RIYO_USR_1 "
	  + "WHERE "
	  +  "R_RIYO_USR_1.USR_ID = ? ";

	/** E0006_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0006_SEL_001 = {"USR_ID_W01"};

	/** E0007_SEL_001 SQL .*/
	public static final String SQL_$E0007_SEL_001 =
	  "SELECT "
	  +  "COUNT(*) "
	  + "FROM  "
	  +  "E_SYU_TOK AS E_SYU_TOK_1 "
	  +  "INNER JOIN "
	  +    "E_SYU_BOK_RRK_SSE_DTL AS E_SYU_BOK_RRK_SSE_DTL_1 "
	  +  "  ON E_SYU_TOK_1.SYU_TOK_NO = E_SYU_BOK_RRK_SSE_DTL_1.SYU_TOK_NO "
	  + "WHERE "
	  +  "E_SYU_TOK_1.SYU_NO = ? "
	  +  "AND E_SYU_TOK_1.BKN_NO = ? ";

	/** E0007_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0007_SEL_001 = {"SYU_NO_W01", "BKN_NO_W01"};

	/** E0007_SEL_002 SQL .*/
	public static final String SQL_$E0007_SEL_002 =
	 "SELECT "
      +  "COUNT(*) "
      + "FROM  "
      +  "E_SYU_TOK AS E_SYU_TOK_1 "
      +  "INNER JOIN "
      +    "E_SYU_TOK_BKO_DTL AS E_SYU_TOK_BKO_DTL_1 ON  "
      +    "E_SYU_TOK_1.SYU_TOK_NO = E_SYU_TOK_BKO_DTL_1.SYU_TOK_NO "
      + "WHERE "
      +  "E_SYU_TOK_1.SYU_NO = ? ";

	/** E0007_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E0007_SEL_002 = {"SYU_NO_W01"};

	/** E0007_SEL_003 SQL .*/
	public static final String SQL_$E0007_SEL_003 =
	  "SELECT "
	  +  "COUNT(*) "
	  + "FROM  "
	  +  "R_SYU_TCH AS R_SYU_TCH_1 "
	  + "WHERE "
	  +  "R_SYU_TCH_1.SYU_NO = ? "
	  +  "AND R_SYU_TCH_1.BKN_NO = ? ";

	/** E0007_SEL_003 �p�����[�^��` .*/
	public static final String[] PARAM_$E0007_SEL_003 = {"SYU_NO_W01", "BKN_NO_W01"};

	/** E0007_SEL_004 SQL .*/
	public static final String SQL_$E0007_SEL_004 =
	  "SELECT "
	  +  "COUNT(*) "
	  + "FROM  "
	  +  "E_KAS_TOK AS E_KAS_TOK_1 "
	  +  "INNER JOIN "
	  +    "E_KAS_BKO_DTL AS E_KAS_BKO_DTL_1 "
	  +  "  ON E_KAS_TOK_1.KAS_TOK_NO = E_KAS_BKO_DTL_1.KAS_TOK_NO "
	  + "WHERE "
	  +  "E_KAS_TOK_1.KYK_NO = ? ";

	/** E0007_SEL_004 �p�����[�^��` .*/
	public static final String[] PARAM_$E0007_SEL_004 = {"KYK_NO_W01"};

	/** E0007_SEL_005 SQL .*/
	public static final String SQL_$E0007_SEL_005 =
	  "SELECT "
	  +  "COUNT(*) "
	  + "FROM  "
	  +  "R_KAS AS R_KAS_1 "
	  +  "INNER JOIN "
	  +    "R_KYK_BKN AS R_KYK_BKN_1 "
	  +  "  ON R_KAS_1.KYK_NO = R_KYK_BKN_1.KYK_NO "
	  + "WHERE "
	  +  "R_KAS_1.KYK_NO = ? ";

	/** E0007_SEL_005 �p�����[�^��` .*/
	public static final String[] PARAM_$E0007_SEL_005 = {"KYK_NO_W01"};




	/** E0105_SEL_001 SQL .*/
	public static final String SQL_$E0105_SEL_001 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.SYU_NO LIKE ? AND "
	  +  "R_BOK_ZAN_KIN_1.BKN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? ";

	/** E0105_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0105_SEL_001 = {"SYU_NO_W01", "BKN_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01"};

	/** E0107_SEL_001 SQL .*/
	public static final String SQL_$E0107_SEL_001 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.SYU_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0107_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0107_SEL_001 = {"SYU_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0107_SEL_002 SQL .*/
	public static final String SQL_$E0107_SEL_002 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.BKN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0107_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E0107_SEL_002 = {"BKN_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0108_SEL_001 SQL .*/
	public static final String SQL_$E0108_SEL_001 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_SSN AS R_SSN_1 "
	  + "WHERE "
	  +  "R_SSN_1.SSN_NO = ? AND "
	  +  "R_SSN_1.SSN_HJNO = ? AND "
	  +  "R_SSN_1.SSN_FST_SHK_YM = ? AND "
	  +  "R_SSN_1.SSN_MKO_DATE = ' ' ";

	/** E0108_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0108_SEL_001 = {"SSN_NO_W01", "SSN_HJNO_W01", "SSN_FST_SHK_YM_W01"};

	/** E0109_SEL_001 SQL .*/
	public static final String SQL_$E0109_SEL_001 =
	  "SELECT "
	  +  "SYU_NO "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.SYU_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0109_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0109_SEL_001 = {"SYU_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0109_SEL_002 SQL .*/
	public static final String SQL_$E0109_SEL_002 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.BKN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0109_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E0109_SEL_002 = {"BKN_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0110_SEL_001 SQL .*/
	public static final String SQL_$E0110_SEL_001 =
	  "SELECT "
	  +  "SYU_NO "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.SYU_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0110_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0110_SEL_001 = {"SYU_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0111_SEL_001 SQL .*/
	public static final String SQL_$E0111_SEL_001 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_SSN AS R_SSN_1 "
	  + "WHERE "
	  +  "R_SSN_1.SSN_NO = ? AND "
	  +  "R_SSN_1.SSN_HJNO = ? AND "
	  +  "R_SSN_1.SSN_MKO_DATE = ' ' ";

	/** E0111_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0111_SEL_001 = {"SSN_NO_W01", "SSN_HJNO_W01"};

	/** E0112_SEL_001 SQL .*/
	public static final String SQL_$E0112_SEL_001 =
	  "SELECT "
	  +  "SYU_NO "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.SYU_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0112_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E0112_SEL_001 = {"SYU_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E0112_SEL_002 SQL .*/
	public static final String SQL_$E0112_SEL_002 =
	  "SELECT "
	  +  "* "
	  + "FROM  "
	  +  "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	  + "WHERE "
	  +  "R_BOK_ZAN_KIN_1.BKN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_NO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SSN_HJNO = ? AND "
	  +  "R_BOK_ZAN_KIN_1.SHK_KAIKE_KICHO_DATE = ? ";

	/** E0112_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E0112_SEL_002 = {"BKN_NO_W01", "SSN_NO_W01", "SSN_HJNO_W01", "SHK_KAIKE_KICHO_DATE_W01"};

	/** E2005_SEL_001 SQL .*/
	public static final String SQL_$E2005_SEL_001 =
	    "SELECT "
   	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_SETBKJ_TCH AS R_SETBKJ_TCH_1 "
	    + "WHERE "
	    +    "R_SETBKJ_TCH_1.SSN_NO = ? "
	    +    "AND R_SETBKJ_TCH_1.SSN_HJNO = ? "
	    +    "AND R_SETBKJ_TCH_1.SETBKJ_KJO_KBN = ? "
	    +    "AND R_SETBKJ_TCH_1.SETBKJ_DTL_TANI_FURI_DATE = ? ";

	/** E2005_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E2005_SEL_001 = {"SSN_NO_W01", "SSN_HJNO_W01", "SETBKJ_KJO_KBN_W01", "SETBKJ_DTL_TANI_FURI_DATE_W01"};

	/** E2009_SEL_001 SQL .*/
	public static final String SQL_$E2009_SEL_001 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_SYU_IDO_RRK AS R_SYU_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_SYU_IDO_RRK_1.SYU_NO = ? "
	    +    "AND R_SYU_IDO_RRK_1.SYU_IDO_RRK_RNO = ? ";

	/** E2009_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E2009_SEL_001 = {"SYU_NO_W01", "SYU_IDO_RRK_RNO_W01"};

	/** E2009_SEL_002 SQL .*/
	public static final String SQL_$E2009_SEL_002 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_CECJ_IDO_RRK AS R_CECJ_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_CECJ_IDO_RRK_1.KYK_NO = ? "
	    +    "AND R_CECJ_IDO_RRK_1.CECJ_IDO_RNO = ? ";

	/** E2009_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E2009_SEL_002 = {"KYK_NO_W01", "CECJ_IDO_RNO_W01"};

	/** E2009_SEL_003 SQL .*/
	public static final String SQL_$E2009_SEL_003 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_KAS_IDO_RRK AS R_KAS_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_KAS_IDO_RRK_1.KYK_NO = ? "
	    +    "AND R_KAS_IDO_RRK_1.KAS_IDO_RNO = ? ";

	/** E2009_SEL_003 �p�����[�^��` .*/
	public static final String[] PARAM_$E2009_SEL_003 = {"KYK_NO_W01", "KAS_IDO_RNO_W01"};

	/** E2009_SEL_004 SQL .*/
	public static final String SQL_$E2009_SEL_004 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_KRUK_IDO_RRK AS R_KRUK_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_KRUK_IDO_RRK_1.KYK_NO = ? "
	    +    "AND R_KRUK_IDO_RRK_1.KRUK_IDO_RNO = ? ";

	/** E2009_SEL_004 �p�����[�^��` .*/
	public static final String[] PARAM_$E2009_SEL_004 = {"KYK_NO_W01", "KRUK_IDO_RNO_W01"};

	/** E2009_SEL_004 SQL .*/
	public static final String SQL_$E2009_SEL_005 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_SEY_IDO_RRK AS R_SEY_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_SEY_IDO_RRK_1.KYK_NO = ? "
	    +    "AND R_SEY_IDO_RRK_1.SEY_IDO_RNO = ? ";

	/** E2009_SEL_004 �p�����[�^��` .*/
	public static final String[] PARAM_$E2009_SEL_005 = {"KYK_NO_W01", "SEY_IDO_RNO_W01"};

	/** E2011_SEL_001 SQL .*/
	public static final String SQL_$E2011_SEL_001 =
	    "SELECT "
	    +    "KYK_DATE "
	    + "FROM  "
	    +    "R_CECJ AS R_CECJ_1 "
	    + "WHERE "
	    +    "R_CECJ_1.KYK_NO = ? ";

	/** E2011_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E2011_SEL_001 = {"KYK_NO_W01"};

	/** E2011_SEL_002 SQL .*/
	public static final String SQL_$E2011_SEL_002 =
	    "SELECT "
	    +    "KYK_DATE "
	    + "FROM  "
	    +    "R_KRUK AS R_KRUK_1 "
	    + "WHERE "
	    +    "R_KRUK_1.KYK_NO = ? ";

	/** E2011_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$E2011_SEL_002 = {"KYK_NO_W01"};

	/** E2011_SEL_003 SQL .*/
	public static final String SQL_$E2011_SEL_003 =
	    "SELECT "
	    +    "KYK_DATE "
	    + "FROM  "
	    +    "R_KAS AS R_KAS_1 "
	    + "WHERE "
	    +    "R_KAS_1.KYK_NO = ? ";

	/** E2011_SEL_003 �p�����[�^��` .*/
	public static final String[] PARAM_$E2011_SEL_003 = {"KYK_NO_W01"};

	/** E2011_SEL_004 SQL .*/
	public static final String SQL_$E2011_SEL_004 =
	    "SELECT "
	    +    "KYKA_DATE "
	    + "FROM  "
	    +    "R_SEY AS R_SEY_1 "
	    + "WHERE "
	    +    "R_SEY_1.KYK_NO = ? ";

	/** E2011_SEL_004 �p�����[�^��` .*/
	public static final String[] PARAM_$E2011_SEL_004 = {"KYK_NO_W01"};

	/** E9002_SEL_001 SQL .*/
	public static final String SQL_$E9002_SEL_001 =
	    "SELECT "
	    +    "COUNT(*) AS COUNT "
	    + "FROM  "
	    +    "R_SHRCHS_TSH_YND AS R_SHRCHS_TSH_YND_1 "
	    + "WHERE "
	    +    "R_SHRCHS_TSH_YND_1.SHRCHS_TSH_YND = ? "
	    +    "AND R_SHRCHS_TSH_YND_1.KAKTE_KBN ='1' ";

	/** E9002_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E9002_SEL_001 = {"SHRCHS_TSH_YND_W01"};

	/** E9003_SEL_001 SQL .*/
	public static final String SQL_$E9003_SEL_001 =
	    "SELECT "
        +    "COUNT(*) AS COUNT "
        + "FROM  "
	    +    "R_SHRCHS_TSH_YND AS R_SHRCHS_TSH_YND_1 "
	    + "WHERE "
	    +    "R_SHRCHS_TSH_YND_1.SHRCHS_TSH_YND = ? "
	    +    "AND R_SHRCHS_TSH_YND_1.KAKTE_KBN != '1' ";

	/** E9003_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$E9003_SEL_001 = {"SHRCHS_TSH_YND_W01"};

	/**
	 * �C���X�^���X�擾���\�b�h.
	 * @return �C���X�^���X
	 */
	public static SQLObjectInterface getInstance() {
		return sqlObj;
	}
}
