/**
 * PrintSQL.java
 * All Rights Reserved.Copyright�@2017,Energia�@Communications.Inc
 */
package jp.co.energia.apl.common.sql;

import jp.co.enecom.framework.dao.AbstractSQLObject;
import jp.co.enecom.framework.dao.SQLObjectInterface;

/**
 * ���[�o�͂Ŏg�p����SQL���`����N���X�ł��B.
 * <p>
 * Ver.00.00.00 2017/12/25 : S.Akashi - Original
 */
public final class PrintSQL extends AbstractSQLObject {

	// ********************************************/
	/* Singleton�i�s�v�ȃC���X�^���X�̐������֎~�j*/
	// ********************************************/
	/** Singleton�p�C���X�^���X�ێ��̈�. */
	private static SQLObjectInterface sqlObj = new PrintSQL();

	/**
	 * �R���X�g���N�^.
	 */
	private PrintSQL() {
		super();
	}

	//FKSR001
	/** FKSR001_SEL_001 SQL .*/
	public static final String SQL_$FKSR001_SEL_001 =
	    "SELECT "
	    +    "R_BKN_1.TDFK_NAME, "
	    +    "R_BKN_1.OOA_TSH_NAME, "
	    +    "R_BKN_1.BKN_ACM, "
	    +    "R_BKN_1.BKN_CBN, "
	    +    "R_BKN_1.TET_NO_NO || '-' || R_BKN_1.TET_NO_DNO AS TET_NO, "
	    +    "R_BKN_1.CMK_KOB_KBN, "
	    +    "R_BKN_1.CMK_GEK_KBN, "
	    +    "R_BKN_1.MES_KOB, "
	    +    "R_BKN_1.OLD_SYSH_TDFK_NAME, "
	    +    "R_BKN_1.OLD_SYSH_OOA_TSH_NAME, "
	    +    "R_BKN_1.OLD_SYSH_ACM, "
	    +    "R_BKN_1.OLD_SYSH_CBN, "
	    +    "R_BKN_1.OLD_SYSH_NAME, "
	    +    "R_BKN_1.KNRI_SBT, "
	    +    "R_BKN_1.SHK_JIY_KBN, "
	    +    "R_BKN_1.SHK_DATE, "
	    +    "R_BKN_1.TKI_DATE, "
	    +    "R_BKN_1.MTKIT_RYU_KBN, "
	    +    "R_BKN_1.TKSS_KBN, "
	    +    "R_BKN_1.KYKS_KBN, "
	    +    "R_BKN_1.JOSSK_Z_KBN, "
	    +    "R_BKN_1.TSK_YOT_KBN, "
	    +    "R_BKN_1.KYYU_MCBN_BUNS, "
	    +    "R_BKN_1.KYYU_MCBN_BUIB, "
	    +    "R_SYU_TCH_1.SYU_NO, "
	    +    "R_SYU_TCH_1.BKN_NO, "
	    +    "R_SYU_TCH_1.DAI_KKSH_CD, "
	    +    "R_SYU_TCH_1.DAI_KKSH_NAME, "
	    +    "R_SYU_TCH_1.GNB_KKSH_NAME, "
	    +    "R_SYU_TCH_1.JUT_KKSH_NAME, "
	    +    "R_SYU_TCH_1.KMK_CD, "
	    +    "R_SYU_TCH_1.YOT_CD, "
	    +    "R_SYU_TCH_1.GENK_CTR_NAME, "
	    +    "R_SYU_TCH_1.WBS_YOS, "
	    +    "R_SYU_TCH_1.WBS_NAME, "
	    +    "R_SYU_TCH_1.KAN_CD, "
	    +    "R_SYU_TCH_1.KAN_NAME, "
	    +    "R_SYU_TCH_1.KKT_CD, "
	    +    "R_SYU_TCH_1.KKT_NAME, "
	    +    "R_SYU_TCH_1.RIT_KIT_NO, "
	    +    "R_SYU_TCH_1.RIT_KIT_DATE, "
	    +    "R_SYU_TCH_1.MES_JOSSK, "
	    +    "R_SYU_TCH_1.SYU_KENCH_KBN, "
	    +    "R_SYU_TCH_1.SHK_KIN, "
	    +    "R_SYU_TCH_1.JOSO_DIS_KBN, "
	    +    "R_SYU_TCH_1.SSN_NO, "
	    +    "R_SYU_TCH_1.SNH_KBN, "
	    +    "R_KKT_1.KKT_NAME AS DHY_KKT_NAME, "
	    +    "R_KKT_1.DHY_KKT_KAN_CD || '-' || R_KKT_1.DHY_KKT_KKK_CD AS DHY_KKT_CD "
	    + "FROM  "
	    +    "R_BKN AS R_BKN_1 "
	    +    "INNER JOIN "
	    +        "R_SYU_TCH AS R_SYU_TCH_1 "
	    +    "    ON R_BKN_1.BKN_NO = R_SYU_TCH_1.BKN_NO "
	    +    "INNER JOIN "
	    +        "R_KKT AS R_KKT_1 "
	    +    "    ON R_SYU_TCH_1.KAN_CD = R_KKT_1.KAN_CD "
	    +    "AND R_SYU_TCH_1.KAN_CD = R_KKT_1.KAN_CD "
	    + "WHERE "
	    +    "R_SYU_TCH_1.SYU_NO = ? "
	    + "ORDER BY R_SYU_TCH_1.SYU_NO";

	/** FKSR001_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_001 = {"SYU_NO_W01"};

	/** FKSR001_SEL_007 SQL .*/
	public static final String SQL_$FKSR001_SEL_007 =
	    "SELECT "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "V_SFSK_CMPY AS V_SFSK_CMPY_1 "
	    + "WHERE "
	    +    "V_SFSK_CMPY_1.JGSH_CD = ? ";

	/** FKSR001_SEL_007 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_007 = {"DAI_KKSH_CD_W01"};

	/** FKSR001_SEL_002 SQL .*/
	public static final String SQL_$FKSR001_SEL_002 =
	    "SELECT "
	    +    "KAIKE_KICHO_DATE "
	    + "FROM  "
	    +    "R_SYU_BOK_RRK AS R_SYU_BOK_RRK_1 "
	    + "WHERE "
	    +    "R_SYU_BOK_RRK_1.SYU_NO = ? ";

	/** FKSR001_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_002 = {"SYU_NO_W01"};

	/** FKSR001_SEL_003 SQL .*/
	public static final String SQL_$FKSR001_SEL_003 =
	    "SELECT "
	    +    "SUM(CHOB_GENK_ZAN_KIN) AS CHOB_GENK_ZAN_KIN, "
	    +    "SUM(FUTKIN) AS FUTKIN, "
	    +    "SUM(GENS_SONS_SUM_KIN) AS GENS_SONS_SUM_KIN "
	    + "FROM  "
	    +    "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	    + "WHERE "
	    +    "R_BOK_ZAN_KIN_1.SYU_NO = ? "
	    +    "AND R_BOK_ZAN_KIN_1.BKN_NO = ? "
	    +    "AND R_BOK_ZAN_KIN_1.SSN_NO = ? "
	    + "GROUP BY "
	    +    "R_BOK_ZAN_KIN_1.SYU_NO, "
	    +    "R_BOK_ZAN_KIN_1.BKN_NO, "
	    +    "R_BOK_ZAN_KIN_1.SSN_NO ";

	/** FKSR001_SEL_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_003 = {"SYU_NO_W01", "BKN_NO_W01", "SSN_NO_W01"};

	/** FKSR001_SEL_004 SQL .*/
	public static final String SQL_$FKSR001_SEL_004 =
	    "SELECT "
	    +    "R_BKN_1.MES_KOB, "
	    +    "R_SYU_TCH_1.SYU_NO, "
	    +    "R_SYU_TCH_1.DAI_KKSH_NAME, "
	    +    "R_SYU_TCH_1.GNB_KKSH_NAME, "
	    +    "R_SYU_TCH_1.KMK_CD, "
	    +    "R_SYU_TCH_1.GENK_CTR_NAME, "
	    +    "R_SYU_TCH_1.WBS_YOS, "
	    +    "R_SYU_TCH_1.WBS_NAME, "
	    +    "R_SYU_TCH_1.KAN_CD, "
	    +    "R_SYU_TCH_1.KAN_NAME, "
	    +    "R_SYU_TCH_1.MES_JOSSK, "
	    +    "R_SYU_TCH_1.SNH_KBN, "
	    +    "R_SYU_TCH_1.SSN_NO "
	    + "FROM  "
	    +    "R_BKN AS R_BKN_1 "
	    +    "INNER JOIN "
	    +        "R_SYU_TCH AS R_SYU_TCH_1 "
	    +    "    ON R_BKN_1.BKN_NO = R_SYU_TCH_1.BKN_NO "
	    + "WHERE "
	    +    "R_SYU_TCH_1.SYU_NO <> ? "
	    +    "AND R_SYU_TCH_1.BKN_NO = ? "
	    + "ORDER BY R_SYU_TCH_1.SYU_NO";

	/** FKSR001_SEL_004 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_004 = {"SYU_NO_W01", "BKN_NO_W01"};

	/** FKSR001_SEL_005 SQL .*/
	public static final String SQL_$FKSR001_SEL_005 =
	    "SELECT "
	    +    "R_KAS_1.KYK_NO, "
	    +    "R_KAS_1.KAST_SUM_MES, "
	    +    "R_KYKSH_1.KYKSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_TDFK_CD, "
	    +    "R_KYKSH_1.KYKSH_TDFK_NAME, "
	    +    "R_KYKSH_1.KYKSH_OOA_TSH_CD, "
	    +    "R_KYKSH_1.KYKSH_OOA_TSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_ACM, "
	    +    "R_KYKSH_1.KYKSH_CBN, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_UP_3, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "R_KYKSH_1.KYKSH_TEL_NO "
	    + "FROM  "
	    +    "R_KAS AS R_KAS_1 "
	    +    "INNER JOIN "
	    +        "R_KYKSH AS R_KYKSH_1 "
	    +    "    ON R_KAS_1.KYKSH_NO = R_KYKSH_1.KYKSH_NO "
	    + "WHERE "
	    +    "R_KAS_1.SSN_NO = ? "
	    + "ORDER BY R_KAS_1.KYK_NO";

	/** FKSR001_SEL_005 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_005 = {"SSN_NO_W01"};

	/** FKSR001_SEL_006 SQL .*/
	public static final String SQL_$FKSR001_SEL_006 =
	    "SELECT "
	    +    "R_SYU_IDO_RRK_1.IDO_DATE AS RRK_IDO_DATE, "
	    +    "R_SYU_IDO_RRK_1.SYU_IDO_SBT, "
	    +    "R_SYU_IDO_RRK_1.IDO_KIT_DATE, "
	    +    "R_SYU_IDO_RRK_1.IDO_KKTS_NO, "
	    +    "R_SYU_IDO_BKO_1.SYU_TCH_BKO, "
	    +    "R_SYU_IDO_BKO_1.IDO_DATE AS BKO_IDO_DATE "
	    + "FROM  "
	    +    "R_SYU_IDO_RRK AS R_SYU_IDO_RRK_1 "
	    +    "INNER JOIN "
	    +        "R_SYU_IDO_BKO AS R_SYU_IDO_BKO_1 "
	    +    "    ON R_SYU_IDO_RRK_1.SYU_NO = R_SYU_IDO_BKO_1.SYU_NO "
	    + "WHERE "
	    +    "R_SYU_IDO_RRK_1.SYU_NO = ? "
	    + "ORDER BY R_SYU_IDO_RRK_1.SYU_NO";

	/** FKSR001_SEL_006 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_006 = {"SYU_NO_W01"};

	/** FKSR001_SEL_008 SQL .*/
	public static final String SQL_$FKSR001_SEL_008 =
		" SELECT "
        +     " COUNT (T01.KYK_NO) AS COUNT "
        + " FROM "
        +     " R_CECJ T01 "
        +     " INNER JOIN R_KYK_BKN T02 "
        +     " ON  T01.KYK_NO = T02.KYK_NO "
        + " WHERE "
        +     " T02.BKN_NO = ? ";

	/** FKSR001_SEL_008 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_008 = {"BKN_NO_W01"};

	/** FKSR001_SEL_009 SQL .*/
	public static final String SQL_$FKSR001_SEL_009 =
		" SELECT "
        +     " COUNT (T01.KYK_NO) AS COUNT "
        + " FROM "
        +     " R_KAS T01 "
        +     " INNER JOIN R_KYK_BKN T02 "
        +     " ON  T01.KYK_NO = T02.KYK_NO "
        + " WHERE "
        +     " T02.BKN_NO = ? ";

	/** FKSR001_SEL_009 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR001_SEL_009 = {"BKN_NO_W01"};

	/** FKSR002_SELECT_001 SQL .*/
	public static final String SQL_$FKSR002_SELECT_001 =
	    "SELECT "
	    +    "R_KRUK_1.KYK_NO, "
	    +    "R_KRUK_1.DAI_KKSH_NAME, "
	    +    "R_KRUK_1.JUT_KKSH_NAME, "
	    +    "R_KRUK_1.KMK_CD, "
	    +    "R_KRUK_1.YOT_CD, "
	    +    "R_KRUK_1.KYOG_TNK_CMK_KBN, "
	    +    "R_KRUK_1.KNRI_SBT, "
	    +    "R_KRUK_1.GENK_CTR_NAME, "
	    +    "R_KRUK_1.WBS_YOS, "
	    +    "R_KRUK_1.WBS_NAME, "
	    +    "R_KRUK_1.KAN_CD, "
	    +    "R_KRUK_1.KAN_NAME, "
	    +    "R_KRUK_1.KKT_CD, "
	    +    "R_KRUK_1.KKT_NAME, "
	    +    "R_KRUK_1.RIT_KIT_NO, "
	    +    "R_KRUK_1.RIT_KIT_DATE, "
	    +    "R_KRUK_1.KYK_DATE, "
	    +    "R_KRUK_1.KYK_KKN_STA, "
	    +    "R_KRUK_1.KYK_KKN_END, "
	    +    "R_KRUK_1.AUTO_UPD_SKI, "
	    +    "R_KRUK_1.SHKT_SUM_MES, "
	    +    "R_KRUK_1.DNC_KYK_SU, "
	    +    "R_KRUK_1.KYYU_MCBN_BUNS, "
	    +    "R_KRUK_1.KYYU_MCBN_BUIB, "
	    +    "R_KRUK_1.TKSS_KBN, "
	    +    "R_KRUK_1.KYKS_KBN, "
	    +    "R_KRUK_1.JOSSK_Z_KBN, "
	    +    "R_KRUK_1.SKK_KBN, "
	    +    "R_KRUK_1.SKK, "
	    +    "R_KRUK_1.SKK_SHR_KMK, "
	    +    "R_KRUK_1.REK_CTR_NAME, "
	    +    "R_KRUK_1.SHR_SKI_KBN, "
	    +    "R_KRUK_1.SHR_SBT, "
	    +    "R_KRUK_1.SEK_HIY_HSE_KSH_NAME, "
	    +    "R_KRUK_1.SSN_NO, "
	    +    "R_KRUK_1.NXT_KATE_DATE, "
	    +    "R_KRUK_1.SNH_KBN, "
	    +    "V_SFSK_CMPY_1.SFSK_CD, "
	    +    "V_SFSK_CMPY_1.SFSK_NAME, "
	    +    "V_SFSK_CMPY_1.CMPY_NAME, "
	    +    "R_KRUK_SHR_KMK_1.SHR_KANJ_KMK_CD, "
	    +    "R_KYKSH_1.KYKSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_NO, "
	    +    "R_KYKSH_1.KYKSH_TDFK_NAME, "
	    +    "R_KYKSH_1.KYKSH_OOA_TSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_ACM, "
	    +    "R_KYKSH_1.KYKSH_CBN, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_UP_3, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "R_KYKSH_1.KYKSH_TEL_NO "
	    + "FROM  "
	    +    "R_KRUK AS R_KRUK_1 "
	    +    "INNER JOIN R_KRUK_SHR_KMK AS R_KRUK_SHR_KMK_1 "
	    +    "    ON  R_KRUK_1.KYK_NO =   R_KRUK_SHR_KMK_1.KYK_NO "
	    +    "INNER JOIN "
	    +        "V_SFSK_CMPY AS V_SFSK_CMPY_1 ON  "
	    +    "    R_KRUK_1.DAI_KKSH_CD = V_SFSK_CMPY_1.JGSH_CD "
	    +    "INNER JOIN "
	    +        "R_KYKSH AS R_KYKSH_1 ON  "
	    +    "    R_KRUK_1.KYKSH_NO = R_KYKSH_1.KYKSH_NO "
	    + "WHERE "
	    +    "R_KRUK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KRUK_1.KYK_NO ASC  ";

	/** FKSR002_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_001 = {"KYK_NO_W01"};

	/** FKSR002_SELECT_002 SQL .*/
	public static final String SQL_$FKSR002_SELECT_002 =
	    "SELECT "
	    +    "KAIKE_KICHO_DATE "
	    + "FROM  "
	    +    "R_KRUK_BOK AS R_KRUK_BOK_1 "
	    + "WHERE "
	    +    "R_KRUK_BOK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KRUK_BOK_1.KAIKE_KICHO_DATE DESC  ";

	/** FKSR002_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_002 = {"KYK_NO_W01"};

	/** FKSR002_SELECT_003 SQL .*/
	public static final String SQL_$FKSR002_SELECT_003 =
	    "SELECT "
	    +    "SSN_NO, "
	    +    "SUM(CHOB_GENK_ZAN_KIN) AS CHOB_GENK, "
	    +    "SUM(FUTKIN) AS FUTKIN, "
	    +    "SUM(GENS_SONS_SUM_KIN) AS GENS_SONS, "
	    +    "MAX(CHOB_GENK_STTS_FLG), "
	    +    "MAX(FUTKIN_UMU_FLG), "
	    +    "MAX(GENS_SONS_SUM_KIN_UMU_FLG) "
	    + "FROM  "
	    +    "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	    + "WHERE "
	    +    "R_BOK_ZAN_KIN_1.SSN_NO = ? "
	    + "GROUP BY "
	    +    "R_BOK_ZAN_KIN_1.SSN_NO ";

	/** FKSR002_SELECT_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_003 = {"SSN_NO_W01"};

	/** FKSR002_SELECT_004 SQL .*/
	public static final String SQL_$FKSR002_SELECT_004 =
	    "SELECT "
	    +    "HMK_KBN, "
	    +    "SHR_KANJ_KMK_CD, "
	    +    "BU_KBN, "
	    +    "BU_KBN_NAME, "
	    +    "HMK_WBS_YOS, "
	    +    "SHR_KMK_HMK_WBS_NAME, "
	    +    "ZEI_KBN, "
	    +    "PAY_PRC "
	    + "FROM  "
	    +    "R_KRUK_SHR_KMK AS R_KRUK_SHR_KMK_1 "
	    + "WHERE "
	    +    "R_KRUK_SHR_KMK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KRUK_SHR_KMK_1.KYK_NO ASC , "
	    +    "R_KRUK_SHR_KMK_1.SHR_KMK_RNO ASC  ";

	/** FKSR002_SELECT_004 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_004 = {"KYK_NO_W01"};

	/** FKSR002_SELECT_005 SQL .*/
	public static final String SQL_$FKSR002_SELECT_005 =
	    "SELECT "
	    +    "R_BKN_1.BKN_NO, "
	    +    "R_BKN_1.TDFK_NAME, "
	    +    "R_BKN_1.OOA_TSH_NAME, "
	    +    "R_BKN_1.BKN_ACM, "
	    +    "R_BKN_1.BKN_CBN, "
	    +    "R_BKN_1.TCH_KIN, "
	    +    "R_BKN_1.TET_NO_NO, "
	    +    "R_BKN_1.TET_NO_DNO, "
	    +    "R_BKN_1.CMK_KOB_KBN, "
	    +    "R_BKN_1.CMK_GEK_KBN, "
	    +    "R_BKN_1.MES_KOB, "
	    +    "R_BKN_1.SHKT_HAI_KBN, "
	    +    "R_BKN_1.STE_MES, "
	    +    "R_BKN_1.HSH_TKA, "
	    +    "R_BKN_1.DNC_SBT, "
	    +    "R_BKN_1.DNC_NO_1 "
	    + "FROM  "
	    +    "R_KYK_BKN AS KYK_BKN_1 "
	    +    "INNER JOIN "
	    +        "R_BKN AS R_BKN_1 ON  "
	    +    "    KYK_BKN_1.BKN_NO = R_BKN_1.BKN_NO "
	    + "WHERE "
	    +    "KYK_BKN_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_BKN_1.BKN_NO ASC  ";

	/** FKSR002_SELECT_005 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_005 = {"KYK_NO_W01"};

	/** FKSR002_SELECT_006 SQL .*/
	public static final String SQL_$FKSR002_SELECT_006 =
	    "SELECT "
	    +    "KRUK_IDO_RNO, "
	    +    "KRUK_IDO_SBT, "
	    +    "IDO_DATE, "
	    +    "IDO_KIT_DATE, "
	    +    "IDO_KKTS_NO "
	    + "FROM  "
	    +    "R_KRUK_IDO_RRK AS R_KRUK_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_KRUK_IDO_RRK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KRUK_IDO_RRK_1.KYK_NO ASC , "
	    +    "R_KRUK_IDO_RRK_1.KRUK_IDO_RNO ASC  ";

	/** FKSR002_SELECT_006 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_006 = {"KYK_NO_W01"};

	/** FKSR002_SELECT_007 SQL .*/
	public static final String SQL_$FKSR002_SELECT_007 =
	    "SELECT "
	    +    "KRUK_IDO_BKO_RNO, "
	    +    "IDO_DATE, "
	    +    "BKO "
	    + "FROM  "
	    +    "R_KRUK_IDO_BKO AS R_KRUK_IDO_BKO_1 "
	    + "WHERE "
	    +    "R_KRUK_IDO_BKO_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KRUK_IDO_BKO_1.KYK_NO ASC , "
	    +    "R_KRUK_IDO_BKO_1.KRUK_IDO_BKO_RNO ASC  ";

	/** FKSR002_SELECT_007 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR002_SELECT_007 = {"KYK_NO_W01"};

	/** FKSR003_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (�ݕt�䒠�̊�{�����擾����) ** //
	public static final String SQL_$FKSR003_SELECT_001 =
	    "SELECT "
	    +    "R_KAS_1.KYK_NO, "
	    +    "R_KAS_1.DAI_KKSH_NAME, "
	    +    "R_KAS_1.JUT_KKSH_NAME, "
	    +    "R_KAS_1.GENK_CTR_NAME, "
	    +    "R_KAS_1.KMK_CD, "
	    +    "R_KAS_1.YOT_CD, "
	    +    "R_KAS_1.WBS_YOS, "
	    +    "R_KAS_1.WBS_NAME, "
	    +    "R_KAS_1.KAN_CD, "
	    +    "R_KAS_1.KAN_NAME, "
	    +    "R_KAS_1.RIT_KIT_NO, "
	    +    "R_KAS_1.RIT_KIT_DATE, "
	    +    "R_KAS_1.KYK_DATE, "
	    +    "R_KAS_1.KYK_KKN_STA, "
	    +    "R_KAS_1.KYK_KKN_END, "
	    +    "R_KAS_1.AUTO_UPD_SKI, "
	    +    "R_KAS_1.KAST_SUM_MES, "
	    +    "R_KAS_1.DNC_KYK_SU, "
	    +    "R_KAS_1.KYKS_KBN, "
	    +    "R_KAS_1.JOSSK_Z_KBN, "
	    +    "R_KAS_1.SKK_KBN, "
	    +    "R_KAS_1.SKK, "
	    +    "R_KAS_1.SKK_KMK_CD, "
	    +    "R_KAS_1.NYK_SKI, "
	    +    "R_KAS_1.NYK_SBT, "
	    +    "R_KAS_1.SEK_HIY_HSE_KSH_NAME, "
	    +    "R_KAS_1.SNH_KBN, "
	    +    "R_KAS_1.GNB_KKSH_NAME, "
	    +    "R_KAS_1.KNRI_SBT, "
	    +    "R_KAS_1.NXT_KATE_DATE, "
	    +    "KYK_BKN_1.KYKSH_NAME, "
	    +    "KYK_BKN_1.KYKSH_TDFK_CD, "
	    +    "KYK_BKN_1.KYKSH_OOA_TSH_CD, "
	    +    "KYK_BKN_1.KYKSH_TDFK_NAME, "
	    +    "KYK_BKN_1.KYKSH_OOA_TSH_NAME, "
	    +    "KYK_BKN_1.KYKSH_ACM, "
	    +    "KYK_BKN_1.KYKSH_CBN, "
	    +    "KYK_BKN_1.KYKSH_ADD_YUB_NO_UP_3, "
	    +    "KYK_BKN_1.KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "KYK_BKN_1.KYKSH_TEL_NO, "
	    +    "V_SFSK_CMPY_1.SFSK_CD, "
	    +    "V_SFSK_CMPY_1.SFSK_NAME, "
	    +    "V_SFSK_CMPY_1.CMPY_NAME "
	    + "FROM  "
	    +    "R_KAS AS R_KAS_1 "
	    +    "INNER JOIN "
	    +        "R_KYKSH AS KYK_BKN_1 ON  "
	    +    "    R_KAS_1.KYKSH_NO = KYK_BKN_1.KYKSH_NO "
	    +    "INNER JOIN "
	    +        "V_SFSK_CMPY AS V_SFSK_CMPY_1 ON  "
	    +    "    R_KAS_1.DAI_KKSH_CD = V_SFSK_CMPY_1.JGSH_CD "
	    + "WHERE "
	    +    "R_KAS_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KAS_1.KYK_NO ASC  ";

	/** FKSR003_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR003_SELECT_001 = {"KYK_NO_W01"};

	/** FKSR003_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (�����Ȗڂ��擾����) ** //
	public static final String SQL_$FKSR003_SELECT_002 =
	    "SELECT "
	    +    "HMK_KBN, "
	    +    "UKE_KMK_UKE_KMK_CD, "
	    +    "BU_KBN, "
	    +    "BU_KBN_NAME, "
	    +    "UKE_KMK_HMK_WBS_YOS, "
	    +    "HMK_WBS_NAME, "
	    +    "UKE_KMK_ZEI_KBN, "
	    +    "NYK_KIN "
	    + "FROM  "
	    +    "R_KAS_UKE_KMK AS R_KAS_UKE_KMK_1 "
	    + "WHERE "
	    +    "R_KAS_UKE_KMK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KAS_UKE_KMK_1.KYK_NO ASC , "
	    +    "R_KAS_UKE_KMK_1.UKE_KMK_RNO ASC  ";

	/** FKSR003_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR003_SELECT_002 = {"KYK_NO_W01"};

	/** FKSR003_SELECT_003 SQL .*/
	// ** �ڍא݌v�����Q�� (�������ׂ��擾����) ** //
	public static final String SQL_$FKSR003_SELECT_003 =
	    "SELECT "
	    +    "R_KYK_BKN_1.BKN_NO, "
	    +    "R_KAS_TSH_1.KAST_HAI_KBN, "
	    +    "R_BKN_1.BKN_NO, "
	    +    "R_BKN_1.TDFK_NAME, "
	    +    "R_BKN_1.OOA_TSH_NAME, "
	    +    "R_BKN_1.BKN_ACM, "
	    +    "R_BKN_1.BKN_CBN, "
	    +    "R_BKN_1.TET_NO_NO, "
	    +    "R_BKN_1.TET_NO_DNO, "
	    +    "R_BKN_1.CMK_KOB_KBN, "
	    +    "R_BKN_1.CMK_GEK_KBN, "
	    +    "R_BKN_1.MES_KOB, "
	    +    "R_SYU_TCH_1.SYU_NO, "
	    +    "R_SYU_TCH_1.MES_JOSSK, "
	    +    "R_SYU_TCH_1.YKYU_STE_TCH_KBN, "
	    +    "R_BULD_KNR_1.BULD_KNR_NO "
	    + "FROM  "
	    +    "R_KYK_BKN AS R_KYK_BKN_1 "
	    +    "INNER JOIN "
	    +        "R_BKN AS R_BKN_1 ON  "
	    +    "    R_KYK_BKN_1.BKN_NO = R_BKN_1.BKN_NO "
	    +    "INNER JOIN "
	    +        "R_SYU_TCH AS R_SYU_TCH_1 ON  "
	    +    "    R_BKN_1.BKN_NO = R_SYU_TCH_1.BKN_NO "
	    +    "INNER JOIN "
	    +        "R_BULD_KNR AS R_BULD_KNR_1 ON  "
	    +    "    R_SYU_TCH_1.SSN_NO = R_BULD_KNR_1.SSN_NO "
	    +    "INNER JOIN "
	    +        "R_KAS_TSH AS R_KAS_TSH_1 ON  "
	    +    "    R_KYK_BKN_1.KYK_NO = R_KAS_TSH_1.KYK_NO "
	    + "WHERE "
	    +    "R_KYK_BKN_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KYK_BKN_1.BKN_NO ASC , "
	    +    "R_BKN_1.BKN_NO ASC  ";

	/** FKSR003_SELECT_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR003_SELECT_003 = {"KYK_NO_W01"};

	/** FKSR003_SELECT_004 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ��������擾����) ** //
	public static final String SQL_$FKSR003_SELECT_004 =
	    "SELECT "
	    +    "KAS_IDO_RNO, "
	    +    "KAS_IDO_SBT, "
	    +    "IDO_DATE, "
	    +    "IDO_KIT_DATE, "
	    +    "IDO_KKTS_NO "
	    + "FROM  "
	    +    "R_KAS_IDO_RRK AS R_KAS_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_KAS_IDO_RRK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KAS_IDO_RRK_1.KYK_NO ASC , "
	    +    "R_KAS_IDO_RRK_1.KAS_IDO_RNO ASC  ";

	/** FKSR003_SELECT_004 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR003_SELECT_004 = {"KYK_NO_W01"};

	/** FKSR003_SELECT_005 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ����l���擾����) ** //
	public static final String SQL_$FKSR003_SELECT_005 =
	    "SELECT "
	    +    "KAS_BKO_SSE_RNO, "
	    +    "IDO_DATE, "
	    +    "BKO "
	    + "FROM  "
	    +    "R_KAS_IDO_BKO AS R_KAS_IDO_BKO_1 "
	    + "WHERE "
	    +    "R_KAS_IDO_BKO_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_KAS_IDO_BKO_1.KYK_NO ASC , "
	    +    "R_KAS_IDO_BKO_1.KAS_BKO_SSE_RNO ASC  ";

	/** FKSR003_SELECT_005 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR003_SELECT_005 = {"KYK_NO_W01"};

	/** FKSR004_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (��p�䒠�̊�{�����擾����) ** //
	public static final String SQL_$FKSR004_SELECT_001 =
		" SELECT "
		+ "     RSE.KYK_NO, "
		+ "     RSE.KYKA_DATE, "
		+ "     RSE.DAI_KKSH_NAME, "
		+ "     RSE.JUT_KKSH_NAME, "
		+ "     RSE.KMK_CD, "
		+ "     RSE.KNRI_SBT, "
		+ "     RSE.GENK_CTR_NAME, "
		+ "     RSE.WBS_YOS, "
		+ "     RSE.WBS_NAME, "
		+ "     RSE.KAN_CD, "
		+ "     RSE.KAN_NAME, "
		+ "     RSE.YOT_CD, "
		+ "     RSE.KKT_CD, "
		+ "     RSE.KKT_NAME, "
		+ "     RSE.RIT_KIT_NO, "
		+ "     RSE.RIT_KIT_DATE, "
		+ "     RSE.KYKA_NO, "
		+ "     RSE.KYKA_KKN_ST, "
		+ "     RSE.KYKA_KKN_EN, "
		+ "     RSE.AUTO_UPD_SKI, "
		+ "     RSE.SEY_SBT, "
		+ "     RSE.KYKS_KBN, "
		+ "     RSE.JOSSK_Z_KBN, "
		+ "     RSE.SHR_SKI_KBN, "
		+ "     RSE.SHR_SBT_KBN, "
		+ "     RSE.SEK_HIY_HSE_KSH_NAME, "
		+ "     RSE.SEY_KIN_TEKIK, "
		+ "     RSE.SNH_KBN, "
		+ "     RKY.KYKSH_NAME, "
		+ "     RKY.KYKSH_TDFK_NAME, "
		+ "     RKY.KYKSH_OOA_TSH_NAME, "
		+ "     RKY.KYKSH_ACM, "
		+ "     RKY.KYKSH_CBN, "
		+ "     RKY.KYKSH_ADD_YUB_NO_UP_3, "
		+ "     RKY.KYKSH_ADD_YUB_NO_DWN_4, "
		+ "     RKY.KYKSH_TEL_NO, "
		+ "     VSC.SFSK_CD, "
		+ "     VSC.SFSK_NAME, "
		+ "     VSC.CMPY_NAME "
		+ " FROM "
		+ "     R_SEY RSE, "
		+ "     R_KYKSH RKY, "
		+ "     V_SFSK_CMPY VSC "
		+ " WHERE "
		+ "     VSC.JGSH_CD = RSE.DAI_KKSH_CD "
		+ "     AND RSE.KYKSH_NO = RKY.KYKSH_NO "
		+ "     AND RSE.KYK_NO = ? "
		+ " ORDER BY "
		+ "     RSE.KYK_NO ";

	/** FKSR004_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR004_SELECT_001 = {"KYK_NO_W01"};

	/** FKSR004_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (�x���Ȗڂ��擾����)  ** //
	public static final String SQL_$FKSR004_SELECT_002 =
		" SELECT "
		+ "     RSEY.SEY_SHR_KMK, "
		+ "     RSEY.HMK_WBS_YOS, "
		+ "     RSEY.HMK_WBS_NAME, "
		+ "     RSEY.BU_KBN, "
		+ "     RSEY.BU_KBN_NAME, "
		+ "     RKSK.HMK_KBN "
		+ " FROM "
		+ "     R_SEY RSEY, "
		+ "     R_KRUK_SHR_KMK RKSK "
		+ " WHERE "
		+ "     RKSK.KYK_NO = RSEY.KYK_NO "
		+ "     AND RSEY.KYK_NO = ? "
		+ " ORDER BY "
		+ "     RSEY.KYK_NO ";

	/** FKSR004_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR004_SELECT_002 = {"KYK_NO_W01"};

	/** FKSR004_SELECT_003 SQL .*/
	// ** �ڍא݌v�����Q�� (�������ׂ��擾����) ** //
	public static final String SQL_$FKSR004_SELECT_003 =
		" SELECT "
		+ "     RKB.BKN_NO, "
		+ "     RST.SYU_NO, "
		+ "     RBK.TDFK_NAME, "
		+ "     RBK.OOA_TSH_NAME, "
		+ "     RBK.BKN_ACM, "
		+ "     RBK.BKN_CBN, "
		+ "     RBK.TET_NO_NO, "
		+ "     RBK.TET_NO_DNO, "
		+ "     RBK.CMK_KOB_KBN, "
		+ "     RBK.MES_KOB, "
		+ "     RBK.SEY_MES, "
		+ "     RBK.SEY_TNC, "
		+ "     RBK.SEY_SU, "
		+ "     RBK.J2_SEY_KBN, "
		+ "     RBK.DNC_SBT, "
		+ "     RBK.DNC_NO_1, "
		+ "     RBK.SEY_HAI_KBN "
		+ " FROM "
		+ "     R_KYK_BKN RKB, "
		+ "     R_SYU_TCH RST, "
		+ "     R_BKN RBK "
		+ " WHERE "
		+ "     RKB.KYK_NO = ? "
		+ "     AND RKB.BKN_NO = RST.BKN_NO "
		+ "     AND RKB.BKN_NO = RBK.BKN_NO "
		+ " ORDER BY "
		+ "     RKB.BKN_NO, "
		+ "     RBK.BKN_NO ";

	/** FKSR004_SELECT_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR004_SELECT_003 = {"KYK_NO_W01"};

	/** FKSR004_SELECT_004 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ��������擾����) ** //
	public static final String SQL_$FKSR004_SELECT_004 =
		" SELECT "
		+ "     RSIR.SEY_IDO_RNO, "
		+ "     RSIR.SEY_IDO_SBT, "
		+ "     RSIR.IDO_DATE, "
		+ "     RSIR.IDO_KIT_DATE, "
		+ "     RSIR.IDO_KKTS_NO, "
		+ " FROM "
		+ "     R_SEY_IDO_RRK RSIR "
		+ " WHERE "
		+ "     RSIR.KYK_NO = ? "
		+ " ORDER BY "
		+ "     RSIR.KYK_NO, "
		+ "     RSIR.SEY_IDO_RNO ";

	/** FKSR004_SELECT_004 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR004_SELECT_004 = {"KYK_NO_W01"};

	/** FKSR004_SELECT_005 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ����l���擾����) ** //
	public static final String SQL_$FKSR004_SELECT_005 =
		" SELECT "
		+ "     RSIB.SEY_BKO_SSE_RNO, "
		+ "     RSIB.IDO_DATE, "
		+ "     RSIB.BKO, "
		+ " FROM "
		+ "     R_SEY_IDO_BKO RSIB "
		+ " WHERE "
		+ "     RSIB.KYK_NO = ? "
		+ " ORDER BY "
		+ "     RSIB.KYK_NO, "
		+ "     RSIB.SEY_BKO_SSE_RNO ";

	/** FKSR004_SELECT_005 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR004_SELECT_005 = {"KYK_NO_W01"};

	// FKSR005 SQLs START
	/** FKSR005_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (�n������n�㌠�䒠�̊�{�����擾����) ** //
	public static final String SQL_$FKSR005_SELECT_001 =
	    "SELECT "
	    +    "R_CECJ_1.KYK_NO, "
	    +    "R_CECJ_1.DAI_KKSH_NAME, "
	    +    "R_CECJ_1.GNB_KKSH_NAME, "
	    +    "R_CECJ_1.KMK_CD, "
	    +    "R_CECJ_1.KNRI_SBT, "
	    +    "R_CECJ_1.GENK_CTR_NAME, "
	    +    "R_CECJ_1.STE_PUR_KBN, "
	    +    "R_CECJ_1.WBS_YOS, "
	    +    "R_CECJ_1.WBS_NAME, "
	    +    "R_CECJ_1.KAN_CD, "
	    +    "R_CECJ_1.KAN_NAME, "
	    +    "R_CECJ_1.KKT_CD, "
	    +    "R_CECJ_1.KKT_NAME, "
	    +    "R_CECJ_1.RIT_KIT_NO, "
	    +    "R_CECJ_1.RIT_KIT_DATE, "
	    +    "R_CECJ_1.KYK_DATE, "
	    +    "R_CECJ_1.TKI_DATE, "
	    +    "R_CECJ_1.CECJ_SEGE_SBT_KBN, "
	    +    "R_CECJ_1.CECJ_SEGE_RIKAK, "
	    +    "R_CECJ_1.YEK_SYU_NO, "
	    +    "R_CECJ_1.AUTO_UPD_SKI, "
	    +    "R_CECJ_1.MTKIT_RYU_KBN, "
	    +    "R_CECJ_1.TKSS_KBN, "
	    +    "R_CECJ_1.KYKS_KBN, "
	    +    "R_CECJ_1.JOSSK_Z_KBN, "
	    +    "R_CECJ_1.KYK_KKN_STA, "
	    +    "R_CECJ_1.KYK_KKN_END, "
	    +    "R_CECJ_1.KYYU_MCBN_BUNS, "
	    +    "R_CECJ_1.KYYU_MCBN_BUIB, "
	    +    "R_CECJ_1.SHR_SKI_KBN, "
	    +    "R_CECJ_1.SHR_SBT, "
	    +    "R_CECJ_1.SHR_KMK, "
	    +    "R_CECJ_1.SEK_HIY_HSE_KSH_NAME, "
	    +    "R_CECJ_1.HMK_WBS_YOS, "
	    +    "R_CECJ_1.HMK_WBS_NAME, "
	    +    "R_CECJ_1.BU_KBN, "
	    +    "R_CECJ_1.BU_KBN_NAME, "
	    +    "R_CECJ_1.CRYO_TEKIK, "
	    +    "R_CECJ_1.NXT_KATE_DATE, "
	    +    "R_CECJ_1.SSN_NO, "
	    +    "R_CECJ_1.SNH_KBN, "
	    +    "V_SFSK_CMPY_1.SFSK_CD, "
	    +    "V_SFSK_CMPY_1.SFSK_NAME, "
	    +    "V_SFSK_CMPY_1.CMPY_NAME, "
	    +    "R_KYKSH_1.KYKSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_TDFK_NAME, "
	    +    "R_KYKSH_1.KYKSH_OOA_TSH_NAME, "
	    +    "R_KYKSH_1.KYKSH_ACM, "
	    +    "R_KYKSH_1.KYKSH_CBN, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_UP_3, "
	    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "R_KYKSH_1.KYKSH_TEL_NO "
	    + "FROM  "
	    +    "R_CECJ AS R_CECJ_1 "
	    +    "INNER JOIN R_KYKSH AS R_KYKSH_1 ON  "
	    +    "    R_CECJ_1.KYKSH_NO = R_KYKSH_1.KYKSH_NO "
	    +    "INNER JOIN V_SFSK_CMPY AS V_SFSK_CMPY_1 ON  "
	    +    "    R_CECJ_1.DAI_KKSH_CD = V_SFSK_CMPY_1.JGSH_CD "
	    + "WHERE "
	    +    "R_CECJ_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_CECJ_1.KYK_NO ASC ";

	/** FKSR005_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_001 = {"KYK_NO_W01"};

	/** FKSR005_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (��v�L���N�������擾����) ** //
	public static final String SQL_$FKSR005_SELECT_002 =
	    "SELECT "
	    +    "KAIKE_KICHO_DATE "
	    + "FROM  "
	    +    "R_CECJ_BOK_RRK AS R_CECJ_BOK_RRK_1 "
	    + "WHERE "
	    +    "R_CECJ_BOK_RRK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_CECJ_BOK_RRK_1.KYK_NO ASC  ";

	/** FKSR005_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_002 = {"KYK_NO_W01"};

	/** FKSR005_SELECT_003 SQL .*/
	// ** �ڍא݌v�����Q�� (���떾�ׂ��擾����) ** //
	public static final String SQL_$FKSR005_SELECT_003 =
	    "SELECT "
	    +    "SUM(CHOB_GENK_ZAN_KIN), "
	    +    "SUM(FUTKIN), "
	    +    "SUM(GENS_SONS_SUM_KIN), "
	    +    "MAX(CHOB_GENK_STTS_FLG), "
	    +    "MAX(FUTKIN_UMU_FLG), "
	    +    "MAX(GENS_SONS_SUM_KIN_UMU_FLG), "
	    +    "YND_STA_SHOKY_KIN "
	    + "FROM  "
	    +    "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 "
	    + "WHERE "
	    +    "R_BOK_ZAN_KIN_1.SYU_NO = ? AND "
	    +    "R_BOK_ZAN_KIN_1.BKN_NO = ? AND "
	    +    "R_BOK_ZAN_KIN_1.SSN_NO = ? "
	    + "GROUP BY "
	    +    "R_BOK_ZAN_KIN_1.SYU_NO, "
	    +    "R_BOK_ZAN_KIN_1.BKN_NO, "
	    +    "R_BOK_ZAN_KIN_1.SSN_NO ";

	/** FKSR005_SELECT_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_003 = {"SYU_NO_W01", "BKN_NO_W01", "SSN_NO_W01"};

	/** FKSR005_SELECT_004 SQL .*/
	// ** �ڍא݌v�����Q�� (�������ׂ��擾����) ** //
	public static final String SQL_$FKSR005_SELECT_004 =
	    "SELECT "
	    +    "R_BOK_ZAN_KIN_1.CHOB_GENK_ZAN_KIN, "
	    +    "R_KYK_BKN_1.BKN_NO, "
	    +    "R_BKN_1.TDFK_NAME, "
	    +    "R_BKN_1.OOA_TSH_NAME, "
	    +    "R_BKN_1.BKN_ACM, "
	    +    "R_BKN_1.BKN_CBN, "
	    +    "R_BKN_1.TCH_KIN, "
	    +    "R_BKN_1.TET_NO_NO, "
	    +    "R_BKN_1.TET_NO_DNO, "
	    +    "R_BKN_1.CMK_KOB_KBN, "
	    +    "R_BKN_1.STE_MES, "
	    +    "R_BKN_1.STE_HAI_KBN, "
	    +    "R_BKN_1.HSH_SBT, "
	    +    "R_BKN_1.BKN_HSH_RIT, "
	    +    "R_BKN_1.HSH_TKA "
	    + "FROM  "
	    +    "R_KYK_BKN AS R_KYK_BKN_1 "
	    +    "INNER JOIN "
	    +        "R_BKN AS R_BKN_1 ON  "
	    +    "    R_KYK_BKN_1.BKN_NO = R_BKN_1.BKN_NO AND  "
	    +    "INNER JOIN "
	    +        "R_BOK_ZAN_KIN AS R_BOK_ZAN_KIN_1 ON  "
	    +    "    R_BKN_1.BKN_NO = R_BOK_ZAN_KIN_1.BKN_NO "
	    + "WHERE "
	    +    "R_KYK_BKN_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_BKN_1.BKN_NO ASC  ";

	/** FKSR005_SELECT_004 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_004 = {"KYK_NO_W01"};

	/** FKSR005_SELECT_005 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ����������擾����) ** //
	public static final String SQL_$FKSR005_SELECT_005 =
	    "SELECT "
	    +    "CECJ_IDO_RNO, "
	    +    "CECJ_IDO_SBT, "
	    +    "IDO_DATE, "
	    +    "IDO_KIT_DATE, "
	    +    "IDO_KKTS_NO "
	    + "FROM  "
	    +    "R_CECJ_IDO_RRK AS R_CECJ_IDO_RRK_1 "
	    + "WHERE "
	    +    "R_CECJ_IDO_RRK_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_CECJ_IDO_RRK_1.KYK_NO ASC, "
	    +    "R_CECJ_IDO_RRK_1.CECJ_IDO_RNO ASC ";

	/** FKSR005_SELECT_005 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_005 = {"KYK_NO_W01"};

	/** FKSR005_SELECT_006 SQL .*/
	// ** �ڍא݌v�����Q�� (�ٓ����l�����擾����) ** //
	public static final String SQL_$FKSR005_SELECT_006 =
	    "SELECT "
	    +    "CECJ_IDO_BKO_RNO, "
	    +    "IDO_DATE, "
	    +    "CECJ_BKO "
	    + "FROM  "
	    +    "R_CECJ_IDO_BKO AS R_CECJ_IDO_BKO_1 "
	    + "WHERE "
	    +    "R_CECJ_IDO_BKO_1.KYK_NO = ? "
	    + "ORDER BY "
	    +    "R_CECJ_IDO_BKO_1.KYK_NO ASC , "
	    +    "R_CECJ_IDO_BKO_1.CECJ_IDO_BKO_RNO ASC  ";

	/** FKSR005_SELECT_006 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR005_SELECT_006 = {"KYK_NO_W01"};
	// FKSR005 SQLs END

	/** FKSR008_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (�ЗL�䒠�̕⎆�����擾����(�ЗL�ԍ��L��̏ꍇ)) ** //
	public static final String SQL_$FKSR008_SELECT_001 =
	    "SELECT "
	    +    "R_SYU_TCH_1.SYU_NO, "
	    +    "R_SYU_TCH_1.BKN_NO, "
	    +    "R_SYU_TCH_1.SYU_TCH_HOSHI, "  // ** �ڍא݌v�����Q��(AS �⎆) ** //
	    +    "V_SFSK_CMPY_1.CMPY_NAME "
	    + " FROM  "
	    +    "R_SYU_TCH AS R_SYU_TCH_1 "
	    +    "INNER JOIN (// ** �ڍא݌v�����Q�� ** //) "
	    +        "V_SFSK_CMPY AS V_SFSK_CMPY_1 ON  "
	    +    "    R_SYU_TCH_1.DAI_KKSH_CD = V_SFSK_CMPY_1.JGSH_CD "
	    + " WHERE "
	    +    "R_SYU_TCH_1.SYU_NO = ? AND "
	    +    "R_SYU_TCH_1.BKN_NO = ? ";

	/** FKSR008_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR008_SELECT_001 = {"SYU_NO_W01", "BKN_NO_W01"};


	/** �x�����׈ꗗ�\���擾���� SQL .*/
	public static final String SQL_$FKSR009_SELECT_001 =
        " SELECT "
        + "     TKS.CHOHY_RNO "
        + "     , TKS.SFSK_CD "
        + "     , TKS.SFSK_NAME "
        + "     , TKS.NOW_DATE "
        + "     , TKS.DAI_KKSH_NAME "
        + "     , TKS.JUT_KKSH_NAME "
        + "     , TKS.SHKT_KIN_SU "
        + "     , TKS.SHKT_KIN "
        + "     , TKS.FURI_SUM "
        + "     , TKS.CMPY_NAME "
        + " FROM "
        + "     TKSR009WK TKS "
        + " ORDER BY "
        + "     TKS.CHOHY_RNO ";

	/** �x�����׈ꗗ�\���擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR009_SELECT_001 = {};

	/** �x�����׈ꗗ�\�̖��ׂ��擾���� SQL .*/
	public static final String SQL_$FKSR009_SELECT_002 =
        " SELECT "
        + "     TKS2.CHOHY_RNO "
        + "     , TKS2.CHOHY_DTL_1_RNO "
        + "     , TKS2.CHK "
        + "     , TKS2.NOTE_MSG "
        + "     , TKS2.KYK_NO "
        + "     , TKS2.SETB_KMK_CD "
        + "     , TKS2.YOT "
        + "     , TKS2.WBS_YOS "
        + "     , TKS2.KAN_NAME "
        + "     , TKS2.KKT_NAME "
        + "     , TKS2.SHR_DATE "
        + "     , TKS2.SHR_SBT_NAME "
        + "     , TKS2.SHR_SKI_NAME "
        + "     , TKS2.SHR_TSH_KKN_ST "
        + "     , TKS2.SHR_TSH_KKN_EN "
        + "     , TKS2.QUES_NO "
        + "     , TKS2.YUB_NO "
        + "     , TKS2.KYKSH_TDFK_NAME "
        + "     , TKS2.KYKSH_OOA_TSH_NAME "
        + "     , TKS2.KYKSH_ACM "
        + "     , TKS2.KYKSH_CBN "
        + "     , TKS2.KYKSH_NAME "
        + "     , TKS2.KYKKN_NAME "
        + "     , TKS2.YKIN_SBT "
        + "     , TKS2.KOZ_NO "
        + "     , TKS2.KOZ_MEGNIN "
        + " FROM "
        + "     TKSR009WK2 TKS2 "
        + " WHERE "
        + "     TKS2.CHOHY_RNO = ? "
        + " ORDER BY "
        + "     TKS2.CHOHY_RNO "
        + "     , TKS2.CHOHY_DTL_1_RNO ";

	/** �x�����׈ꗗ�\�̖��ׂ��擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR009_SELECT_002 = {"CHOHY_RNO_W01"};

	/** �x�����׈ꗗ�\�̖��ׂ��擾���� SQL .*/
	//TODO
	public static final String SQL_$FKSR009_SELECT_003 =
        " SELECT "
        + "     TKS3.CHOHY_RNO "
        + "     , TKS3.CHOHY_DTL_1_RNO "
        + "     , TKS3.CHOHY_DTL_2_RNO "
        + "     , TKS3.HIN_NAME "
        + "     , TKS3.SHR_KANJ_KMK_CD "
        + "     , TKS3.ZEI_KBN_NAME "
        + "     , TKS3.BU_KBN_NAME "
        + "     , TKS3.PAY_PRC "
        + "     , TKS3.HMK_WBS_YOS "
        + "     , TKS3.HMK_WBS_NAME "
        + " FROM "
        + "     TKSR009WK3 TKS3 "
        + " WHERE "
        + "     TKS3.CHOHY_RNO = ? "
        + "     AND TKS3.CHOHY_DTL_1_RNO = ? "
        + " ORDER BY "
        + "     TKS3.CHOHY_RNO "
        + "     , TKS3.CHOHY_DTL_1_RNO "
        + "     , TKS3.CHOHY_DTL_2_RNO ";

	/** �x�����׈ꗗ�\�̖��ׂ��擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR009_SELECT_003 = {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"};

	/** �x���\��ꗗ�\���擾���� SQL .*/
	public static final String SQL_$FKSR010_SELECT_001 =
        " SELECT "
        + "     TKS.CHOHY_RNO "
        + "     , TKS.SFSK_CD "
        + "     , TKS.SFSK_NAME "
        + "     , TKS.NOW_DATE "
        + "     , TKS.DAI_KKSH_NAME "
        + "     , TKS.JUT_KKSH_NAME "
        + "     , TKS.SHKT_KIN_SU "
        + "     , TKS.SHKT_KIN "
        + "     , TKS.FURI_SUM "
        + "     , TKS.CMPY_NAME "
        + " FROM "
        + "     TKSR010WK TKS "
        + " ORDER BY "
        + "     TKS.CHOHY_RNO ";

	/** �x���\��ꗗ�\���擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR010_SELECT_001 = {};

	/** �x���\��ꗗ�\�̖��ׂ��擾���� SQL .*/
	public static final String SQL_$FKSR010_SELECT_002 =
        " SELECT "
        + "     TKS2.CHOHY_RNO "
        + "     , TKS2.CHOHY_DTL_1_RNO "
        + "     , TKS2.CHK "
        + "     , TKS2.NOTE_MSG "
        + "     , TKS2.KYK_NO "
        + "     , TKS2.SETB_KMK_CD "
        + "     , TKS2.YOT "
        + "     , TKS2.WBS_YOS "
        + "     , TKS2.KAN_NAME "
        + "     , TKS2.KKT_NAME "
        + "     , TKS2.SHR_DATE "
        + "     , TKS2.SHR_SBT_NAME "
        + "     , TKS2.SHR_SKI_NAME "
        + "     , TKS2.SHR_TSH_KKN_ST "
        + "     , TKS2.SHR_TSH_KKN_EN "
        + "     , TKS2.YUB_NO "
        + "     , TKS2.KYKSH_TDFK_NAME "
        + "     , TKS2.KYKSH_OOA_TSH_NAME "
        + "     , TKS2.KYKSH_ACM "
        + "     , TKS2.KYKSH_CBN "
        + "     , TKS2.KYKSH_NAME "
        + "     , TKS2.KYKKN_NAME "
        + "     , TKS2.YKIN_SBT "
        + "     , TKS2.KOZ_NO "
        + "     , TKS2.KOZ_MEGNIN "
        + " FROM "
        + "     TKSR010WK2 TKS2 "
        + " WHERE "
        + "     TKS2.CHOHY_RNO = ? "
        + " ORDER BY "
        + "     TKS2.CHOHY_RNO "
        + "     , TKS2.CHOHY_DTL_1_RNO ";

	/** �x���\��ꗗ�\�̖��ׂ��擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR010_SELECT_002 = {"CHOHY_RNO_W01"};

	/** �x���\��ꗗ�\�̖��ׂ��擾���� SQL .*/
	//TODO
	public static final String SQL_$FKSR010_SELECT_003 =
        " SELECT "
        + "     TKS3.CHOHY_RNO "
        + "     , TKS3.CHOHY_DTL_1_RNO "
        + "     , TKS3.CHOHY_DTL_2_RNO "
        + "     , TKS3.HIN_NAME "
        + "     , TKS3.SHR_KANJ_KMK_CD "
        + "     , TKS3.ZEI_KBN_NAME "
        + "     , TKS3.BU_KBN_NAME "
        + "     , TKS3.PAY_PRC "
        + "     , TKS3.HMK_WBS_YOS "
        + "     , TKS3.HMK_WBS_NAME "
        + " FROM "
        + "     TKSR010WK3 TKS3 "
        + " WHERE "
        + "     TKS3.CHOHY_RNO = ? "
        + "     AND TKS3.CHOHY_DTL_1_RNO = ? "
        + " ORDER BY "
        + "     TKS3.CHOHY_RNO "
        + "     , TKS3.CHOHY_DTL_1_RNO "
        + "     , TKS3.CHOHY_DTL_2_RNO ";

	/** �x���\��ꗗ�\�̖��ׂ��擾���� �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR010_SELECT_003 = {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"};

	/** FKSR012_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (�����\��ꗗ�\�̖��ׂ��擾����) ** //
	public static final String SQL_$FKSR012_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "NOW_DATE, "
	    +    "DAI_KKSH_NAME, "
	    +    "JUT_KKSH_NAME, "
	    +    "SHKT_KIN_SU, "
	    +    "SHKT_KIN, "
	    +    "FURI_SUM, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR012WK AS TKSR012WK_1 "
	    + "ORDER BY "
	    +    "TKSR012WK_1.CHOHY_RNO ASC  ";

	/** FKSR012_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR012_SELECT_001 = {};

	/** FKSR012_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (�����\��ꗗ�\�̖��ׂ��擾����) ** //
	public static final String SQL_$FKSR012_SELECT_002 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "CHOHY_DTL_1_RNO, "
	    +    "CHK, "
	    +    "NOTE_MSG, "
	    +    "KYK_NO, "
	    +    "SETB_KMK_CD, "
	    +    "YOT, "
	    +    "WBS_YOS, "
	    +    "KAN_NAME, "
	    +    "KKT_NAME, "
	    +    "NYK_DATE, "
	    +    "NYK_SBT_NAME, "
	    +    "NYK_SKI_NAME, "
	    +    "NYK_TSH_KKN_ST, "
	    +    "NYK_TSH_KKN_EN, "
	    +    "YUB_NO, "
	    +    "KYKSH_TDFK_NAME, "
	    +    "KYKSH_OOA_TSH_NAME, "
	    +    "KYKSH_ACM, "
	    +    "KYKSH_CBN, "
	    +    "KYKSH_NAME, "
	    +    "KYK_DATE, "
	    +    "KYK_KKN_ST, "
	    +    "KYK_KKN_EN, "
	    +    "KAST_SUM_MES, "
	    +    "DNC_KYK_SU "
	    + "FROM  "
	    +    "TKSR012WK2 AS TKSR012WK2_1 "
	    + "WHERE "
	    +    "TKSR012WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR012WK2_1.CHOHY_RNO ASC , "
	    +    "TKSR012WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** FKSR012_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR012_SELECT_002 = {"CHOHY_RNO_W01"};

	/** FKSR012_SELECT_003 SQL .*/
	// ** �ڍא݌v�����Q�� (�����\��ꗗ�\�̖��ׂ��擾����) ** //
	public static final String SQL_$FKSR012_SELECT_003 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "CHOHY_DTL_1_RNO, "
	    +    "CHOHY_DTL_2_RNO, "
	    +    "HIN_NAME, "
	    +    "UKE_KANJ_KMK_CD, "
	    +    "ZEI_KBN_NAME, "
	    +    "BU_KBN_NAME, "
	    +    "NYK_KIN, "
	    +    "HMK_WBS_YOS, "
	    +    "HMK_WBS_NAME "
	    + "FROM  "
	    +    "TKSR012WK3 AS TKSR012WK3_1 "
	    + "WHERE "
	    +    "TKSR012WK3_1.CHOHY_RNO = ? AND "
	    +    "TKSR012WK3_1.CHOHY_DTL_1_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR012WK3_1.CHOHY_RNO ASC , "
	    +    "TKSR012WK3_1.CHOHY_DTL_1_RNO ASC , "
	    +    "TKSR012WK3_1.CHOHY_DTL_2_RNO ASC  ";

	/** FKSR012_SELECT_003 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR012_SELECT_003 = {"CHOHY_RNO_W01", "CHOHY_DTL_1_RNO_W01"};

	/** FKSR013_SEL_001 SQL .*/
	public static final String SQL_$FKSR013_SELECT_001 =
		"SELECT "
        +     "CHOHY_RNO, "
        +     "SFSK_CD, "
        +     "SFSK_NAME, "
        +     "DAI_KKSH_NAME, "
        +     "JUT_TCH_KKSH_NAME, "
        +     "NOW_DATE, "
        +     "CMPY_NAME, "
        +     "SSN_TANI, "
        +     "SETB_KMK_NAME "
        + "FROM "
        +     "TKSR013WK AS TKSR013WK_1 "
        + "ORDER BY "
        +     "TKSR013WK_1.CHOHY_RNO ASC ";

	/** FKSR013_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR013_SELECT_001 = {};

	/** FKSR013_SELECT_002 SQL .*/
	public static final String SQL_$FKSR013_SELECT_002 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "CHOHY_DTL_1_RNO, "
	    +    "KAN_CD, "
	    +    "KAN_NAME, "
	    +    "SSN_NO, "
	    +    "SSN_HJNO, "
	    +    "GENK_CTR, "
	    +    "ETC_KNR_UMU, "
	    +    "SHK_Y, "
	    +    "YOCH_CHOB_GENK_ZAN_KIN, "
	    +    "YOCH_FUTKIN, "
	    +    "YOCH_GENS_SONS_SUM_KIN, "
	    +    "KEIR_CHOB_GENK_ZAN_KIN, "
	    +    "KEIR_FUTKIN, "
	    +    "KEIR_GENS_SONS_SUM_KIN, "
	    +    "SHOG_KEKK_CHOB_GENK_ZAN_KIN, "
	    +    "SHOG_KEKK_FUTKIN, "
	    +    "SHOG_KEKK_GENS_SONS_SUM_KIN, "
	    +    "SHOG_KEKK_NOW_SHOKY_SUM_KIN, "
	    +    "KAN_SUM_KOB_MES, "
	    +    "KAN_SUM_JOSSK_MES, "
	    +    "YOCH_NOW_SHOKY_SUM_KIN, "
	    +    "KEIR_NOW_SHOKY_SUM_KIN, "
	    +    "SUM_FLG "
	    + "FROM  "
	    +    "TKSR013WK2 AS TKSR013WK2_1 "
	    + "WHERE "
	    +    "TKSR013WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR013WK2_1.CHOHY_RNO ASC , "
	    +    "TKSR013WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** FKSR013_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR013_SELECT_002 = {"CHOHY_RNO_W01"};

	/** TKSR019_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
	public static final String SQL_$TKSR019_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "REK_CTR_CD, "
	    +    "DAI_KKSH_NAME, "
	    +    "GNB_KKSH_NAME, "
	    +    "KJO_YM, "
	    +    "FURI_YM, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR019WK AS TKSR019WK_1 "
	    + "ORDER BY "
	    +    "TKSR019WK_1.CHOHY_RNO ASC  ";

	/** TKSR019_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR019_SELECT_001 = {};

	/** TKSR019_SELECT_002 SQL .*/
	public static final String SQL_$TKSR019_SELECT_002 =
	    "SELECT "
	    +    "KYK_NO, "
	    +    "KESSN_SERI_YM_1, "
	    +    "KESSN_SERI_YM_2, "
	    +    "PREHR_HIY_KJO_KIN, "
	    +    "PREHR_HIY_FRMD_KIN, "
	    +    "SHR_KANJ_KMK_CD, "
	    +    "SHR_KANJ_KMK_CD_2, "
	    +    "UKE_KANJ_KMK_CD, "
	    +    "UKE_KANJ_KMK_CD_2, "
	    +    "SHR_DATE, "
	    +    "PAY_PRC, "
	    +    "SHR_TSH_KKN_ST, "
	    +    "SHR_TSH_KKN_EN, "
	    +    "SUM_FLG "
	    + "FROM  "
	    +    "TKSR019WK2 AS TKSR019WK2_1 "
	    + "WHERE "
	    +    "TKSR019WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR019WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR019_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR019_SELECT_002 = {"CHOHY_RNO_W01"};

	/** TKSR020_SELECT_001 SQL .*/
	public static final String SQL_$FKSR020_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "REK_CTR_NAME, "
	    +    "DAI_KKSH_NAME, "
	    +    "GNB_KKSH_NAME, "
	    +    "KJO_YM, "
	    +    "FURI_YM, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR020WK AS TKSR020WK_1 "
	    + "ORDER BY "
	    +    "TKSR020WK_1.CHOHY_RNO ASC  ";

	/** TKSR020_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR020_SELECT_001 = {};

	/** TKSR020_SELECT_002 SQL .*/
	public static final String SQL_$FKSR020_SELECT_002 =
	    "SELECT "
	    +    "CHOHY_DTL_1_RNO, "
	    +    "KYK_NO, "
	    +    "KESSN_SERI_YM_1, "
	    +    "KESSN_SERI_YM_2, "
	    +    "NHR_HIY_KJO_KIN, "
	    +    "NHR_HIY_FRMD_KIN, "
	    +    "SHR_KMK_CD, "
	    +    "SHR_KANJ_KMK_CD_2, "
	    +    "UKE_KANJ_KMK_CD, "
	    +    "UKE_KANJ_KMK_CD_2, "
	    +    "SHR_DATE, "
	    +    "PAY_PRC, "
	    +    "SHR_TSH_KKN_ST "
	    + "FROM  "
	    +    "TKSR020WK2 AS TKSR020WK2_1 "
	    + "WHERE "
	    +    "TKSR020WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR020WK2_1.CHOHY_RNO ASC , "
	    +    "TKSR020WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR020_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$FKSR020_SELECT_002 = {"CHOHY_RNO_W01"};

	/** TKSR021_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
	public static final String SQL_$TKSR021_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "GNB_KKSH_NAME, "
	    +    "DAI_KKSH_NAME, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR021WK AS TKSR021WK_1 "
	    + "ORDER BY "
	    +    "TKSR021WK_1.CHOHY_RNO ASC  ";

	/** TKSR021_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR021_SELECT_001 = {};

	/** TKSR021_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
	public static final String SQL_$TKSR021_SELECT_002 =
	    "SELECT "
	    +    "KYK_NO, "
	    +    "SETB_KMK_NAME, "
	    +    "YOT_NAME, "
	    +    "KAN_NAME, "
	    +    "WBS_NAME, "
	    +    "UKB_DATE, "
	    +    "SHR_SBT_NAME, "
	    +    "SHR_SKI_NAME, "
	    +    "UKB_TSH_KKN_ST, "
	    +    "UKB_TSH_KKN_EN, "
	    +    "SHR_KMK, "
	    +    "KYOG_TNK_KBN, "
	    +    "SHKT_SUM_MES, "
	    +    "TND_KYOG_TNK, "
	    +    "TND_SHKT_KIN, "
	    +    "YKND_KYOG_TNK, "
	    +    "YKND_SHKT_SHO, "
	    +    "UKB_AIT_NAME, "
	    +    "KYKKN_NAME, "
	    +    "YKIN_SBT, "
	    +    "KOZ_NO, "
	    +    "KOZ_MEGNIN, "
	    +    "KYKSH_ADD_YUB_NO_UP_3, "
	    +    "KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "KYKSH_TDFK_NAME, "
	    +    "KYKSH_OOA_TSH_NAME, "
	    +    "KYKSH_ACM, "
	    +    "KYKSH_CBN "
	    + "FROM  "
	    +    "TKSR021WK2 AS TKSR021WK2_1 "
	    + "WHERE "
	    +    "TKSR021WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR021WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR021_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR021_SELECT_002 = {"CHOHY_RNO_W01"};

	/** TKSR022_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
	public static final String SQL_$TKSR022_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "GNB_KKSH_NAME, "
	    +    "DAI_KKSH_NAME, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR022WK AS TKSR022WK_1 "
	    + "ORDER BY "
	    +    "TKSR022WK_1.CHOHY_RNO ASC  ";

	/** TKSR022_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR022_SELECT_001 = {};

	/** TKSR022_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
	public static final String SQL_$TKSR022_SELECT_002 =
	    "SELECT "
	    +    "KYK_NO, "
	    +    "SETB_KMK_NAME, "
	    +    "YOT_NAME, "
	    +    "KAN_NAME, "
	    +    "WBS_NAME, "
	    +    "UKB_DATE, "
	    +    "SHR_SBT_NAME, "
	    +    "SHR_SKI_NAME, "
	    +    "UKB_TSH_KKN_ST, "
	    +    "UKB_TSH_KKN_EN, "
	    +    "SHR_KMK, "
	    +    "KYOG_TNK_KBN, "
	    +    "KYOG_TNK_KBN_NAME, "
	    +    "SHKT_SUM_MES, "
	    +    "ZNND_KYOG_TNK, "
	    +    "ZNND_SHKT_KIN, "
	    +    "TND_KYOG_TNK, "
	    +    "TND_SHKT_KIN, "
	    +    "UKB_AIT_NAME, "
	    +    "KYKKN_NAME, "
	    +    "YKIN_SBT, "
	    +    "KOZ_NO, "
	    +    "KOZ_MEGNIN, "
	    +    "KYKSH_ADD_YUB_NO_UP_3, "
	    +    "KYKSH_ADD_YUB_NO_DWN_4, "
	    +    "KYKSH_TDFK_NAME, "
	    +    "KYKSH_OOA_TSH_NAME, "
	    +    "KYKSH_ACM, "
	    +    "KYKSH_CBN "
	    + "FROM  "
	    +    "TKSR022WK2 AS TKSR022WK2_1 "
	    + "WHERE "
	    +    "TKSR022WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR022WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR022_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR022_SELECT_002 = {"CHOHY_RNO_W01"};

	/** TKSR023_SEL_001 SQL .*/
	// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
	public static final String SQL_$TKSR023_SEL_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR023WK AS TKSR023WK_1 ";

	/** TKSR023_SEL_001 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR023_SEL_001 = {};

	/** TKSR023_SEL_002 SQL .*/
	// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
	public static final String SQL_$TKSR023_SEL_002 =
		"SELECT "
	    +    "BKN_NO, "
	    +    "KYK_NO, "
	    +    "KBT, "
	    +    "SHYU, "
	    +    "KYK, "
	    +    "UPD, "
	    +    "TDFK_CD, "
	    +    "OLD_SYSH_TDFK_CD, "
	    +    "KYKSH_TDFK_CD, "
	    +    "BKN_OOA_TSH_CD, "
	    +    "OLD_SYSH_OOA_TSH_CD, "
	    +    "KYKSH_OOA_TSH_CD, "
	    +    "TDFK_NAME, "
	    +    "OOA_TSH_NAME, "
	    +    "OLD_SYSH_OOA_TSH_NAME, "
	    +    "KYKSH_OOA_TSH_NAME, "
	    +    "BKN_ACM, "
	    +    "OLD_SYSH_ACM, "
	    +    "KYKSH_ACM, "
	    +    "KYKSH_ADD_YUB_NO_UP_3, "
	    +    "KYKSH_ADD_YUB_NO_DWN_4 "
	    + "FROM  "
	    +    "TKSR023WK2 AS TKSR023WK2_1 "
	    + "WHERE "
	    +    "TKSR023WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR023WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR023_SEL_002 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR023_SEL_002 = {"CHOHY_RNO_W01"};

	/** TKSR024_SELECT_001 SQL .*/
	// ** �ڍא݌v�����Q�� (ͯ�ް�����̎擾) ** //
	public static final String SQL_$TKSR024_SELECT_001 =
	    "SELECT "
	    +    "CHOHY_RNO, "
	    +    "SFSK_CD, "
	    +    "SFSK_NAME, "
	    +    "NOW_DATE, "
	    +    "CMPY_NAME "
	    + "FROM  "
	    +    "TKSR024WK AS TKSR024WK_1 "
	    + "ORDER BY "
	    +    "TKSR024WK_1.CHOHY_RNO ASC  ";

	/** TKSR024_SELECT_001 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR024_SELECT_001 = {};

	/** TKSR024_SELECT_002 SQL .*/
	// ** �ڍא݌v�����Q�� (���ו����̎擾) ** //
	public static final String SQL_$TKSR024_SELECT_002 =
	    "SELECT "
	    +    "BKN_NO, "
	    +    "KYK_NO, "
	    +    "KBT, "
	    +    "SHYU, "
	    +    "KYK, "
	    +    "UPD, "
	    +    "ERR_MSG, "
	    +    "TDFK_CD, "
	    +    "BKN_OOA_TSH_CD, "
	    +    "TDFK_NAME, "
	    +    "OOA_TSH_NAME, "
	    +    "ACM, "
	    +    "SSE_IM_ADD "
	    + "FROM  "
	    +    "TKSR024WK2 AS TKSR024WK2_1 "
	    + "WHERE "
	    +    "TKSR024WK2_1.CHOHY_RNO = ? "
	    + "ORDER BY "
	    +    "TKSR024WK2_1.CHOHY_DTL_1_RNO ASC  ";

	/** TKSR024_SELECT_002 �p�����[�^��` .*/
	public static final String[] PARAM_$TKSR024_SELECT_002 = {"CHOHY_RNO_W01"};

	/**
	 * �C���X�^���X�擾���\�b�h.
	 * @return �C���X�^���X
	 */
	public static SQLObjectInterface getInstance() {
		return sqlObj;
	}
}
