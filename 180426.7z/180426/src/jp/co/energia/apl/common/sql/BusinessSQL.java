/**
 * BusinessSQL.java
 * All Rights Reserved.Copyright�@[???�����N???],Energia�@Communications.Inc
 */
package jp.co.energia.apl.common.sql;

import jp.co.enecom.framework.dao.AbstractSQLObject;
import jp.co.enecom.framework.dao.SQLObjectInterface;

/**
 * �r�W�l�X���W�b�N�Ŏg�p����SQL���`����N���X�ł��B.
 * <p>
 * Ver.00.00.00 2017/12/25 : S.Akashi - Original
 */
public final class BusinessSQL extends AbstractSQLObject {

    // ********************************************/
    /* Singleton�i�s�v�ȃC���X�^���X�̐������֎~�j*/
    // ********************************************/
    /** Singleton�p�C���X�^���X�ێ��̈�. */
    private static SQLObjectInterface sqlObj = new BusinessSQL();

    /**
     * �R���X�g���N�^.
     */
    private BusinessSQL() {
        super();
    }

    // ********************************************/
    /* �����E�䒠�쐬�Ɩ�              */
    // ********************************************/
    /** FKSD122_SELECT_001 SQL .*/
    public static final String SQL_$FKSD122_SELECT_001 =
            " SELECT "
                    +     " T01.BKN_NO, "
                    +     " T01.TDFK_CD, "
                    +     " T01.TDFK_NAME, "
                    +     " T01.BKN_OOA_TSH_CD, "
                    +     " T01.OOA_TSH_NAME, "
                    +     " T01.BKN_ACM, "
                    +     " T01.BKN_CBN, "
                    +     " T01.TET_NO_NO, "
                    +     " T01.TET_NO_DNO, "
                    +     " T01.CMK_KOB_KBN, "
                    +     " T01.CMK_GEK_KBN, "
                    +     " T01.MES_KOB, "
                    +     " T01.OLD_SYSH_TDFK_CD, "
                    +     " T01.OLD_SYSH_TDFK_NAME, "
                    +     " T01.OLD_SYSH_OOA_TSH_CD, "
                    +     " T01.OLD_SYSH_OOA_TSH_NAME, "
                    +     " T01.OLD_SYSH_ACM, "
                    +     " T01.OLD_SYSH_CBN, "
                    +     " T01.OLD_SYSH_NAME, "
                    +     " T01.KNRI_SBT, "
                    +     " T01.SHK_JIY_KBN, "
                    +     " T01.SHK_DATE, "
                    +     " T01.TKI_DATE, "
                    +     " T01.MTKIT_RYU_KBN, "
                    +     " T01.TKSS_KBN, "
                    +     " T01.KYKS_KBN, "
                    +     " T01.JOSSK_Z_KBN, "
                    +     " T01.TSK_YOT_KBN, "
                    +     " T01.KYYU_MCBN_BUNS, "
                    +     " T01.KYYU_MCBN_BUIB, "
                    +     " T01.KKCH_KBN, "
                    +     " T02.SYU_NO, "
                    +     " T02.DAI_KKSH_CD, "
                    +     " T02.DAI_KKSH_NAME, "
                    +     " T02.GNB_KKSH_CD, "
                    +     " T02.GNB_KKSH_NAME, "
                    +     " T02.JUT_KKSH_CD, "
                    +     " T02.JUT_KKSH_NAME, "
                    +     " T02.KMK_CD, "
                    +     " T02.YOT_CD, "
                    +     " T02.GENK_CTR_CD, "
                    +     " T02.GENK_CTR_NAME, "
                    +     " T02.WBS_YOS, "
                    +     " T02.WBS_NAME, "
                    +     " T02.KAN_CD, "
                    +     " T02.KAN_NAME, "
                    +     " T02.KKK_CD, "
                    +     " T02.KKT_CD, "
                    +     " T02.KKT_NAME, "
                    +     " T02.RIT_KIT_NO, "
                    +     " T02.RIT_KIT_DATE, "
                    +     " T02.MES_JOSSK, "
                    +     " T02.KNNK_TSH_KBN, "
                    +     " T02.KNNK_SBT, "
                    +     " T02.KYKA_NO, "
                    +     " T02.NNK_KKN_ST, "
                    +     " T02.NNK_KKN_EN, "
                    +     " T02.SYU_KENCH_KBN, "
                    +     " T02.SHK_KIN, "
                    +     " T02.KTSS_ZEI_TOKR_KBN, "
                    +     " T02.SYU_TCH_HOSHI, "
                    +     " T02.YKYU_STE_TCH_KBN, "
                    +     " T02.YKYU_KNR_NO, "
                    +     " T02.YKYU_STE_TCH_DATE, "
                    +     " T02.JK_SNTH_KBN, "
                    +     " T02.SUITE_JK, "
                    +     " T02.SSN_NO, "
                    +     " T03.KKT_NAME AS DHY_KKT_NAME, "
                    +     " T03.DHY_KKT_KAN_CD || '-' || T03.DHY_KKT_KKK_CD AS DHY_KKT_CD "
                    + " FROM "
                    +     " R_BKN T01 "
                    +     " INNER JOIN R_SYU_TCH T02 "
                    +     " ON  T01.BKN_NO = T02.BKN_NO "
                    +     " INNER JOIN R_KKT T03 "
                    +     " ON  T02.KAN_CD = T03.KAN_CD "
                    +     " AND T02.KKK_CD = T03.KKK_CD "
                    + " WHERE "
                    +     " T01.BKN_NO = ? "
                    + " AND T02.SYU_NO = ? ";

    /** FKSD122_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_001 = {"BKN_NO_W01", "SYU_NO_W01"};

    /** FKSD122_SELECT_002 SQL .*/
    public static final String SQL_$FKSD122_SELECT_002 =
            " SELECT "
                    +     " MAX (SHK_KAIKE_KICHO_DATE) AS SHK_KAIKE_KICHO_DATE, "
                    +     " SUM (CHOB_GENK_ZAN_KIN) AS CHOB_GENK_ZAN_KIN, "
                    +     " SUM (FUTKIN) AS FUTKIN, "
                    +     " SUM (GENS_SONS_SUM_KIN) AS GENS_SONS_SUM_KIN "
                    + " FROM "
                    +     " R_BOK_ZAN_KIN "
                    + " WHERE "
                    +     " SYU_NO = ? "
                    + " AND BKN_NO = ? "
                    + " AND SSN_NO = ? "
                    + " GROUP BY "
                    +     " SYU_NO, "
                    +     " BKN_NO, "
                    +     " SSN_NO ";

    /** FKSD122_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_002 = {"SYU_NO_W01", "BKN_NO_W01", "SSN_NO_W01"};

    /** FKSD122_SELECT_003 SQL .*/
    public static final String SQL_$FKSD122_SELECT_003 =
            " SELECT "
                    +     " ZMN_KYKS_DIS_FILE_NAME, "
                    +	  " ZMN_KYKS_PASS "
                    + " FROM "
                    +     " R_SYU_ZMN "
                    + " WHERE "
                    +     " SYU_NO = ? "
                    + " ORDER BY "
                    +	  " ZMN_RNO ";

    /** FKSD122_SELECT_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_003 = {"SYU_NO_W01"};

    /** FKSD122_SELECT_004 SQL .*/
    public static final String SQL_$FKSD122_SELECT_004 =
            " SELECT "
                    +     " SYU_TCH_BKO "
                    + " FROM "
                    +     " R_SYU_IDO_BKO "
                    + " WHERE "
                    +     " SYU_NO = ? "
                    + " AND SYU_IDO_BKO_RNO = ( "
                    +         " SELECT "
                    +             " MAX (SYU_IDO_BKO_RNO) "
                    +         " FROM "
                    +             " R_SYU_IDO_BKO "
                    +         " WHERE "
                    +             " SYU_NO = ? "
                    +     " ) ";
    /** FKSD122_SELECT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_004 = {"SYU_NO_W01", "SYU_NO_W02"};

    /** FKSD122_SELECT_005 SQL .*/
    public static final String SQL_$FKSD122_SELECT_005 =
            " SELECT "
                    +     " COUNT (T01.KYK_NO) AS COUNT "
                    + " FROM "
                    +     " R_CECJ T01 "
                    +     " INNER JOIN R_KYK_BKN T02 "
                    +     " ON  T01.KYK_NO = T02.KYK_NO "
                    + " WHERE "
                    +     " T02.BKN_NO = ? ";

    /** FKSD122_SELECT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_005 = {"BKN_NO_W01"};

    /** FKSD122_SELECT_006 SQL .*/
    public static final String SQL_$FKSD122_SELECT_006 =
            " SELECT "
                    +     " DNC_SBT, "
                    +     " DNC_SU, "
                    +     " SETB_KMK_KBN, "
                    +     " DNC_NO_1 || '-' || DNC_NO_2 || '-' || DNC_NO_3 || '-' || DNC_NO_4 || '-' || DNC_NO_5 || '-' || DNC_NO_6 AS DNC_NO "
                    + " FROM "
                    +     " R_SYU_DNC "
                    + " WHERE "
                    +     " SYU_NO = ? "
                    + " ORDER BY "
                    +     " SYU_DNC_RNO ";

    /** FKSD122_SELECT_006 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_006 = {"SYU_NO_W01"};

    /** FKSD122_SELECT_007 SQL .*/
    public static final String SQL_$FKSD122_SELECT_007 =
            " SELECT "
                    +     " T02.ZEI_INF_MES_KOB, "
                    +     " T02.ZEI_INF_MES_CMK "
                    + " FROM "
                    +     " R_SYU_TCH T01 "
                    +     " LEFT OUTER JOIN R_ZEI_INF T02 "
                    +     " ON  T01.SYU_NO = T02.SYU_NO "
                    + " WHERE "
                    +     " T01.SYU_NO = ? ";

    /** FKSD122_SELECT_007 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD122_SELECT_007 = {"SYU_NO_W01"};


    /** FKSD123_SELECT_004 SQL .*/
    public static final String SQL_$FKSD123_SELECT_004 =
            " SELECT "
                    +     " T01.KYK_NO, "
                    +     " T01.KYKSH_NO, "
                    +     " T01.DAI_KKSH_CD, "
                    +     " T01.DAI_KKSH_NAME, "
                    +     " T01.JUT_KKSH_CD, "
                    +     " T01.JUT_KKSH_NAME, "
                    +     " T01.GENK_CTR_CD, "
                    +     " T01.GENK_CTR_NAME, "
                    +     " T01.KMK_CD, "
                    +     " T01.YOT_CD, "
                    +     " T01.WBS_YOS, "
                    +     " T01.WBS_NAME, "
                    +     " T01.KAN_CD, "
                    +     " T01.KAN_NAME, "
                    +     " T01.RIT_KIT_NO, "
                    +     " T01.RIT_KIT_DATE, "
                    +     " T01.KYK_DATE, "
                    +     " T01.KYK_KKN_STA, "
                    +     " T01.KYK_KKN_END, "
                    +     " T01.AUTO_UPD_SKI, "
                    +     " T01.KAST_SUM_MES, "
                    +     " T01.DNC_KYK_SU, "
                    +     " T01.KYKS_KBN, "
                    +     " T01.JOSSK_Z_KBN, "
                    +     " T01.KAS_HOSHI, "
                    +     " T01.SKK_KBN, "
                    +     " T01.SKK, "
                    +     " T01.SKK_KMK_CD, "
                    +     " T01.NYK_SKI, "
                    +     " T01.NYK_SBT, "
                    +     " T01.KNRE_CMPY_KBN, "
                    +     " T01.SEK_HIY_HSE_KSH_CD, "
                    +     " T01.SEK_HIY_HSE_KSH_NAME, "
                    +     " T01.NYK_DATE_DYMT, "
                    +     " T01.KAST_KIN_DYMT, "
                    +     " T01.TSH_KKN_ST_DYMT, "
                    +     " T01.TSH_KKN_EN_DYMT, "
                    +     " T01.NYK_DATE_TEKIK, "
                    +     " T01.KAST_KIN_TEKIK, "
                    +     " T01.TSH_KKN_ST_TEKIK, "
                    +     " T01.TSH_KKN_EN_TEKIK, "
                    +     " T01.GNB_KKSH_CD, "
                    +     " T01.GNB_KKSH_NAME, "
                    +     " T02.KYKSH_NAME, "
                    +     " T02.KYKSH_TDFK_CD, "
                    +     " T02.KYKSH_TDFK_NAME, "
                    +     " T02.KYKSH_OOA_TSH_CD, "
                    +     " T02.KYKSH_OOA_TSH_NAME, "
                    +     " T02.KYKSH_ACM, "
                    +     " T02.KYKSH_CBN, "
                    +     " T02.KYKSH_ADD_YUB_NO_UP_3 || '-' || T02.KYKSH_ADD_YUB_NO_DWN_4 AS KYKSH_ADD_YUB_NO, "
                    +     " T02.KYKSH_TEL_NO "
                    + " FROM "
                    +     " R_KAS T01 "
                    +     " INNER JOIN R_KYKSH T02 "
                    +     " ON  T01.KYKSH_NO = T02.KYKSH_NO "
                    + " WHERE "
                    +     " T01.KYK_NO = ? ";

    /** FKSD123_SELECT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD123_SELECT_004 = {"KYK_NO_W01"};

    /** FKSD123_SELECT_005 SQL .*/
    public static final String SQL_$FKSD123_SELECT_005 =
            " SELECT "
                    +     " HMK_KBN, "
                    +     " UKE_KMK_UKE_KMK_CD, "
                    +     " BU_KBN, "
                    +     " BU_KBN_NAME, "
                    +     " UKE_KMK_HMK_WBS_YOS, "
                    +     " HMK_WBS_NAME, "
                    +     " UKE_KMK_ZEI_KBN, "
                    +     " NYK_KIN "
                    + " FROM "
                    +     " R_KAS_UKE_KMK "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " ORDER BY "
                    +	  " UKE_KMK_RNO ";

    /** FKSD123_SELECT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD123_SELECT_005 = {"KYK_NO_W01"};

    /** FKSD123_SELECT_006 SQL .*/
    public static final String SQL_$FKSD123_SELECT_006 =
            " SELECT "
                    +     " ZMN_KYKS_DIS_FILE_NAME, "
                    +     " ZMN_KYKS_PASS "
                    + " FROM "
                    +     " R_KAS_ZMN "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " ORDER BY "
                    +	  " ZMN_RNO ";

    /** FKSD123_SELECT_006 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD123_SELECT_006 = {"KYK_NO_W01"};

    /** FKSD123_SELECT_007 SQL .*/
    public static final String SQL_$FKSD123_SELECT_007 =
            " SELECT "
                    +     " KAST_HAI_KBN, "
                    +     " SYU_NO "
                    + " FROM "
                    +     " R_KAS_TSH "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " ORDER BY "
                    +	  " SYU_NO ";

    /** FKSD123_SELECT_007 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD123_SELECT_007 = {"KYK_NO_W01"};

    /** FKSD123_SELECT_008 SQL .*/
    public static final String SQL_$FKSD123_SELECT_008 =
            " SELECT "
                    +     " BKO "
                    + " FROM "
                    +     " R_KAS_IDO_BKO "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " AND KAS_BKO_SSE_RNO = ( "
                    +         " SELECT "
                    +             " MAX (KAS_BKO_SSE_RNO) "
                    +         " FROM "
                    +             " R_KAS_IDO_BKO "
                    +         " WHERE "
                    +             " KYK_NO = ? "
                    +     " ) ";
    /** FKSD123_SELECT_008 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD123_SELECT_008 = {"KYK_NO_W01", "KYK_NO_W02"};


    /** FSKD124_SELECT_008 SQL .*/
    public static final String SQL_$FSKD124_SELECT_008 =
            "SELECT "
                    +    "R_KRUK_1.KYK_NO, "
                    +    "R_KRUK_1.DAI_KKSH_CD, "
                    +    "R_KRUK_1.DAI_KKSH_NAME, "
                    +    "R_KRUK_1.GNB_KKSH_CD, "
                    +    "R_KRUK_1.GNB_KKSH_NAME, "
                    +    "R_KRUK_1.JUT_KKSH_CD, "
                    +    "R_KRUK_1.JUT_KKSH_NAME, "
                    +    "R_KRUK_1.KMK_CD, "
                    +    "R_KRUK_1.YOT_CD, "
                    +    "R_KRUK_1.KYOG_TNK_CMK_KBN, "
                    +    "R_KRUK_1.KRIUP_SHATK_TEHAI_KBN, "
                    +    "R_KRUK_1.KNRI_SBT, "
                    +    "R_KRUK_1.GENK_CTR_CD, "
                    +    "R_KRUK_1.GENK_CTR_NAME, "
                    +    "R_KRUK_1.WBS_YOS, "
                    +    "R_KRUK_1.WBS_NAME, "
                    +    "R_KRUK_1.KAN_CD, "
                    +    "R_KRUK_1.KAN_NAME, "
                    +    "R_KRUK_1.KKK_CD, "
                    +    "R_KRUK_1.KKT_CD, "
                    +    "R_KRUK_1.KKT_NAME, "
                    +    "R_KRUK_1.RIT_KIT_NO, "
                    +    "R_KRUK_1.RIT_KIT_DATE, "
                    +    "R_KRUK_1.KYK_DATE, "
                    +    "R_KRUK_1.TKI_DATE, "
                    +    "R_KRUK_1.KYK_KKN_STA, "
                    +    "R_KRUK_1.KYK_KKN_END, "
                    +    "R_KRUK_1.AUTO_UPD_SKI, "
                    +    "R_KRUK_1.SHKT_SUM_MES, "
                    +    "R_KRUK_1.DNC_KYK_SU, "
                    +    "R_KRUK_1.KYYU_MCBN_BUNS, "
                    +    "R_KRUK_1.KYYU_MCBN_BUIB, "
                    +    "R_KRUK_1.MTKIT_RYU_KBN, "
                    +    "R_KRUK_1.TKSS_KBN, "
                    +    "R_KRUK_1.KYKS_KBN, "
                    +    "R_KRUK_1.JOSSK_Z_KBN, "
                    +    "R_KRUK_1.KNNK_TSH_KBN, "
                    +    "R_KRUK_1.KNNK_SBT, "
                    +    "R_KRUK_1.KYKA_NO, "
                    +    "R_KRUK_1.KYKA_KKN_ST, "
                    +    "R_KRUK_1.KYKA_KKN_EN, "
                    +    "R_KRUK_1.KRUK_HOSHI, "
                    +    "R_KRUK_1.KYKSH_NO, "
                    +    "R_KRUK_1.SKK_KBN, "
                    +    "R_KRUK_1.SKK, "
                    +    "R_KRUK_1.SKK_SHR_KBN, "
                    +    "R_KRUK_1.SKK_SHR_KMK, "
                    +    "R_KRUK_1.REK_CTR_CD, "
                    +    "R_KRUK_1.REK_CTR_NAME, "
                    +    "R_KRUK_1.SHR_SKI_KBN, "
                    +    "R_KRUK_1.SHR_SBT, "
                    +    "R_KRUK_1.KNRE_CMPY_KBN, "
                    +    "R_KRUK_1.SEK_HIY_HSE_KSH_CD, "
                    +    "R_KRUK_1.SEK_HIY_HSE_KSH_NAME, "
                    +    "R_KRUK_1.SHR_DATE_DYMT, "
                    +    "R_KRUK_1.TSH_KKN_ST_DYMT, "
                    +    "R_KRUK_1.TSH_KKN_EN_DYMT, "
                    +    "R_KRUK_1.SO_SHR_KIN_DYMT, "
                    +    "R_KRUK_1.SHR_DATE_TEKIK, "
                    +    "R_KRUK_1.TSH_KKN_ST_TEKIK, "
                    +    "R_KRUK_1.TSH_KKN_EN_TEKIK, "
                    +    "R_KRUK_1.SO_SHR_KIN_TEKIK, "
                    +    "R_KRUK_1.SSN_NO, "
                    +    "R_KYKSH_1.KYKSH_NAME, "
                    +    "R_KYKSH_1.KYKSH_TDFK_CD, "
                    +    "R_KYKSH_1.KYKSH_TDFK_NAME, "
                    +    "R_KYKSH_1.KYKSH_OOA_TSH_CD, "
                    +    "R_KYKSH_1.KYKSH_OOA_TSH_NAME, "
                    +    "R_KYKSH_1.KYKSH_ACM, "
                    +    "R_KYKSH_1.KYKSH_CBN, "
                    +    "R_KYKSH_1.KYKSH_ADD_YUB_NO_UP_3 || '-' || R_KYKSH_1.KYKSH_ADD_YUB_NO_DWN_4 AS KYKSH_ADD_YUB_NO, "
                    +    "R_KYKSH_1.KYKSH_TEL_NO "
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    +    "INNER JOIN "
                    +        "R_KYKSH AS R_KYKSH_1 "
                    +    "    ON R_KRUK_1.KYKSH_NO = R_KYKSH_1.KYKSH_NO "
                    + "WHERE "
                    +    "R_KRUK_1.KYK_NO = ? ";

    /** FSKD124_SELECT_008 �p�����[�^��` .*/
    public static final String[] PARAM_$FSKD124_SELECT_008 = {"KYK_NO_W01"};

    /** FSKD124_SELECT_009 SQL .*/
    public static final String SQL_$FSKD124_SELECT_009 =
            "SELECT "
                    +    "HMK_KBN, "
                    +    "SHR_KMK_CD, "
                    +    "BU_KBN, "
                    +    "BU_KBN_NAME, "
                    +    "HMK_WBS_YOS, "
                    +    "SHR_KMK_HMK_WBS_NAME, "
                    +    "ZEI_KBN, "
                    +    "PAY_PRC "
                    + "FROM  "
                    +    "R_KRUK_SHR_KMK AS R_KRUK_SHR_KMK_1 "
                    + "WHERE "
                    +    "R_KRUK_SHR_KMK_1.KYK_NO = ? ";

    /** FSKD124_SELECT_009 �p�����[�^��` .*/
    public static final String[] PARAM_$FSKD124_SELECT_009 = {"KYK_NO_W01"};

    /** FSKD124_SELECT_010 SQL .*/
    public static final String SQL_$FSKD124_SELECT_010 =
            "SELECT "
                    +    "BKN_NO "
                    + "FROM  "
                    +    "R_KYK_BKN AS R_KYK_BKN_1 "
                    + "WHERE "
                    +    "R_KYK_BKN_1.KYK_NO = ? ";

    /** FSKD124_SELECT_010 �p�����[�^��` .*/
    public static final String[] PARAM_$FSKD124_SELECT_010 = {"KYK_NO_W01"};

    /** FSKD124_SELECT_011 SQL .*/
    public static final String SQL_$FSKD124_SELECT_011 =
            "SELECT "
                    +    "BKN_NO, "
                    +    "TDFK_CD, "
                    +    "TDFK_NAME, "
                    +    "BKN_OOA_TSH_CD, "
                    +    "OOA_TSH_NAME, "
                    +    "BKN_ACM, "
                    +    "BKN_CBN, "
                    +    "TET_NO_NO || '-' || TET_NO_DNO AS TET_NO, "
                    +    "CMK_KOB_KBN, "
                    +    "CMK_GEK_KBN, "
                    +    "MES_KOB, "
                    +    "SHKT_HAI_KBN, "
                    +    "DNC_SBT, "
                    +    "DNC_NO_1 || '-' || DNC_NO_2 || '-' || DNC_NO_3 || '-' || DNC_NO_4 || '-' || DNC_NO_5 || '-' || DNC_NO_6 AS DNC_NO, "
                    +    "TNK_KBN, "
                    +    "SHKT_KNRI_TKA, "
                    +    "SHKT_KNRI_STE_MES "
                    + "FROM  "
                    +    "R_BKN AS R_BKN_1 "
                    + "WHERE "
                    +    "R_BKN_1.BKN_NO = ? ";

    /** FSKD124_SELECT_011 �p�����[�^��` .*/
    public static final String[] PARAM_$FSKD124_SELECT_011 = {"BKN_NO_W01"};

    /** FKSD124_SELECT_012 SQL .*/
    public static final String SQL_$FKSD124_SELECT_012 =
            " SELECT "
                    +     " BKO "
                    + " FROM "
                    +     " R_KRUK_IDO_BKO "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " AND KRUK_IDO_BKO_RNO = ( "
                    +         " SELECT "
                    +             " MAX (KRUK_IDO_BKO_RNO) "
                    +         " FROM "
                    +             " R_KRUK_IDO_BKO "
                    +         " WHERE "
                    +             " KYK_NO = ? "
                    +     " ) ";
    /** FKSD124_SELECT_012 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD124_SELECT_012 = {"KYK_NO_W01", "KYK_NO_W02"};

    /** FKSD124_SELECT_013 SQL .*/
    public static final String SQL_$FKSD124_SELECT_013 =
            " SELECT "
                    +     " ZMN_KYKS_DIS_FILE_NAME, "
                    +     " ZMN_KYKS_PASS "
                    + " FROM "
                    +     " R_KRUK_ZMN "
                    + " WHERE "
                    +     " KYK_NO = ? "
                    + " ORDER BY "
                    +	  " ZMN_RNO ";

    /** FKSD124_SELECT_013 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD124_SELECT_013 = {"KYK_NO_W01"};


    /** FKSD128_SELECT_001 SQL .*/
    // ** �ڍא݌v�����Q�� (�ЗL�y�n�̕뉿�����𒊏o����) ** //
    public static final String SQL_$FKSD128_SELECT_001 =
            "SELECT "
                    +    "E_SYU_TOK_1.BKN_NO, "
                    +    "E_SYU_BOK_RRK_SSE_DTL_1.SS_KBN, "
                    +    "E_SYU_BOK_RRK_SSE_DTL_1.BOK_IDO_SBT AS IDO_SBT, "
                    +    "E_SYU_BOK_RRK_SSE_DTL_1.KAIKE_KICHO_DATE, "
                    +    "E_SYU_BOK_RRK_SSE_DTL_1.CHOB_GENK_UD_KIN "
                    + "FROM "
                    +    "E_SYU_TOK AS E_SYU_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SYU_BOK_RRK_SSE_DTL AS E_SYU_BOK_RRK_SSE_DTL_1 ON  "
                    +        "E_SYU_TOK_1.SYU_TOK_NO = E_SYU_BOK_RRK_SSE_DTL_1.SYU_TOK_NO "
                    + "WHERE "
                    +    "E_SYU_TOK_1.SYU_NO LIKE ? AND "
                    +    "E_SYU_TOK_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_SYU_BOK_RRK_SSE_DTL_1.KAIKE_KICHO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD128_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD128_SELECT_001 = {"SYU_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD128_SELECT_001_CNT SQL. */
    public static final String SQL_$FKSD128_SELECT_001_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM "
                    +    "E_SYU_TOK AS E_SYU_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SYU_BOK_RRK_SSE_DTL AS E_SYU_BOK_RRK_SSE_DTL_1 ON  "
                    +        "E_SYU_TOK_1.SYU_TOK_NO = E_SYU_BOK_RRK_SSE_DTL_1.SYU_TOK_NO "
                    + "WHERE "
                    +    "E_SYU_TOK_1.SYU_NO LIKE ? AND "
                    +    "E_SYU_TOK_1.BKN_NO LIKE ? ";

    /** FKSD128_SELECT_001_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD128_SELECT_001_CNT = {"SYU_NO_W01", "BKN_NO_W01"};

    /** FKSD128_SELECT_002 SQL .*/
    // ** �ڍא݌v�����Q�� (�؎�̕뉿�����𒊏o����) ** //
    public static final String SQL_$FKSD128_SELECT_002 =
            "SELECT "
                    +    "E_KRUK_BOK_SSE_DTL_1.BKN_NO, "
                    +    "E_KRUK_BOK_SSE_DTL_1.SS_KBN, "
                    +    "E_KRUK_BOK_SSE_DTL_1.IDO_SBT , "
                    +    "E_KRUK_BOK_SSE_DTL_1.KAIKE_KICHO_DATE, "
                    +    "E_KRUK_BOK_SSE_DTL_1.CHOB_GENK_UD_KIN "
                    + "FROM  "
                    +    "E_KRUK_TOK AS E_KRUK_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KRUK_BOK_SSE_DTL AS E_KRUK_BOK_SSE_DTL_1 ON  "
                    +        "E_KRUK_TOK_1.KRUK_TOK_NO = E_KRUK_BOK_SSE_DTL_1.KRUK_TOK_NO "
                    + "WHERE "
                    +    "E_KRUK_TOK_1.KYK_NO LIKE ? AND "
                    +    "E_KRUK_BOK_SSE_DTL_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_KRUK_BOK_SSE_DTL_1.KAIKE_KICHO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD128_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD128_SELECT_002 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD128_SELECT_002_CNT SQL. */
    public static final String SQL_$FKSD128_SELECT_002_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_KRUK_TOK AS E_KRUK_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KRUK_BOK_SSE_DTL AS E_KRUK_BOK_SSE_DTL_1 ON  "
                    +        "E_KRUK_TOK_1.KRUK_TOK_NO = E_KRUK_BOK_SSE_DTL_1.KRUK_TOK_NO "
                    + "WHERE "
                    +    "E_KRUK_TOK_1.KYK_NO LIKE ? AND "
                    +    "E_KRUK_BOK_SSE_DTL_1.BKN_NO LIKE ? ";

    /** FKSD128_SELECT_002_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD128_SELECT_002_CNT = {"KYK_NO_W01", "BKN_NO_W01"};

    /** FKSD128_SELECT_003 SQL .*/
    // ** �ڍא݌v�����Q�� (�n�����n�㌠�̕뉿�����𒊏o����) ** //
    public static final String SQL_$FKSD128_SELECT_003 =
            "SELECT "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.SS_KBN, "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.IDO_SBT, "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.KAIKE_KICHO_DATE, "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.CHOB_GENK_UD_KIN, "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.BKN_NO "
                    + "FROM  "
                    +    "E_CECJ_TOK AS E_CECJ_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_CECJ_BOK_RRK_SSE_DTL AS E_CECJ_BOK_RRK_SSE_DTL_1 ON  "
                    +        "E_CECJ_TOK_1.CECJ_TOK_NO = E_CECJ_BOK_RRK_SSE_DTL_1.CECJ_TOK_NO "
                    + "WHERE "
                    +    "E_CECJ_TOK_1.KYK_NO LIKE ? AND "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.KAIKE_KICHO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD128_SELECT_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD128_SELECT_003 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD128_SELECT_003_CNT SQL. */
    public static final String SQL_$FKSD128_SELECT_003_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_CECJ_TOK AS E_CECJ_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_CECJ_BOK_RRK_SSE_DTL AS E_CECJ_BOK_RRK_SSE_DTL_1 ON  "
                    +        "E_CECJ_TOK_1.CECJ_TOK_NO = E_CECJ_BOK_RRK_SSE_DTL_1.CECJ_TOK_NO "
                    + "WHERE "
                    +    "E_CECJ_TOK_1.KYK_NO LIKE ? AND "
                    +    "E_CECJ_BOK_RRK_SSE_DTL_1.BKN_NO LIKE ? ";

    /** FKSD128_SELECT_003_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD128_SELECT_003_CNT = {"KYK_NO_W01", "BKN_NO_W01"};


    /** FKSD129_SELECT_001 SQL .*/
    // ** �ڍא݌v�����Q�� (�ЗL�y�n�̔��l�𒊏o����) ** //
    public static final String SQL_$FKSD129_SELECT_001 =
            "SELECT "
                    +    "E_SYU_TOK_BKO_DTL_1.SS_KBN, "
                    +    "E_SYU_TOK_BKO_DTL_1.IDO_DATE, "
                    +    "E_SYU_TOK_BKO_DTL_1.SYU_BKO AS BKO "
                    + "FROM  "
                    +    "E_SYU_TOK AS E_SYU_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SYU_TOK_BKO_DTL AS E_SYU_TOK_BKO_DTL_1 ON  "
                    +    "    E_SYU_TOK_1.SYU_TOK_NO = E_SYU_TOK_BKO_DTL_1.SYU_TOK_NO "
                    + "WHERE "
                    +    "E_SYU_TOK_1.SYU_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_SYU_TOK_BKO_DTL_1.IDO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD129_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD129_SELECT_001 = {"SYU_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD129_SELECT_001_CNT SQL. */
    public static final String SQL_$FKSD129_SELECT_001_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_SYU_TOK AS E_SYU_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SYU_TOK_BKO_DTL AS E_SYU_TOK_BKO_DTL_1 ON  "
                    +    "    E_SYU_TOK_1.SYU_TOK_NO = E_SYU_TOK_BKO_DTL_1.SYU_TOK_NO "
                    + "WHERE "
                    +    "E_SYU_TOK_1.SYU_NO LIKE ? ";

    /** FKSD129_SELECT_001_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD129_SELECT_001_CNT = {"SYU_NO_W01"};

    /** FKSD129_SELECT_002 SQL .*/
    // ** �ڍא݌v�����Q�� (�n�����n�㌠�̔��l�𒊏o����) ** //
    public static final String SQL_$FKSD129_SELECT_002 =
            "SELECT "
                    +    "E_CECJ_BKO_DTL_1.SS_KBN, "
                    +    "E_CECJ_BKO_DTL_1.IDO_DATE, "
                    +    "E_CECJ_BKO_DTL_1.BKO "
                    + "FROM  "
                    +    "E_CECJ_TOK AS E_CECJ_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_CECJ_BKO_DTL AS E_CECJ_BKO_DTL_1 ON  "
                    +    "    E_CECJ_TOK_1.CECJ_TOK_NO = E_CECJ_BKO_DTL_1.CECJ_TOK_NO "
                    + "WHERE "
                    +    "E_CECJ_TOK_1.KYK_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_CECJ_BKO_DTL_1.IDO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD129_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD129_SELECT_002 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD129_SELECT_002_CNT SQL. */
    public static final String SQL_$FKSD129_SELECT_002_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_CECJ_TOK AS E_CECJ_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_CECJ_BKO_DTL AS E_CECJ_BKO_DTL_1 ON  "
                    +    "    E_CECJ_TOK_1.CECJ_TOK_NO = E_CECJ_BKO_DTL_1.CECJ_TOK_NO "
                    + "WHERE "
                    +    "E_CECJ_TOK_1.KYK_NO LIKE ? ";

    /** FKSD129_SELECT_002_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD129_SELECT_002_CNT = {"KYK_NO_W01"};

    /** FKSD129_SELECT_003 SQL .*/
    // ** �ڍא݌v�����Q�� (�؎�̔��l�𒊏o����) ** //
    public static final String SQL_$FKSD129_SELECT_003 =
            "SELECT "
                    +    "E_KRUK_BKO_DTL_1.SS_KBN, "
                    +    "E_KRUK_BKO_DTL_1.IDO_DATE, "
                    +    "E_KRUK_BKO_DTL_1.BKO "
                    + "FROM  "
                    +    "E_KRUK_TOK AS E_KRUK_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KRUK_BKO_DTL AS E_KRUK_BKO_DTL_1 ON  "
                    +    "    E_KRUK_TOK_1.KRUK_TOK_NO = E_KRUK_BKO_DTL_1.KRUK_TOK_NO "
                    + "WHERE "
                    +    "E_KRUK_TOK_1.KYK_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_KRUK_BKO_DTL_1.IDO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD129_SELECT_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD129_SELECT_003 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD129_SELECT_003_CNT SQL. */
    public static final String SQL_$FKSD129_SELECT_003_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_KRUK_TOK AS E_KRUK_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KRUK_BKO_DTL AS E_KRUK_BKO_DTL_1 ON  "
                    +    "    E_KRUK_TOK_1.KRUK_TOK_NO = E_KRUK_BKO_DTL_1.KRUK_TOK_NO "
                    + "WHERE "
                    +    "E_KRUK_TOK_1.KYK_NO LIKE ? ";

    /** FKSD129_SELECT_003_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD129_SELECT_003_CNT = {"KYK_NO_W01"};

    /** FKSD129_SELECT_004 SQL .*/
    // ** �ڍא݌v�����Q�� (��L�̔��l�𒊏o����) ** //
    public static final String SQL_$FKSD129_SELECT_004 =
            "SELECT "
                    +    "E_SEY_BKO_DTL_1.SS_KBN, "
                    +    "E_SEY_BKO_DTL_1.IDO_DATE, "
                    +    "E_SEY_BKO_DTL_1.BKO "
                    + "FROM  "
                    +    "E_SEY_TOK AS E_SEY_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SEY_BKO_DTL AS E_SEY_BKO_DTL_1 ON  "
                    +    "    E_SEY_TOK_1.SEY_TOK_NO = E_SEY_BKO_DTL_1.SEY_TOK_NO "
                    + "WHERE "
                    +    "E_SEY_TOK_1.KYK_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_SEY_BKO_DTL_1.IDO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD129_SELECT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD129_SELECT_004 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD129_SELECT_004_CNT SQL. */
    public static final String SQL_$FKSD129_SELECT_004_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_SEY_TOK AS E_SEY_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_SEY_BKO_DTL AS E_SEY_BKO_DTL_1 ON  "
                    +    "    E_SEY_TOK_1.SEY_TOK_NO = E_SEY_BKO_DTL_1.SEY_TOK_NO "
                    + "WHERE "
                    +    "E_SEY_TOK_1.KYK_NO LIKE ? ";
    /** FKSD129_SELECT_004_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD129_SELECT_004_CNT = {"KYK_NO_W01"};

    /** FKSD129_SELECT_005 SQL .*/
    // ** �ڍא݌v�����Q�� (�ݕt�̔��l�𒊏o����) ** //
    public static final String SQL_$FKSD129_SELECT_005 =
            "SELECT "
                    +    "E_KAS_BKO_DTL_1.SS_KBN, "
                    +    "E_KAS_BKO_DTL_1.IDO_DATE, "
                    +    "E_KAS_BKO_DTL_1.BKO "
                    + "FROM  "
                    +    "E_KAS_TOK AS E_KAS_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KAS_BKO_DTL AS E_KAS_BKO_DTL_1 ON  "
                    +    "    E_KAS_TOK_1.KAS_TOK_NO = E_KAS_BKO_DTL_1.KAS_TOK_NO "
                    + "WHERE "
                    +    "E_KAS_TOK_1.KYK_NO LIKE ? "
                    + "ORDER BY "
                    +    "E_KAS_BKO_DTL_1.IDO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD129_SELECT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD129_SELECT_005 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD129_SELECT_005_CNT SQL. */
    public static final String SQL_$FKSD129_SELECT_005_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "E_KAS_TOK AS E_KAS_TOK_1 "
                    +    "INNER JOIN "
                    +        "E_KAS_BKO_DTL AS E_KAS_BKO_DTL_1 ON  "
                    +    "    E_KAS_TOK_1.KAS_TOK_NO = E_KAS_BKO_DTL_1.KAS_TOK_NO "
                    + "WHERE "
                    +    "E_KAS_TOK_1.KYK_NO LIKE ? ";
    /** FKSD129_SELECT_005_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD129_SELECT_005_CNT = {"KYK_NO_W01"};

    /** FKSD130_SELECT_001 SQL .*/
    // ** �ڍא݌v�����Q�� (�ЗL�y�n�̕⎆�𒊏o����) ** //
    public static final String SQL_$FKSD130_SELECT_001 =
            "SELECT "
                    +    "SYU_NO, "
                    +    "BKN_NO, "
                    +    "SYU_TCH_HOSHI as HOSHI "
                    + "FROM  "
                    +    "R_SYU_TCH AS R_SYU_TCH_1 "
                    + "WHERE "
                    +    "R_SYU_TCH_1.SYU_NO LIKE ? AND "
                    +    "R_SYU_TCH_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "R_SYU_TCH_1.SYU_NO ASC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD130_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_001 = {"SYU_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD130_SELECT_001_CNT SQL .*/
    public static final String SQL_$FKSD130_SELECT_001_CNT =
            "SELECT "
                    + " COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "R_SYU_TCH AS R_SYU_TCH_1 "
                    + "WHERE "
                    +    "R_SYU_TCH_1.SYU_NO LIKE ? AND "
                    +    "R_SYU_TCH_1.BKN_NO LIKE ? ";
    /** FKSD130_SELECT_001_CNT �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_001_CNT = {"SYU_NO_W01", "BKN_NO_W01"};

    /** FKSD130_SELECT_002 SQL .*/
    // ** �ڍא݌v�����Q�� (�n�����n�㌠�̕⎆�𒊏o����) ** //
    public static final String SQL_$FKSD130_SELECT_002 =
            "SELECT "
                    +    "R_CECJ_1.KYK_NO, "
                    +    "R_CECJ_1.CECJ_HOSHI as HOSHI, "
                    +    "KYK_BKN_1.BKN_NO "
                    + "FROM  "
                    +    "R_CECJ AS R_CECJ_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_CECJ_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_CECJ_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "R_CECJ_1.KYK_NO ASC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD130_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_002 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD130_SELECT_002_CNT SQL .*/
    public static final String SQL_$FKSD130_SELECT_002_CNT =
            "SELECT "
                    + " COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "R_CECJ AS R_CECJ_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_CECJ_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_CECJ_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? ";
    /** FKSD130_SELECT_002_CNT �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_002_CNT = {"KYK_NO_W01", "BKN_NO_W01"};

    /** FKSD130_SELECT_003 SQL .*/
    //** �ڍא݌v�����Q�� (�؎�̕⎆�𒊏o����) ** //
    public static final String SQL_$FKSD130_SELECT_003 =
            "SELECT "
                    +    "R_KRUK_1.KYK_NO, "
                    +    "R_KRUK_1.KRUK_HOSHI as HOSHI, "
                    +    "KYK_BKN_1.BKN_NO "
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_KRUK_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_KRUK_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "R_KRUK_1.KYK_NO ASC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD130_SELECT_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_003 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD130_SELECT_003_CNT SQL .*/
    public static final String SQL_$FKSD130_SELECT_003_CNT =
            "SELECT "
                    + " COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_KRUK_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_KRUK_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? ";
    /** FKSD130_SELECT_003_CNT �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_003_CNT = {"KYK_NO_W01", "BKN_NO_W01"};

    /** FKSD130_SELECT_004 SQL .*/
    // ** �ڍא݌v�����Q�� (�ݕt�̕⎆�𒊏o����) ** //
    public static final String SQL_$FKSD130_SELECT_004 =
            "SELECT "
                    +    "R_KAS_1.KYK_NO, "
                    +    "R_KAS_1.KAS_HOSHI as HOSHI, "
                    +    "KYK_BKN_1.BKN_NO "
                    + "FROM  "
                    +    "R_KAS AS R_KAS_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_KAS_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_KAS_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "R_KAS_1.KYK_NO ASC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD130_SELECT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_004 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD130_SELECT_004 SQL_CNT .*/
    public static final String SQL_$FKSD130_SELECT_004_CNT =
            "SELECT "
                    + " COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "R_KAS AS R_KAS_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_KAS_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_KAS_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? ";
    /** FKSD130_SELECT_004_CNT �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_004_CNT = {"KYK_NO_W01", "BKN_NO_W01"};

    /** FKSD130_SELECT_005 SQL .*/
    // ** �ڍא݌v�����Q�� (��p�̕⎆�𒊏o����) ** //
    public static final String SQL_$FKSD130_SELECT_005 =
            "SELECT "
                    +    "R_SEY_1.KYK_NO, "
                    +    "R_SEY_1.SEY_HOSHI as HOSHI, "
                    +    "KYK_BKN_1.BKN_NO "
                    + "FROM  "
                    +    "R_SEY AS R_SEY_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_SEY_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_SEY_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? "
                    + "ORDER BY "
                    +    "R_SEY_1.KYK_NO ASC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";
    /** FKSD130_SELECT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_005 = {"KYK_NO_W01", "BKN_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD130_SELECT_005 SQL_CNT .*/
    public static final String SQL_$FKSD130_SELECT_005_CNT =
            "SELECT "
                    + " COUNT(*) AS COUNT "
                    + "FROM  "
                    +    "R_SEY AS R_SEY_1 "
                    +    "INNER JOIN "
                    +        "R_KYK_BKN AS KYK_BKN_1 ON  "
                    +    "    R_SEY_1.KYK_NO = KYK_BKN_1.KYK_NO "
                    + "WHERE "
                    +    "R_SEY_1.KYK_NO LIKE ? AND "
                    +    "KYK_BKN_1.BKN_NO LIKE ? ";
    /** FKSD130_SELECT_005_CNT �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD130_SELECT_005_CNT = {"KYK_NO_W01", "BKN_NO_W01"};

    /** FKSD134_SELECT_001 SQL .*/
    public static final String SQL_$FKSD134_SELECT_001 =
            " SELECT  "
                    + " R_CHOHY.CHOHY_ID, R_CHOHY.CHOHY_NAME, R_CHOHY_CRE_NOTC_STE.CHOHY_ID AS KJYUN"
                    + " FROM "
                    + " R_CHOHY "
                    + " LEFT OUTER JOIN "
                    + " (SELECT CHOHY_ID  "
                    + " FROM R_CHOHY_CRE_NOTC_STE "
                    + " WHERE USR_ID = ? "
                    + " ) AS R_CHOHY_CRE_NOTC_STE "
                    + " ON  "
                    + " R_CHOHY.CHOHY_ID = R_CHOHY_CRE_NOTC_STE.CHOHY_ID "
                    + " WHERE "
                    + " R_CHOHY.CHOHY_ID NOT IN('FKSR001','FKSR002','FKSR003','FKSR004','FKSR005','FKSR006','FKSR007','FKSR008') "
                    + " AND "
                    + " R_CHOHY.CHOHY_NAME LIKE ? ";
    /** FKSD134_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD134_SELECT_001 = {"USR_ID_W01", "CHOHY_NAME_W01" };

    /** FKSD134_DELETE_001 SQL. */
    public static final String SQL_$FKSD134_DELETE_001 =
            " DELETE FROM  "
                    + " R_CHOHY_CRE_NOTC_STE  "
                    + " WHERE  "
                    + " CHOHY_ID = ? "
                    + " AND "
                    + " USR_ID = ?";
    /** FKSD134_DELETE_001 �p�����[�^��`. */
    public static final String[] PARAM_$FKSD134_DELETE_001 = {"CHOHY_ID", "USR_ID"};

    /** FKSD134_INSERT_001 SQL. */
    public static final String SQL_$FKSD134_INSERT_001 =
            " INSERT INTO R_CHOHY_CRE_NOTC_STE ( "
                    + " CHOHY_ID, "
                    + " USR_ID , "
                    + " UPD_USR , "
                    + " UPD_DATE "
                    + " ) VALUES ( "
                    + " ?, "
                    + " ?, "
                    + " ?, "
                    + " ?, "
                    + " )";
    /** FKSD134_INSERT_001 �p�����[�^��`. */
    public static final String[] PARAM_$FKSD134_INSERT_001 = {"CHOHY_ID", "USR_ID", "UPD_USR", "UPD_DATE"};



    // ********************************************/
    /* �}�X�^�����e�Ɩ�_���[�U�[�Ǘ�              */
    // ********************************************/

    /** FKSD140_SELECT_001 SQL. */
    public static final String SQL_$FKSD140_SELECT_001 =
            " SELECT "
                    + " 	USR_ID,"
                    + " 	USR_NAME,"
                    + " 	JGSH_CD,"
                    + " 	MAIL_ADDRES,"
                    + " 	SHIMEI_CD,"
                    + " 	KNR_SHA_KBN,"
                    + " 	SYNN_SYA_CD_1,"
                    + " 	SYNN_SYA_CD_2,"
                    + "		DAI_SRCH_KBN,"
                    + "		DAI_UPD_KBN,"
                    + "		USR_BKO,"
                    + "		MAIL_NOTC_KBN,"
                    + "		DEL_KBN,"
                    + "		UPD_USR,"
                    + "		UPD_DATE"
                    + " FROM"
                    + "		R_USR"
                    + " WHERE"
                    + "			USR_ID LIKE ?"
                    + "		AND	JGSH_CD LIKE ?"
                    + "	ORDER BY"
                    + "		KNR_SHA_KBN DESC,"
                    + "		JGSH_CD ASC,"
                    + "		USR_ID ASC"
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD140_SELECT_001 �p�����[�^��`. */
    public static final String[] PARAM_$FKSD140_SELECT_001 = {"USR_ID_W01", "JGSH_CD_W01", "LIMIT", "OFFSET"};

    /** FKSD140_SELECT_001_CNT SQL. */
    public static final String SQL_$FKSD140_SELECT_001_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT"
                    + " FROM"
                    + "		R_USR"
                    + " WHERE"
                    + "			USR_ID LIKE ?"
                    + "		AND	JGSH_CD LIKE ?";

    /** FKSD140_SELECT_001_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD140_SELECT_001_CNT = {"USR_ID_W01", "JGSH_CD_W01"};

    /** FKSD140_DELETE_001 SQL. */
    public static final String SQL_$FKSD140_DELETE_001 =
            "DELETE "
                    + "FROM "
                    +    "R_USR "
                    + "WHERE "
                    +    "USR_ID = ? ";

    /** FKSD140_DELETE_001 �p�����[�^��`. */
    public static final String[] PARAM_$FKSD140_DELETE_001 = {"USR_ID_W01"};

    /** FKSD140_INSERT_001 SQL. */
    public static final String SQL_$FKSD140_INSERT_001 =
            "INSERT INTO R_USR ( "
                    +    "USR_ID, "
                    +    "USR_NAME, "
                    +    "JGSH_CD, "
                    +    "MAIL_ADDRES, "
                    +    "SHIMEI_CD, "
                    +    "KNR_SHA_KBN, "
                    +    "SYNN_SYA_CD_1, "
                    +    "SYNN_SYA_CD_2, "
                    +    "DAI_SRCH_KBN, "
                    +    "DAI_UPD_KBN, "
                    +    "USR_BKO, "
                    +    "MAIL_NOTC_KBN, "
                    +    "DEL_KBN, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD140_INSERT_001 �p�����[�^��`. */
    public static final String[] PARAM_$FKSD140_INSERT_001 = {"USR_ID", "USR_NAME", "JGSH_CD", "MAIL_ADDRES", "SHIMEI_CD", "KNR_SHA_KBN",
        "SYNN_SYA_CD_1", "SYNN_SYA_CD_2", "DAI_SRCH_KBN", "DAI_UPD_KBN", "USR_BKO", "MAIL_NOTC_KBN", "DEL_KBN", "UPD_USR", "UPD_DATE"};

    /** FKSD141_SELECT_001 SQL .*/
    public static final String SQL_$FKSD141_SELECT_001 =
            "SELECT "
                    +    "JGSH_CD, "
                    +    "JGSH_NAME, "
                    +    "DAT_YORYO_KBN, "
                    +    "SHRCHS_DAT_KKSH_CD, "
                    +    "JGSH_ADD_1, "
                    +    "JGSH_ADD_2, "
                    +    "JGSH_TEL_NO, "
                    +    "JGSH_BKO "
                    +	"FROM "
                    +		"R_JGSH "
                    +	"ORDER BY "
                    +		"R_JGSH.JGSH_CD ASC ";

    /** FKSD141_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD141_SELECT_001 = {};

    /** FKSD141_DELETE_001 SQL .*/
    public static final String SQL_$FKSD141_DELETE_001 =
            "DELETE "
                    +	"FROM "
                    +		"R_JGSH";

    /** FKSD141_DELETE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD141_DELETE_001 = {};

    /** FKSD141_INSERT_001 SQL .*/
    public static final String SQL_$FKSD141_INSERT_001 =
            "INSERT INTO R_JGSH ( "
                    +    "JGSH_CD, "
                    +    "JGSH_NAME, "
                    +    "DAT_YORYO_KBN, "
                    +    "SHRCHS_DAT_KKSH_CD, "
                    +    "JGSH_ADD_1, "
                    +    "JGSH_ADD_2, "
                    +    "JGSH_TEL_NO, "
                    +    "JGSH_BKO, "
                    +    "DHY_SFSK_KBN, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD141_INSERT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD141_INSERT_001 = {"JGSH_CD", "JGSH_NAME", "DAT_YORYO_KBN", "SHRCHS_DAT_KKSH_CD", "JGSH_ADD_1", "JGSH_ADD_2", "JGSH_TEL_NO", "JGSH_BKO", "DHY_SFSK_KBN", "UPD_USR", "UPD_DATE" };

    //�}�X�^�����e�Ɩ��|���c�P������

    /** FKSD142_SELECT_001 SQL .*/
    public static final String SQL_$FKSD142_SELECT_001 =
            "SELECT "
                    +    "KYOG_TNK_SBT, "
                    +    "KYOG_TNK_CD, "
                    +    "TND, "
                    +    "TND_KYOG_TNK, "
                    +    "YKND, "
                    +    "YKND_KYOG_TNK, "
                    +    "LST_OUT_KBN, "
                    +    "DAI_UPD_SHJ_KBN, "
                    +    "KYOG_TNK_UPD_DATE "
                    + "FROM  "
                    +    "R_KYOG_TNK AS R_KYOG_TNK_1 ";

    /** FKSD142_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD142_SELECT_001 = {};

    /** FKSD142_UPDATE_001 SQL .*/
    public static final String SQL_$FKSD142_UPDATE_001 =
            "UPDATE "
                    +    "R_KYOG_TNK "
                    + "SET "
                    +    "TND_KYOG_TNK = ? , "
                    +    "YKND_KYOG_TNK = ? , "
                    +    "KYOG_TNK_UPD_DATE = ? , "
                    +    "LST_OUT_KBN = ?, "
                    +    "DAI_UPD_SHJ_KBN = ?, "
                    +    "UPD_USR = ? , "
                    +    "UPD_DATE = ?  "
                    + "WHERE "
                    +    "KYOG_TNK_SBT = ? AND "
                    +    "KYOG_TNK_CD = ? ";

    /** FKSD142_UPDATE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD142_UPDATE_001 = {"TND_KYOG_TNK", "YKND_KYOG_TNK", "KYOG_TNK_UPD_DATE", "LST_OUT_KBN", "DAI_UPD_SHJ_KBN", "UPD_USR", "UPD_DATE", "KYOG_TNK_SBT_W01", "KYOG_TNK_CD_W01"};


    /** FKSD144_SELECT_001 SQL .*/
    public static final String SQL_$FKSD144_SELECT_001 =
            "SELECT "
                    +    "SETBKJ_WBS_YOS, "
                    +    "SETBKJ_FST_SHK_DATE, "
                    +    "SETBKJ_SSN_CALSS, "
                    +    "SETBKJ_KOU_CD, "
                    +    "SETBKJ_KENKR_KAN_CD, "
                    +    "SETBKJ_KAN_CD, "
                    +    "SETBKJ_SETB_KMK_CD, "
                    +    "SETBKJ_GENK_CTR_CD, "
                    +    "DAI_KKSH_CD, "
                    +    "GNB_KKSH_CD, "
                    +    "JUT_KKSH_CD, "
                    +    "SETBKJ_KESSN_CHOB_GENK_SUM, "
                    +    "SETBKJ_KESSN_SHK_KIN, "
                    +    "SETBKJ_KESSN_UKEO_KIN, "
                    +    "SETBKJ_KESSN_ETC_KIN, "
                    +    "SETBKJ_KESSN_FUTKIN, "
                    +    "SETBKJ_TCH_CHOB_GENK_SUM, "
                    +    "SETBKJ_TCH_SHK_KIN, "
                    +    "SETBKJ_TCH_UKEO_KIN, "
                    +    "SETBKJ_TCH_ETC_KIN, "
                    +    "SETBKJ_TCH_FUTKIN, "
                    +    "SETBKJ_KAKTE_KBN, "
                    +    "SETBKJ_BUKT_SES_FLG, "
                    +    "SETBKJ_PRJ_DEF, "
                    +    "SETBKJ_KENKR_SEL_TANI_KBN "
                    +	"FROM  "
                    +    "R_SETBKJ_TCH AS R_SETBKJ_TCH_1 "
                    +	"WHERE "
                    +    "R_SETBKJ_TCH_1.SSN_NO = ? AND "
                    +    "R_SETBKJ_TCH_1.SSN_HJNO = ? AND "
                    +    "R_SETBKJ_TCH_1.SETBKJ_KJO_KBN = ? AND "
                    +    "R_SETBKJ_TCH_1.SETBKJ_DTL_TANI_FURI_DATE = ? ";

    /** FKSD144_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD144_SELECT_001 = {"SSN_NO_W01", "SSN_HJNO_W01", "SETBKJ_KJO_KBN_W01", "SETBKJ_DTL_TANI_FURI_DATE_W01"};

    /** FKSD144_SELECT_002 SQL .*/
    public static final String SQL_$FKSD144_SELECT_002 =
            "SELECT "
                    +    "SETBKJ_WBS_YOS, "
                    +    "SETBKJ_FST_SHK_DATE, "
                    +    "SETBKJ_SSN_CALSS, "
                    +    "SETBKJ_KOU_CD, "
                    +    "SETBKJ_KENKR_KAN_CD, "
                    +    "SETBKJ_KAN_CD, "
                    +    "SETBKJ_SETB_KMK_CD, "
                    +    "SETBKJ_GENK_CTR_CD, "
                    +    "DAI_KKSH_CD, "
                    +    "GNB_KKSH_CD, "
                    +    "JUT_KKSH_CD, "
                    +    "SETBKJ_KESSN_CHOB_GENK_SUM, "
                    +    "SETBKJ_KESSN_SHK_KIN, "
                    +    "SETBKJ_KESSN_UKEO_KIN, "
                    +    "SETBKJ_KESSN_ETC_KIN, "
                    +    "SETBK_KESSN_FUTKIN, "
                    +    "SETBKJ_TCH_CHOB_GENK_SUM, "
                    +    "SETBKJ_TCH_SHK_KIN, "
                    +    "SETBK_TCH_UKEO_KIN, "
                    +    "SETBKJ_TCH_ETC_KIN, "
                    +    "SETBKJ_TCH_FUTKIN, "
                    +    "SETBKJ_KAKTE_KBN, "
                    +    "SETBKJ_BUKT_SES_FLG, "
                    +    "SETBKJ_PRJ_DEF, "
                    +    "SETBKJ_KENKR_SEL_TANI_KBN "
                    +	"FROM  "
                    +    "R_SETBKJ_TCH AS R_SETBKJ_TCH_1 "
                    +	"WHERE "
                    +    "R_SETBKJ_TCH_1.SSN_NO = ? AND "
                    +    "R_SETBKJ_TCH_1.SSN_HJNO = ? AND "
                    +    "R_SETBKJ_TCH_1.SETBKJ_KJO_KBN = ? AND "
                    +    "R_SETBKJ_TCH_1.SETBKJ_DTL_TANI_FURI_DATE = ? ";

    /** FKSD144_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD144_SELECT_002 = {"SSN_NO_W01", "SSN_HJNO_W01", "SETBKJ_KJO_KBN_W01", "SETBKJ_DTL_TANI_FURI_DATE_W01"};


    /** FKSD144_DELETE_001 SQL .*/
    public static final String SQL_$FKSD144_DELETE_001 =
            "DELETE "
                    +	"FROM "
                    +    "R_SETBKJ_TCH "
                    +	"WHERE "
                    +    "SSN_NO = ? AND "
                    +    "SSN_HJNO = ? AND "
                    +    "SETBKJ_KJO_KBN = ? AND "
                    +    "SETBKJ_DTL_TANI_FURI_DATE = ? ";

    /** FKSD144_DELETE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD144_DELETE_001 = {"SSN_NO_W01", "SSN_HJNO_W01", "SETBKJ_KJO_KBN_W01", "SETBKJ_DTL_TANI_FURI_DATE_W01"};

    /** FKSD144_INSERT_001 SQL .*/
    public static final String SQL_$FKSD144_INSERT_001 =
            "INSERT INTO R_SETBKJ_TCH ( "
                    +    "SSN_NO, "
                    +    "SSN_HJNO, "
                    +    "SETBKJ_WBS_YOS, "
                    +    "SETBKJ_FST_SHK_DATE, "
                    +    "SETBKJ_SSN_CALSS, "
                    +    "SETBKJ_KOU_CD, "
                    +    "SETBKJ_KENKR_KAN_CD, "
                    +    "SETBKJ_KAN_CD, "
                    +    "SETBKJ_SETB_KMK_CD, "
                    +    "SETBKJ_GENK_CTR_CD, "
                    +    "DAI_KKSH_CD, "
                    +    "GNB_KKSH_CD, "
                    +    "JUT_KKSH_CD, "
                    +    "SETBKJ_KESSN_CHOB_GENK_SUM, "
                    +    "SETBKJ_KESSN_SHK_KIN, "
                    +    "SETBKJ_KESSN_UKEO_KIN, "
                    +    "SETBKJ_KESSN_ETC_KIN, "
                    +    "SETBKJ_KESSN_FUTKIN, "
                    +    "SETBKJ_TCH_CHOB_GENK_SUM, "
                    +    "SETBKJ_TCH_SHK_KIN, "
                    +    "SETBKJ_TCH_UKEO_KIN, "
                    +    "SETBKJ_TCH_ETC_KIN, "
                    +    "SETBKJ_TCH_FUTKIN, "
                    +    "SETBKJ_KAKTE_KBN, "
                    +    "SETBKJ_BUKT_SES_FLG, "
                    +    "SETBKJ_KJO_KBN, "
                    +    "SETBKJ_PRJ_DEF, "
                    +    "SETBKJ_KENKR_SEL_TANI_KBN, "
                    +    "SETBKJ_DTL_TANI_FURI_DATE, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    +	") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    +	") ";

    /** FKSD144_INSERT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD144_INSERT_001 = {"SSN_NO", "SSN_HJNO", "SETBKJ_WBS_YOS", "SETBKJ_FST_SHK_DATE", "SETBKJ_SSN_CALSS", "SETBKJ_KOU_CD", "SETBKJ_KENKR_KAN_CD", "SETBKJ_KAN_CD", "SETBKJ_SETB_KMK_CD", "SETBKJ_GENK_CTR_CD", "DAI_KKSH_CD", "GNB_KKSH_CD", "JUT_KKSH_CD", "SETBKJ_KESSN_CHOB_GENK_SUM", "SETBKJ_KESSN_SHK_KIN", "SETBKJ_KESSN_UKEO_KIN", "SETBKJ_KESSN_ETC_KIN", "SETBKJ_KESSN_FUTKIN", "SETBKJ_TCH_CHOB_GENK_SUM", "SETBKJ_TCH_SHK_KIN", "SETBKJ_TCH_UKEO_KIN", "SETBKJ_TCH_ETC_KIN", "SETBKJ_TCH_FUTKIN", "SETBKJ_KAKTE_KBN", "SETBKJ_BUKT_SES_FLG", "SETBKJ_KJO_KBN", "SETBKJ_PRJ_DEF", "SETBKJ_KENKR_SEL_TANI_KBN", "SETBKJ_DTL_TANI_FURI_DATE", "UPD_USR", "UPD_DATE"};

    /** FKSD144_INSERT_002 SQL .*/
    public static final String SQL_$FKSD144_INSERT_002 =
            "INSERT INTO R_SETBKJ_TCH ( "
                    +    "SSN_NO, "
                    +    "SSN_HJNO, "
                    +    "SETBKJ_WBS_YOS, "
                    +    "SETBKJ_FST_SHK_DATE, "
                    +    "SETBKJ_SSN_CALSS, "
                    +    "SETBKJ_KOU_CD, "
                    +    "SETBKJ_KENKR_KAN_CD, "
                    +    "SETBKJ_KAN_CD, "
                    +    "SETBKJ_SETB_KMK_CD, "
                    +    "SETBKJ_GENK_CTR_CD, "
                    +    "DAI_KKSH_CD, "
                    +    "GNB_KKSH_CD, "
                    +    "JUT_KKSH_CD, "
                    +    "SETBKJ_KESSN_CHOB_GENK_SUM, "
                    +    "SETBKJ_KESSN_SHK_KIN, "
                    +    "SETBKJ_KESSN_UKEO_KIN, "
                    +    "SETBKJ_KESSN_ETC_KIN, "
                    +    "SETBK_KESSN_FUTKIN, "
                    +    "SETBKJ_TCH_CHOB_GENK_SUM, "
                    +    "SETBKJ_TCH_SHK_KIN, "
                    +    "SETBK_TCH_UKEO_KIN, "
                    +    "SETBKJ_TCH_ETC_KIN, "
                    +    "SETBKJ_TCH_FUTKIN, "
                    +    "SETBKJ_KAKTE_KBN, "
                    +    "SETBKJ_BUKT_SES_FLG, "
                    +    "SETBKJ_KJO_KBN, "
                    +    "SETBKJ_PRJ_DEF, "
                    +    "SETBKJ_KENKR_SEL_TANI_KBN, "
                    +    "SETBKJ_DTL_TANI_FURI_DATE, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    +	") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    +	") ";

    /** FKSD144_INSERT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD144_INSERT_002 = {"SSN_NO", "SSN_HJNO", "SETBKJ_WBS_YOS", "SETBKJ_FST_SHK_DATE", "SETBKJ_SSN_CALSS", "SETBKJ_KOU_CD", "SETBKJ_KENKR_KAN_CD", "SETBKJ_KAN_CD", "SETBKJ_SETB_KMK_CD", "SETBKJ_GENK_CTR_CD", "DAI_KKSH_CD", "GNB_KKSH_CD", "JUT_KKSH_CD", "SETBKJ_KESSN_CHOB_GENK_SUM", "SETBKJ_KESSN_SHK_KIN", "SETBKJ_KESSN_UKEO_KIN", "SETBKJ_KESSN_ETC_KIN", "SETBK_KESSN_FUTKIN", "SETBKJ_TCH_CHOB_GENK_SUM", "SETBKJ_TCH_SHK_KIN", "SETBK_TCH_UKEO_KIN", "SETBKJ_TCH_ETC_KIN", "SETBKJ_TCH_FUTKIN", "SETBKJ_KAKTE_KBN", "SETBKJ_BUKT_SES_FLG", "SETBKJ_KJO_KBN", "SETBKJ_PRJ_DEF", "SETBKJ_KENKR_SEL_TANI_KBN", "SETBKJ_DTL_TANI_FURI_DATE", "UPD_USR", "UPD_DATE"};

    /** FKSD145_SELECT_001 SQL .*/
    public static final String SQL_$FKSD145_SELECT_001 =
            "SELECT "
                    +    "SYU_NO, "
                    +    "KYK_NO, "
                    +    "DAI_KKSH_CD, "
                    +    "GNB_KKSH_CD, "
                    +    "SSN_KNR_KAN_CD, "
                    +    "KNRI_SBT_CD, "
                    +    "IDO_SBT_CD, "
                    +    "SSN_KNR_KMK_CD, "
                    +    "JOCHO_DATE, "
                    +    "DAI_KKSH_TORI_FLG, "
                    +    "RICH_ENV_TORI_FLG "
                    + "FROM  "
                    +    "R_JOCHO_DAI_KEY "
                    + "WHERE "
                    +    "DAI_KKSH_CD = ? "
                    + "AND "
                    +    "GNB_KKSH_CD LIKE ? "
                    + "AND "
                    +    "SSN_KNR_KAN_CD LIKE ? "
                    + "ORDER BY "
                    +    "SYU_NO ASC , "
                    +    "KYK_NO ASC , "
                    +    "JOCHO_DATE DESC  "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD145_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD145_SELECT_001 = {"DAI_KKSH_CD_W01", "GNB_KKSH_CD_W01", "SSN_KNR_KAN_CD_W01", "LIMIT", "OFFSET"};

    /** FKSD145_SELECT_001_CNT SQL. */
    public static final String SQL_$FKSD145_SELECT_001_CNT =
            " SELECT "
                    + " 	COUNT(*) AS COUNT "
                    + " FROM"
                    + "		R_JOCHO_DAI_KEY "
                    + "WHERE "
                    +    "DAI_KKSH_CD = ? "
                    + "AND "
                    +    "GNB_KKSH_CD LIKE ? "
                    + "AND "
                    +    "SSN_KNR_KAN_CD LIKE ? ";

    /** FKSD145_SELECT_001_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD145_SELECT_001_CNT = {"DAI_KKSH_CD_W01", "GNB_KKSH_CD_W01", "SSN_KNR_KAN_CD_W01"};

    /** FKSD145_UPDATE_001 SQL .*/
    public static final String SQL_$FKSD145_UPDATE_001 =
            "UPDATE "
                    +    "R_JOCHO_DAI_KEY "
                    + "SET "
                    +    "DAI_KKSH_TORI_FLG = ?, "
                    +    "RICH_ENV_TORI_FLG = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "SYU_NO = ?"
                    + "AND "
                    +    "KYK_NO = ? ";

    /** FKSD145_UPDATE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD145_UPDATE_001 = {"DAI_KKSH_TORI_FLG", "RICH_ENV_TORI_FLG", "UPD_USR", "UPD_DATE", "SYU_NO_W01", "KYK_NO_W01"};

    /** FKSD146_SELECT_001 SQL .*/
    public static final String SQL_$FKSD146_SELECT_001 =
            "SELECT "
                    +    "SYU_NO, "
                    +    "SYU_IDO_RRK_RNO, "
                    +    "IDO_DATE, "
                    +    "SYU_IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO "
                    + "FROM  "
                    +    "R_SYU_IDO_RRK AS R_SYU_IDO_RRK_1 "
                    + "WHERE "
                    +    "R_SYU_IDO_RRK_1.SYU_NO = ? "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD146_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_SELECT_001 = {"SYU_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD146_SELECT_001_CNT SQL. */
    public static final String SQL_$FKSD146_SELECT_001_CNT =
            " SELECT "
                    + 	"COUNT(*) AS COUNT "
                    + "FROM  "
                    +   "R_SYU_IDO_RRK "
                    + "WHERE "
                    +   "SYU_NO = ? ";

    /** FKSD146_SELECT_001_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD146_SELECT_001_CNT = {"SYU_NO_W01"};

    /** FKSD146_SELECT_002 SQL .*/
    public static final String SQL_$FKSD146_SELECT_002 =
            "SELECT "
                    +    "KYK_NO, "
                    +    "CECJ_IDO_RNO, "
                    +    "CECJ_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO "
                    + "FROM  "
                    +    "R_CECJ_IDO_RRK AS R_CECJ_IDO_RRK_1 "
                    + "WHERE "
                    +    "R_CECJ_IDO_RRK_1.KYK_NO = ? "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD146_SELECT_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_SELECT_002 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD146_SELECT_002_CNT SQL. */
    public static final String SQL_$FKSD146_SELECT_002_CNT =
            " SELECT "
                    + 	"COUNT(*) AS COUNT "
                    + "FROM  "
                    +   "R_CECJ_IDO_RRK "
                    + "WHERE "
                    +   "KYK_NO = ? ";

    /** FKSD146_SELECT_002_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD146_SELECT_002_CNT = {"KYK_NO_W01"};

    /** FKSD146_SELECT_003 SQL .*/
    public static final String SQL_$FKSD146_SELECT_003 =
            "SELECT "
                    +    "KYK_NO, "
                    +    "KAS_IDO_RNO, "
                    +    "KAS_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO "
                    + "FROM  "
                    +    "R_KAS_IDO_RRK AS R_KAS_IDO_RRK_1 "
                    + "WHERE "
                    +    "R_KAS_IDO_RRK_1.KYK_NO = ? "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD146_SELECT_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_SELECT_003 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD146_SELECT_003_CNT SQL. */
    public static final String SQL_$FKSD146_SELECT_003_CNT =
            " SELECT "
                    + 	"COUNT(*) AS COUNT "
                    + "FROM  "
                    +   "R_KAS_IDO_RRK "
                    + "WHERE "
                    +   "KYK_NO = ? ";

    /** FKSD146_SELECT_003_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD146_SELECT_003_CNT = {"KYK_NO_W01"};

    /** FKSD146_SELECT_004 SQL .*/
    public static final String SQL_$FKSD146_SELECT_004 =
            "SELECT "
                    +    "KYK_NO, "
                    +    "KRUK_IDO_RNO, "
                    +    "KRUK_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO "
                    + "FROM  "
                    +    "R_KRUK_IDO_RRK AS R_KRUK_IDO_RRK_1 "
                    + "WHERE "
                    +    "R_KRUK_IDO_RRK_1.KYK_NO = ? "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD146_SELECT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_SELECT_004 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD146_SELECT_004_CNT SQL. */
    public static final String SQL_$FKSD146_SELECT_004_CNT =
            " SELECT "
                    + 	"COUNT(*) AS COUNT "
                    + "FROM  "
                    +   "R_KRUK_IDO_RRK "
                    + "WHERE "
                    +   "KYK_NO = ? ";

    /** FKSD146_SELECT_004_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD146_SELECT_004_CNT = {"KYK_NO_W01"};

    /** FKSD146_SELECT_005 SQL .*/
    public static final String SQL_$FKSD146_SELECT_005 =
            "SELECT "
                    +    "KYK_NO, "
                    +    "SEY_IDO_RNO, "
                    +    "SEY_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO "
                    + "FROM  "
                    +    "R_SEY_IDO_RRK AS R_SEY_IDO_RRK_1 "
                    + "WHERE "
                    +    "R_SEY_IDO_RRK_1.KYK_NO = ? "
                    + "	LIMIT ?"
                    + "	OFFSET ?";

    /** FKSD146_SELECT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_SELECT_005 = {"KYK_NO_W01", "LIMIT", "OFFSET"};

    /** FKSD146_SELECT_005_CNT SQL. */
    public static final String SQL_$FKSD146_SELECT_005_CNT =
            " SELECT "
                    + 	"COUNT(*) AS COUNT "
                    + "FROM  "
                    +   "R_SEY_IDO_RRK "
                    + "WHERE "
                    +   "KYK_NO = ? ";

    /** FKSD146_SELECT_005_CNT �p�����[�^��`. */
    public static final String[] PARAM_$FKSD146_SELECT_005_CNT = {"KYK_NO_W01"};

    /** FKSD146_INSERT_001 SQL .*/
    public static final String SQL_$FKSD146_INSERT_001 =
            "INSERT INTO R_SYU_IDO_RRK ( "
                    +    "SYU_NO, "
                    +    "SYU_IDO_RRK_RNO, "
                    +    "IDO_DATE, "
                    +    "SYU_IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " COALESCE (( "
                    +       "SELECT "
                    +           "MAX(SYU_IDO_RRK_RNO) + 1 "
                    +       "FROM "
                    +           "R_SYU_IDO_RRK "
                    +       "WHERE "
                    +           "SYU_NO = ? "
                    +    " ), 1), "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_001 = {"SYU_NO", "SYU_NO", "IDO_DATE", "SYU_IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_UPDATE_001 SQL .*/
    public static final String SQL_$FKSD146_UPDATE_001 =
            "UPDATE "
                    +    "R_SYU_IDO_RRK "
                    + "SET "
                    +    " IDO_DATE = ?, "
                    +    " SYU_IDO_SBT = ?, "
                    +    " IDO_KIT_DATE = ?, "
                    +    " IDO_KKTS_NO = ?, "
                    +    " UPD_USR = ?, "
                    +    " UPD_DATE = ? "
                    + "WHERE "
                    +    "SYU_NO = ? "
                    + "AND "
                    +    "SYU_IDO_RRK_RNO = ? ";

    /** FKSD146_UPDATE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_UPDATE_001 = {"IDO_DATE", "SYU_IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE", "SYU_NO_W01", "SYU_IDO_RRK_RNO_W01"};

    /** FKSD146_DELETE_001 SQL .*/
    public static final String SQL_$FKSD146_DELETE_001 =
            "DELETE "
                    + "FROM "
                    +    "R_SYU_IDO_RRK "
                    + "WHERE "
                    +    "SYU_NO = ? AND "
                    +    "SYU_IDO_RRK_RNO = ? ";

    /** FKSD146_DELETE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_DELETE_001 = {"SYU_NO_W01", "SYU_IDO_RRK_RNO_W01"};

    /** FKSD146_INSERT_004 SQL .*/
    public static final String SQL_$FKSD146_INSERT_004 =
            "INSERT INTO E_SYU_IDO_RRK_SSE_DTL ( "
                    +    "SYU_TOK_NO, "
                    +    "SYU_TOK_RRK_SSE_RNO, "
                    +    "SS_KBN, "
                    +    "IDO_DATE, "
                    +    "IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_004 = {"SYU_TOK_NO", "SYU_TOK_RRK_SSE_RNO", "SS_KBN", "IDO_DATE", "IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_INSERT_005 SQL .*/
    public static final String SQL_$FKSD146_INSERT_005 =
            "INSERT INTO R_CECJ_IDO_RRK ( "
                    +    "KYK_NO, "
                    +    "CECJ_IDO_RNO, "
                    +    "CECJ_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " COALESCE (( "
                    +       "SELECT "
                    +           "MAX(CECJ_IDO_RNO) + 1 "
                    +       "FROM "
                    +           "R_CECJ_IDO_RRK "
                    +       "WHERE "
                    +           "KYK_NO = ? "
                    +    " ), 1), "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_005 = {"KYK_NO", "KYK_NO", "CECJ_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_UPDATE_002 SQL .*/
    public static final String SQL_$FKSD146_UPDATE_002 =
            "UPDATE "
                    +    "R_CECJ_IDO_RRK "
                    + "SET "
                    +    "CECJ_IDO_SBT = ?, "
                    +    "IDO_DATE = ?, "
                    +    "IDO_KIT_DATE = ?, "
                    +    "IDO_KKTS_NO = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    + "AND "
                    +    "CECJ_IDO_RNO = ? ";

    /** FKSD146_UPDATE_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_UPDATE_002 = {"CECJ_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE", "KYK_NO_W01", "CECJ_IDO_RNO_W01"};

    /** FKSD146_DELETE_002 SQL .*/
    public static final String SQL_$FKSD146_DELETE_002 =
            "DELETE "
                    + "FROM "
                    +    "R_CECJ_IDO_RRK "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    + "AND "
                    +    "CECJ_IDO_RNO = ? ";

    /** FKSD146_DELETE_002 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_DELETE_002 = {"KYK_NO_W01", "CECJ_IDO_RNO_W01"};


    /** FKSD146_INSERT_008 SQL .*/
    public static final String SQL_$FKSD146_INSERT_008 =
            "INSERT INTO E_CECJ_IDO_RRK_SSE_DTL ( "
                    +    "CECJ_TOK_NO, "
                    +    "CECJ_IDO_RRK_SSE_RNO, "
                    +    "SS_KBN, "
                    +    "IDO_DATE, "
                    +    "IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_008 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_008 = {"CECJ_TOK_NO", "CECJ_IDO_RRK_SSE_RNO", "SS_KBN", "IDO_DATE", "IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_INSERT_009 SQL .*/
    public static final String SQL_$FKSD146_INSERT_009 =
            "INSERT INTO R_KAS_IDO_RRK ( "
                    +    "KYK_NO, "
                    +    "KAS_IDO_RNO, "
                    +    "KAS_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " COALESCE (( "
                    +       "SELECT "
                    +           "MAX(KAS_IDO_RNO) + 1 "
                    +       "FROM "
                    +           "R_KAS_IDO_RRK "
                    +       "WHERE "
                    +           "KYK_NO = ? "
                    +    " ), 1), "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_009 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_009 = {"KYK_NO", "KYK_NO", "KAS_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_UPDATE_003 SQL .*/
    public static final String SQL_$FKSD146_UPDATE_003 =
            "UPDATE "
                    +    "R_KAS_IDO_RRK "
                    + "SET "
                    +    "KAS_IDO_SBT = ?, "
                    +    "IDO_DATE = ?, "
                    +    "IDO_KIT_DATE = ?, "
                    +    "IDO_KKTS_NO = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND KAS_IDO_RNO = ? ";

    /** FKSD146_UPDATE_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_UPDATE_003 = {"KAS_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE", "KYK_NO_W01", "KAS_IDO_RNO_W01"};

    /** FKSD146_DELETE_003 SQL .*/
    public static final String SQL_$FKSD146_DELETE_003 =
            "DELETE "
                    + "FROM "
                    +    "R_KAS_IDO_RRK "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND KAS_IDO_RNO = ? ";

    /** FKSD146_DELETE_003 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_DELETE_003 = {"KYK_NO_W01", "KAS_IDO_RNO_W01"};


    /** FKSD146_INSERT_012 SQL .*/
    public static final String SQL_$FKSD146_INSERT_012 =
            "INSERT INTO E_KAS_IDO_RRK_SSE_DTL ( "
                    +    "KAS_TOK_NO, "
                    +    "KAS_IDO_RRK_SSE_RNO, "
                    +    "SS_KBN, "
                    +    "IDO_DATE, "
                    +    "IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_012 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_012 = {"KAS_TOK_NO", "KAS_IDO_RRK_SSE_RNO", "SS_KBN", "IDO_DATE", "IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_INSERT_013 SQL .*/
    public static final String SQL_$FKSD146_INSERT_013 =
            "INSERT INTO R_KRUK_IDO_RRK ( "
                    +    "KYK_NO, "
                    +    "KRUK_IDO_RNO, "
                    +    "KRUK_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " COALESCE (( "
                    +       "SELECT "
                    +           "MAX(KRUK_IDO_RNO) + 1 "
                    +       "FROM "
                    +           "R_KRUK_IDO_RRK "
                    +       "WHERE "
                    +           "KYK_NO = ? "
                    +    " ), 1), "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_013 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_013 = {"KYK_NO", "KYK_NO", "KRUK_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_UPDATE_004 SQL .*/
    public static final String SQL_$FKSD146_UPDATE_004 =
            "UPDATE "
                    +    "R_KRUK_IDO_RRK "
                    + "SET "
                    +    "KRUK_IDO_SBT = ?, "
                    +    "IDO_DATE = ?, "
                    +    "IDO_KIT_DATE = ?, "
                    +    "IDO_KKTS_NO = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND KRUK_IDO_RNO = ? ";

    /** FKSD146_UPDATE_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_UPDATE_004 = {"KRUK_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE", "KYK_NO_W01", "KRUK_IDO_RNO_W01"};

    /** FKSD146_DELETE_004 SQL .*/
    public static final String SQL_$FKSD146_DELETE_004 =
            "DELETE "
                    + "FROM "
                    +    "R_KRUK_IDO_RRK "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND KRUK_IDO_RNO = ? ";

    /** FKSD146_DELETE_004 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_DELETE_004 = {"KYK_NO_W01", "KRUK_IDO_RNO_W01"};


    /** FKSD146_INSERT_016 SQL .*/
    public static final String SQL_$FKSD146_INSERT_016 =
            "INSERT INTO E_KRUK_IDO_RRK_SSE_DTL ( "
                    +    "KRUK_TOK_NO, "
                    +    "KRUK_IDO_RRK_SSE_RNO, "
                    +    "SS_KBN, "
                    +    "IDO_DATE, "
                    +    "IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_016 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_016 = {"KRUK_TOK_NO", "KRUK_IDO_RRK_SSE_RNO", "SS_KBN", "IDO_DATE", "IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_INSERT_017 SQL .*/
    public static final String SQL_$FKSD146_INSERT_017 =
            "INSERT INTO R_SEY_IDO_RRK ( "
                    +    "KYK_NO, "
                    +    "SEY_IDO_RNO, "
                    +    "SEY_IDO_SBT, "
                    +    "IDO_DATE, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " COALESCE (( "
                    +       "SELECT "
                    +           "MAX(SEY_IDO_RNO) + 1 "
                    +       "FROM "
                    +           "R_SEY_IDO_RRK "
                    +       "WHERE "
                    +           "KYK_NO = ? "
                    +    " ), 1), "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_017 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_017 = {"KYK_NO", "KYK_NO", "SEY_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD146_UPDATE_005 SQL .*/
    public static final String SQL_$FKSD146_UPDATE_005 =
            "UPDATE "
                    +    "R_SEY_IDO_RRK "
                    + "SET "
                    +    "SEY_IDO_SBT = ?, "
                    +    "IDO_DATE = ?, "
                    +    "IDO_KIT_DATE = ?, "
                    +    "IDO_KKTS_NO = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND SEY_IDO_RNO = ? ";

    /** FKSD146_UPDATE_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_UPDATE_005 = {"SEY_IDO_SBT", "IDO_DATE", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE", "KYK_NO_W01", "SEY_IDO_RNO_W01"};

    /** FKSD146_DELETE_005 SQL .*/
    public static final String SQL_$FKSD146_DELETE_005 =
            "DELETE "
                    + "FROM "
                    +    "R_SEY_IDO_RRK "
                    + "WHERE "
                    +    "KYK_NO = ? "
                    +    "AND SEY_IDO_RNO = ? ";

    /** FKSD146_DELETE_005 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_DELETE_005 = {"KYK_NO_W01", "SEY_IDO_RNO_W01"};


    /** FKSD146_INSERT_020 SQL .*/
    public static final String SQL_$FKSD146_INSERT_020 =
            "INSERT INTO E_SEY_IDO_RRK_SSE_DTL ( "
                    +    "SEY_TOK_NO, "
                    +    "SEY_IDO_RRK_SSE_RNO, "
                    +    "SS_KBN, "
                    +    "IDO_DATE, "
                    +    "IDO_SBT, "
                    +    "IDO_KIT_DATE, "
                    +    "IDO_KKTS_NO, "
                    +    "UPD_USR, "
                    +    "UPD_DATE "
                    + ") VALUES ( "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ? , "
                    +    " ?  "
                    + ") ";

    /** FKSD146_INSERT_020 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD146_INSERT_020 = {"SEY_TOK_NO", "SEY_IDO_RRK_SSE_RNO", "SS_KBN", "IDO_DATE", "IDO_SBT", "IDO_KIT_DATE", "IDO_KKTS_NO", "UPD_USR", "UPD_DATE"};

    /** FKSD147_SELECT_001 SQL .*/
    public static final String SQL_$FKSD147_SELECT_001 =
            "SELECT "
                    +    "SHRCHS_TSH_YND, "
                    +    "KAKTE_KBN "
                    + "FROM  "
                    +    "R_SHRCHS_TSH_YND AS R_SHRCHS_TSH_YND_1 "
                    + "ORDER BY "
                    +    "R_SHRCHS_TSH_YND_1.SHRCHS_TSH_YND DESC  ";

    /** FKSD147_SELECT_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD147_SELECT_001 = {};

    /** FKSD147_UPDATE_001 SQL .*/
    public static final String SQL_$FKSD147_UPDATE_001 =
            "UPDATE "
                    +    "R_SHRCHS_TSH_YND "
                    + "SET "
                    +    "KAKTE_KBN = ?, "
                    +    "UPD_USR = ?, "
                    +    "UPD_DATE = ? "
                    + "WHERE "
                    +    "SHRCHS_TSH_YND = ? ";

    /** FKSD147_UPDATE_001 �p�����[�^��` .*/
    public static final String[] PARAM_$FKSD147_UPDATE_001 = {"KAKTE_KBN", "UPD_USR", "UPD_DATE", "SHRCHS_TSH_YND_W01"};

    // COMMONSQL

    /** COMMON_25_1 SQL .*/
    public static final String SQL_$COMMON_25_1 =
            "SELECT "
                    +	"MAX(MAX_NO) AS MAX_NO "
                    + "FROM "
                    + "( "
                    + "SELECT "
                    +    "SYU_NO AS MAX_NO "
                    + "FROM  "
                    +    "R_SYU_TCH AS R_SYU_TCH_1 "
                    + "WHERE "
                    +    " SUBSTR(R_SYU_TCH_1.SYU_NO, 2, 1)=? "
                    + "UNION ALL "
                    + "SELECT "
                    +    "BKN_NO AS MAX_NO "
                    + "FROM  "
                    +    "R_BKN AS R_BKN_1 "
                    + "WHERE "
                    +    " SUBSTR(R_BKN_1.BKN_NO, 2, 1)=? "
                    + ") T1";


    /** COMMON_25_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_25_1 =  {"STN_BNR_W01", "STN_BNR_W02"};

    /** COMMON_27_1 SQL .*/
    public static final String SQL_$COMMON_27_1 =
            "SELECT "
                    +    "SUB1_1.KYK_NO AS MAX_KYK_NO "
                    + "FROM  "
                    + "("
                    + "SELECT "
                    +    "R_CECJ_1.KYK_NO "
                    + "FROM  "
                    +    "R_CECJ AS R_CECJ_1 "
                    + "WHERE "
                    +    "R_CECJ_1.KYK_NO SUBSTR(KYK_CD,2,1) = ? "
                    + "UNION ALL"
                    + "SELECT "
                    +    "R_KRUK_1.KYK_NO "
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    + "SELECT "
                    +    "R_KAS_1.KYK_NO "
                    + "FROM  "
                    +    "R_KAS AS R_KAS_1 "
                    + "SELECT "
                    +    "R_SEY_1.KYK_NO "
                    + "FROM  "
                    +    "R_SEY AS R_SEY_1 "
                    +    " ) SUB1_1 "
                    + "WHERE "
                    +    "SUBSTR(SUB1_1 .KYK_NO, 2, 1) = ? ";

    /** COMMON_27_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_27_1 = {"STN_BNR_W01"};


    /** COMMON_28_1 SQL .*/
    public static final String SQL_$COMMON_28_1 =
            "SELECT "
                    +    "MIN(SYU_TCH_1.SYU_NO) AS SYU_NO "
                    + "FROM  "
                    +    "R_SYU_TCH AS R_SYU_TCH_1 "
                    + "WHERE "
                    +    "R_SYU_TCH_1.SYU_NO > ? ";

    /** COMMON_28_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_28_1 = {"SYU_NO_W01"};

    /** COMMON_29_1 SQL .*/
    public static final String SQL_$COMMON_29_1 =
            "SELECT "
                    +    "MAX(SYU_TCH_1.SYU_NO) AS SYU_NO "
                    + "FROM  "
                    +    "R_SYU_TCH AS R_SYU_TCH_1 "
                    + "WHERE "
                    +    "R_SYU_TCH_1.SYU_NO < ? ";

    /** COMMON_29_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_29_1 = {"SYU_NO_W01"};

    /** COMMON_30_1 SQL .*/
    public static final String SQL_$COMMON_30_1 =
            "SELECT "
                    +    "MIN(R_CECJ_1.KYK_NO) AS KYK_NO "
                    + "FROM  "
                    +    "R_CECJ AS R_CECJ_1 "
                    + "WHERE "
                    +    "R_CECJ_1.KYK_NO > ? ";

    /** COMMON_30_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_30_1 = {"KYK_NO_W01"};

    /** COMMON_30_2 SQL .*/
    public static final String SQL_$COMMON_30_2 =
            "SELECT "
                    +    "MIN(R_CECJ_1.KYK_NO) AS KYK_NO "
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    + "WHERE "
                    +    "R_KRUK_1.KYK_NO > ? ";

    /** COMMON_30_2 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_30_2 = {"KYK_NO_W01"};

    /** COMMON_30_3 SQL .*/
    public static final String SQL_$COMMON_30_3 =
            "SELECT "
                    +    "MIN(R_CECJ_1.KYK_NO) AS KYK_NO "
                    + "FROM  "
                    +    "R_KAS AS R_KAS_1 "
                    + "WHERE "
                    +    "R_KAS_1.KYK_NO > ? ";

    /** COMMON_30_3 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_30_3 = {"KYK_NO_W01"};

    /** COMMON_30_4 SQL .*/
    public static final String SQL_$COMMON_30_4 =
            "SELECT "
                    +    "MIN(R_CECJ_1.KYK_NO) AS KYK_NO "
                    + "FROM  "
                    +    "R_SEY AS R_SEY_1 "
                    + "WHERE "
                    +    "R_SEY_1.KYK_NO > ? ";

    /** COMMON_30_4 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_30_4 = {"KYK_NO_W01"};

    /** COMMON_31_1 SQL .*/
    public static final String SQL_$COMMON_31_1 =
            "SELECT "
                    +    "MAX(AS R_SEY_1.KYK_NO) AS KYK_NO"
                    + "FROM  "
                    +    "R_CECJ AS R_CECJ_1 "
                    + "WHERE "
                    +    "R_CECJ_1.KYK_NO < ? ";

    /** COMMON_31_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_31_1 = {"KYK_NO_W01"};

    /** COMMON_31_2 SQL .*/
    public static final String SQL_$COMMON_31_2 =
            "SELECT "
                    +    "MAX(AS R_SEY_1.KYK_NO) AS KYK_NO"
                    + "FROM  "
                    +    "R_KRUK AS R_KRUK_1 "
                    + "WHERE "
                    +    "R_KRUK_1.KYK_NO < ? ";

    /** COMMON_31_2 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_31_2 = {"KYK_NO_W01"};

    /** COMMON_31_3 SQL .*/
    public static final String SQL_$COMMON_31_3 =
            "SELECT "
                    +    "MAX(AS R_SEY_1.KYK_NO) AS KYK_NO"
                    + "FROM  "
                    +    "R_KAS AS R_KAS_1 "
                    + "WHERE "
                    +    "R_KAS_1.KYK_NO < ? ";

    /** COMMON_31_3 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_31_3 = {"KYK_NO_W01"};

    /** COMMON_31_4 SQL .*/
    public static final String SQL_$COMMON_31_4 =
            "SELECT "
                    +    "MAX(AS R_SEY_1.KYK_NO) AS KYK_NO"
                    + "FROM  "
                    +    "R_SEY AS R_SEY_1 "
                    + "WHERE "
                    +    "R_SEY_1.KYK_NO < ? ";

    /** COMMON_31_4 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_31_4 = {"KYK_NO_W01"};

    /** COMMON_32_1 SQL .*/
    public static final String SQL_$COMMON_32_1 =
            " SELECT "
                    + " nextval('SEQ_SYU_TOK_NO')";

    /** COMMON_32_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_32_1 = {};

    /** COMMON_33_1 SQL .*/
    public static final String SQL_$COMMON_33_1 =
            " SELECT "
                    + " nextval('SEQ_CECJ_TOK_NO')";

    /** COMMON_33_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_33_1 = {};

    /** COMMON_34_1 SQL .*/
    public static final String SQL_$COMMON_34_1 =
            " SELECT "
                    + " nextval('SEQ_KRUK_TOK_NO')";

    /** COMMON_34_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_34_1 = {};

    /** COMMON_35_1 SQL .*/
    public static final String SQL_$COMMON_35_1 =
            " SELECT "
                    + " nextval('SEQ_SEY_TOK_NO')";

    /** COMMON_35_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_35_1 = {};

    /** COMMON_36_1 SQL .*/
    public static final String SQL_$COMMON_36_1 =
            " SELECT "
                    + " nextval('SEQ_KAS_TOK_NO')";

    /** COMMON_36_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_36_1 = {};

    /** COMMON_37_1 SQL .*/
    public static final String SQL_$COMMON_37_1 =
            " SELECT "
                    + " nextval('SEQ_UKB_TOK_NO')";

    /** COMMON_37_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_37_1 = {};

    /** COMMON_38_1 SQL .*/
    public static final String SQL_$COMMON_38_1 =
            " SELECT "
                    + " nextval('SEQ_BULD_KNR_TOK_NO')";

    /** COMMON_38_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_38_1 = {};

    /** COMMON_39_1 SQL .*/
    public static final String SQL_$COMMON_39_1 =
            " SELECT "
                    + " nextval('SEQ_KYKSH_TOK_NO')";

    /** COMMON_39_1  �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_39_1 = {};



    /** COMMON_41_1 SQL .*/
    public static final String SQL_$COMMON_40_1 =
            "SELECT "
                    +    "KBN_NAME "
                    + "FROM  "
                    +    "R_KBN AS R_KBN_1 "
                    + "WHERE "
                    +    "R_KBN_1.KBN_SBT_CD = ? AND "
                    +    "R_KBN_1.KBN_CD = ? ";

    /** COMMON_41_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_40_1 = {"KBN_SBT_CD_W01", "KBN_CD_W01"};




    /** COMMON_42_1 SQL .*/
    public static final String SQL_$COMMON_42_1 =
            "SELECT "
                    +		"JGSH_CD "
                    +		",JGSH_NAME "
                    +	"FROM "
                    +		"R_JGSH AS R_JGSH_1 "
                    +	"ORDER BY "
                    +		"R_JGSH_1.JGSH_CD ASC ";

    /** COMMON_42_1 SQL �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_42_1 = {};

    /** COMMON_44_1 SQL .*/
    public static final String SQL_$COMMON_44_1 =
            "SELECT "
                    +    "KBN_CD AS CODE, "
                    +    "KBN_NAME AS NAME "
                    + "FROM  "
                    +    "R_KBN AS R_KBN_1 "
                    + "WHERE "
                    +    "R_KBN_1.KBN_SBT_CD = ? "
                    + "ORDER BY "
                    +    "R_KBN_1.KBN_CD ASC  ";

    /** COMMON_44_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_44_1 = {"KBN_SBT_CD_W01"};

    /** COMMON_50_1 SQL .*/
    public static final String SQL_$COMMON_50_1 =
             " SELECT "
                    + " T1.PREFECTURE_KANJI "
                    + " ,T1.CITY_COUNTY_MUNICIPALITY_KANJI "
                    + " FROM "
                    + " R_ADDRESS T1 "
                    + " INNER JOIN ( "
                    + " SELECT "
                    + " T2.MUNICIPALITY_CD "
                    + " FROM "
                    + " R_ADDRESS T2 "
                    + " WHERE "
                    + " T2.MUNICIPALITY_CD = ? "
                    + " GROUP BY "
                    + " T2.MUNICIPALITY_CD "
                    + " ) SUB1 "
                    + " ON  T1.MUNICIPALITY_CD = SUB1.MUNICIPALITY_CD ";

    /** COMMON_50_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_50_1 = {"MUNICIPALITY_CD_W01"};

    /** COMMON_51_1 SQL .*/
    public static final String SQL_$COMMON_51_1 =
            "SELECT "
                    +    "VILLAGE_SECTION_KANJI, "
                    +    "CITY_BLOCK_KANJI "
                    + "FROM  "
                    +    "R_ADDRESS AS R_ADDRESS_1 "
                    + "WHERE "
                    +    "R_ADDRESS_1.MUNICIPALITY_CD = ? AND "
                    +    "R_ADDRESS_1.LOCATION_CD = ? ";

    /** COMMON_51_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_51_1 = {"MUNICIPALITY_CD_W01", "LOCATION_CD_W01"};

    /** COMMON_53_1 SQL .*/
    public static final String SQL_$COMMON_53_1 =
            "SELECT "
                    +    "JGSH_NAME "
                    + "FROM  "
                    +    "R_JGSH AS R_JGSH_1 "
                    + "WHERE "
                    +    "R_JGSH_1.JGSH_CD = ? ";

    /** COMMON_53_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_53_1 = {"JGSH_CD_W01"};

    /** COMMON_55_1 SQL .*/
    public static final String SQL_$COMMON_55_1 =
        "SELECT "
        +    "MAX(TOK_NO) AS TOK_NO "
        + "FROM  "
        +	 "( "
        +		"SELECT "
        +			"TOK_NO "
        +		"FROM  "
        +			"BACK_LOGWK AS BACK_LOGWK_1 "
        +		"UNION ALL "
        +		"SELECT "
        +			"TOK_NO "
        +		"FROM  "
        +			"R_DAI_CRE_KEY AS R_DAI_CRE_KEY_1"
        +       "UNION ALL "
        +		"SELECT "
        +			"TOK_NO "
        +		"FROM  "
        +			"R_UPD_RRK AS R_UPD_RRK_1 "
        +		"UNION ALL "
        +		"SELECT "
        +			"KTEREN_TOK_NO AS TOK_NO "
        +		"FROM "
        +			"R_KTEREN_SHJ AS R_KTEREN_SHJ_1 "
        +	") SUB_1 "
        + "WHERE "
        +    "substr(SUB_1.TOK_NO,1,22) = ?";

    /** COMMON_55_1 �p�����[�^��` .*/
    public static final String[] PARAM_$COMMON_55_1 = {"TOK_NO_W01"};

    /**
     * �C���X�^���X�擾���\�b�h.
     * @return �C���X�^���X
     */
    public static SQLObjectInterface getInstance() {
        return sqlObj;
    }

}
