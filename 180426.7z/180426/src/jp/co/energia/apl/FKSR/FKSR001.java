/**
 * FKSR001.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSR;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.enecom.framework.config.SystemConfiguration;
import jp.co.enecom.framework.constants.FrameworkConstants;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �ЗL�䒠���[�쐬�p�N���X�ł��B.
 * Ver.00.00.00 2018/3/22 : Y.Tani - Original
 */
public class FKSR001 {
	/** ���[ID�i�䒠�⎆�j. */
    public static final String REPORT_ID = "FKSR001";
	/** ���׍ő�s���i�P�y�[�W�ځj. */
	private static final int LINE_MAX = 2;
	/** ���׍ő�s���i�Q�y�[�W�ڈȍ~�j. */
	private static final int LINE_MAX_2 = 9;
	/** ������e�ő�s��. */
	private static final int RRK_LINE_MAX = 5;
	/** �\������_�L. */
	private static final String MOJI_ARI = "�L";
	/** ���Ӄ��b�Z�[�W. */
	private static final String NOTE = "���������o�c�Ǘ��ƁC���댴�����s��v�̂��߁C���떾�ׂ́u���v�\���ƂȂ�܂��B��������";
	/** �X�p�[�X. */
	private static final String SPACE = " ";
	/** �Ȃ��i�t���O�j. */
	private static final String NASHI_FLG = "0";

	/** �R���X�g���N�^. */
	public FKSR001() { };


	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @param param ���[�쐬�p�����[�^
	 * @return �_�E�����[�h���
	 * @throws Exception ��O
	 */
	public Map<String, String> makePrintFile(CommonDAO dao, Map<String, Object>param) throws Exception {

		// �ЗL�䒠�����擾����B
		List<Map<String, Object>> syuList = dao.getQueryResult(param, "FKSR001_SEL_001", CommonDAO.PRINT_SQL);
		if (syuList == null || syuList.size() == 0) {
			return null;
		}
		param.put("DAI_KKSH_CD_W01", syuList.get(0).get("DAI_KKSH_CD"));
		// ��v�L���N�������擾����B
		List<Map<String, Object>> kichoDateList = dao.getQueryResult(param, "FKSR001_SEL_002", CommonDAO.PRINT_SQL);
		param.put("BKN_NO_W01", syuList.get(0).get("BKN_NO"));
		param.put("SSN_NO_W01", syuList.get(0).get("SSN_NO"));
		// ���떾�ׂ��擾����B
		List<Map<String, Object>> chobList = dao.getQueryResult(param, "FKSR001_SEL_003", CommonDAO.PRINT_SQL);
		// �d���Ǘ����ׂ��擾����B
		List<Map<String, Object>> chfkKnrList = dao.getQueryResult(param, "FKSR001_SEL_004", CommonDAO.PRINT_SQL);
		// �ݒn�_����擾����B
		List<Map<String, Object>> kstKykList = dao.getQueryResult(param, "FKSR001_SEL_005", CommonDAO.PRINT_SQL);
		// �ٓ��������擾����B
		List<Map<String, Object>> idoRrkList = dao.getQueryResult(param, "FKSR001_SEL_006", CommonDAO.PRINT_SQL);
		// �v��n���擾����B
		List<Map<String, Object>> yechCntList = dao.getQueryResult(param, "FKSR001_SEL_008", CommonDAO.PRINT_SQL);
		// �ݕt���擾����B
		List<Map<String, Object>> kastCntList = dao.getQueryResult(param, "FKSR001_SEL_009", CommonDAO.PRINT_SQL);

		// ���׍s�̕ҏW
		List<Map<String, Object>> listParams = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> listParams2 = new ArrayList<Map<String, Object>>();
		int pageNo = 1;
		int startId = 0;
		int fullPage = 0;

		// �d���Ǘ����׍ő�y�[�W���擾
		int chfkPageMax = getPageMax(chfkKnrList.size());
		// �ݕt�_��ő�y�[�W���擾
		int kstPageMax = getPageMax(kstKykList.size());

		//���[�̍ő�y�[�W������
		if (chfkPageMax > kstPageMax) {
			fullPage = chfkPageMax;
		} else {
			fullPage = kstPageMax;
		}

		while (chfkKnrList.size() > startId || kstKykList.size() > startId) {
			Map<String, Object> beanParam = new HashMap<String, Object>();
			beanParam.putAll(getHeaderData(syuList, chobList, pageNo, fullPage));
			beanParam.putAll(getFooterData(syuList, pageNo));

			if (pageNo == 1) {
				beanParam.putAll(getSyuData(dao, syuList, yechCntList, kastCntList, kichoDateList, chobList));
				beanParam.putAll(getDetailChfkKnrData(dao, chfkKnrList));
				beanParam.putAll(getKasKykData(kstKykList));
				beanParam.putAll(getIdoRrkUpData(dao, idoRrkList));
				beanParam.putAll(getIdoRrkDwnData(idoRrkList));
				listParams.add(beanParam);
				startId += LINE_MAX;
			} else {
				beanParam.putAll(getDetailChfkKnrData2(dao, chfkKnrList, startId));
				beanParam.putAll(getKasKykData2(kstKykList, startId));
				listParams2.add(beanParam);
				startId += LINE_MAX_2;
			}
			pageNo++;
		}

		// �o�͐�t�@�C�����w�肷��B
		String exportTempFolder = SystemConfiguration.get(FrameworkConstants.EXPORT_TEMPORARY_FOLDER);
		String kkshCd = syuList.get(0).get("DAI_KKSH_CD").toString();
		String outFile = CommonModule.getRealPath(exportTempFolder + File.separator + getFileID(kkshCd));

		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = CommonModule.getTemplateFileName(Constants.TEMPLATE_MAP.get(REPORT_ID + "_1"));
		String templateFileName2 = CommonModule.getTemplateFileName(Constants.TEMPLATE_MAP.get(REPORT_ID + "_2"));

		// �o�̓t�@�C��������ɍ쐬�ł��Ă��邱�ƁB
		JasperPrint jasper = JasperFillManager.fillReport(templateFileName, new HashMap<String, Object>(), new JRBeanCollectionDataSource(listParams));
		JasperPrint jasper2 = JasperFillManager.fillReport(templateFileName2, new HashMap<String, Object>(), new JRBeanCollectionDataSource(listParams2));

		//���[��ǉ�
		for (JRPrintPage page : jasper2.getPages()) {
			jasper.addPage(page);
		}

		// ����C���[�W��PDF�t�@�C���ɏo�͂���B
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		// �ԋp�l�ݒ�
		Map<String, String> fileInfo = new HashMap<String, String>();
		fileInfo.put(Constants.DOWNLOAD_PATH_KEY, outFile + ".pdf");
		fileInfo.put(Constants.DOWNLOAD_NAME_KEY, getFileID(kkshCd) + ".pdf");
		return fileInfo;
	}


	/**
	 * �w�b�_�\�����e���擾���܂��B.
	 * @param syuList	�ЗL�䒠���
	 * @param chobList	���떾�׏��
	 * @param pageNo	�y�[�W�ԍ�
	 * @param fullPage	�S�y�[�W��
 	 * @return �w�b�_�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getHeaderData(List<Map<String, Object>> syuList, List<Map<String, Object>> chobList,
			int pageNo, int fullPage) throws Exception {
		Map<String, Object> headerMap = new HashMap<String, Object>();

		Map<String, Object> syuMap = syuList.get(0);
		String templateId = "FKSR001_2";
		String snhKbnId = "FKSR001_2_010";
		if (pageNo == 1) {
			templateId = "FKSR001_1";
			snhKbnId = "FKSR001_1_063";
		}
		headerMap.put(templateId + "_001", syuMap.get("SFSK_CD"));
		headerMap.put(templateId + "_002", syuMap.get("SFSK_NAME"));
		headerMap.put(templateId + "_003", syuMap.get("DAI_KKSH_NAME"));
		headerMap.put(templateId + "_004", syuMap.get("GNB_KKSH_NAME"));
		headerMap.put(templateId + "_005", syuMap.get("JUT_KKSH_NAME"));
		// �o�͏����Ɉ�v����ꍇ
		if (isMatch(chobList, syuMap.get("SNH_KBN").toString())) {
			headerMap.put(templateId + "_006", NOTE);
		} else {
			headerMap.put(templateId + "_006", "");
		}
		headerMap.put("FKSR001_1_007", CommonModule.formatJPEijiYMD((new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD)).format(new Date())));
		headerMap.put("FKSR001_1_008", String.valueOf(pageNo));
		headerMap.put("FKSR001_1_009", String.valueOf(fullPage));
		if (NASHI_FLG.equals(syuMap.get("SNH_KBN").toString())) {
			headerMap.put(snhKbnId, "�i�����j");
		} else {
			headerMap.put(snhKbnId, "");
		}
		return headerMap;
	}

	/**
	 * �t�b�^�\�����e���擾���܂��B.
	 * @param syuList	�ЗL�䒠���
	 * @param pageNo 	�y�[�W�ԍ�
 	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFooterData(List<Map<String, Object>> syuList, int pageNo) throws Exception {
		Map<String, Object> footerMap = new HashMap<String, Object>();

		Map<String, Object> syuMap = syuList.get(0);
		if (pageNo == 1) {
			footerMap.put("FKSR001_1_501", syuMap.get("CMPY_NAME"));
		} else {
			footerMap.put("FKSR001_2_401", syuMap.get("CMPY_NAME"));
		}
		return footerMap;
	}

	/**
	 * ���o�����\�����e���擾���܂��B.
	 * @param dao 			DAO
	 * @param syuList 		�ЗL�䒠���
	 * @param yechCntList 	�v��n���
	 * @param kastCntList 	�ݕt���
	 * @param kichoDateList ��v�L���N�������
	 * @param chobList		���떾�׏��
 	 * @return ���o�����\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getSyuData(CommonDAO dao, List<Map<String, Object>> syuList, List<Map<String, Object>> yechCntList, List<Map<String, Object>> kastCntList, List<Map<String, Object>> kichoDateList, List<Map<String, Object>> chobList) throws Exception {
		Map<String, Object> syuDataMap = new HashMap<String, Object>();

		Map<String, Object> syuMap = syuList.get(0);
		Map<String, Object> kichoDateLMap = kichoDateList.get(0);
		Map<String, Object> chobMap = chobList.get(0);

		//�J���}��؂�t�H�[�}�b�g
		NumberFormat nfNum = NumberFormat.getNumberInstance();

		//�����_�ȉ��Q���t�H�[�}�b�g
		DecimalFormat decimalFormat = new DecimalFormat("#,###,###,###.00");
		decimalFormat.setMaximumFractionDigits(2);
		decimalFormat.setMinimumFractionDigits(2);

		syuDataMap.put("FKSR001_1_010", syuMap.get("SYU_NO"));
		syuDataMap.put("FKSR001_1_011", syuMap.get("BKN_NO"));
		syuDataMap.put("FKSR001_1_012", syuMap.get("SSN_NO"));
		syuDataMap.put("FKSR001_1_013", syuMap.get("GENK_CTR_NAME"));
		syuDataMap.put("FKSR001_1_014", CommonModule.getKbn(dao, Constants.KMK_CD, ((String) syuMap.get("KMK_CD"))));
		syuDataMap.put("FKSR001_1_015", syuMap.get("WBS_YOS"));
		syuDataMap.put("FKSR001_1_016", syuMap.get("WBS_NAME"));
		syuDataMap.put("FKSR001_1_017", syuMap.get("KAN_CD"));
		syuDataMap.put("FKSR001_1_018", syuMap.get("KAN_NAME"));
		syuDataMap.put("FKSR001_1_019", syuMap.get("KKT_CD").toString().substring(0, 7) + "-" + syuMap.get("KKT_CD").toString().substring(7));
		syuDataMap.put("FKSR001_1_020", syuMap.get("KKT_NAME"));
		syuDataMap.put("FKSR001_1_021", syuMap.get("DHY_KKT_CD"));
		syuDataMap.put("FKSR001_1_022", syuMap.get("DHY_KKT_NAME"));
		syuDataMap.put("FKSR001_1_023", CommonModule.getKbn(dao, Constants.KNRI_SBT_CD, ((String) syuMap.get("KNRI_SBT"))));
		syuDataMap.put("FKSR001_1_024", syuMap.get("TET_NO"));
		syuDataMap.put("FKSR001_1_025", CommonModule.getKbn(dao, Constants.CMK_CD, ((String) syuMap.get("CMK_KOB_KBN"))));
		syuDataMap.put("FKSR001_1_026", CommonModule.getKbn(dao, Constants.CMK_CD, ((String) syuMap.get("CMK_GEK_KBN"))));
		syuDataMap.put("FKSR001_1_027", CommonModule.getKbn(dao, Constants.SHK_JIY_KBN, ((String) syuMap.get("SHK_JIY_KBN"))));
		syuDataMap.put("FKSR001_1_028", CommonModule.formatJPEijiYMD(syuMap.get("SHK_DATE").toString()));
		syuDataMap.put("FKSR001_1_029", syuMap.get("RIT_KIT_NO"));
		syuDataMap.put("FKSR001_1_030", CommonModule.formatJPEijiYMD(syuMap.get("RIT_KIT_DATE").toString()));
		syuDataMap.put("FKSR001_1_031", nfNum.format(Long.parseLong(syuMap.get("SHK_KIN").toString())));
		syuDataMap.put("FKSR001_1_032", CommonModule.getKbn(dao, Constants.SEBJKY_CD, ((String) syuMap.get("KYKS_KBN"))));
		syuDataMap.put("FKSR001_1_033", CommonModule.getKbn(dao, Constants.SEBJKY_CD, ((String) syuMap.get("JOSSK_Z_KBN"))));
		syuDataMap.put("FKSR001_1_034", CommonModule.getKbn(dao, Constants.SEBJKY_CD, ((String) syuMap.get("TKSS_KBN"))));
		syuDataMap.put("FKSR001_1_035", CommonModule.getKbn(dao, Constants.YOT_CD, ((String) syuMap.get("YOT_CD"))));
		syuDataMap.put("FKSR001_1_036", CommonModule.formatJPEijiYMD(syuMap.get("TKI_DATE").toString()));
		syuDataMap.put("FKSR001_1_037", CommonModule.getKbn(dao, Constants.MTKIT_RYU_KBN, ((String) syuMap.get("MTKIT_RYU_KBN"))));
		syuDataMap.put("FKSR001_1_038", CommonModule.getKbn(dao, Constants.TSK_KBN, ((String) syuMap.get("TSK_YOT_KBN"))));
		syuDataMap.put("FKSR001_1_039", CommonModule.getKbn(dao, Constants.SYU_KENCH_KBN, (String) syuMap.get("SYU_KENCH_KBN")));
		if (Integer.parseInt(yechCntList.get(0).get("COUNT").toString()) >= 1) {
			syuDataMap.put("FKSR001_1_040", MOJI_ARI);
		} else {
			syuDataMap.put("FKSR001_1_040", "");
		}
		if (Integer.parseInt(kastCntList.get(0).get("COUNT").toString()) >= 1) {
			syuDataMap.put("FKSR001_1_041", MOJI_ARI);
		} else {
			syuDataMap.put("FKSR001_1_041", "");
		}
		syuDataMap.put("FKSR001_1_042", CommonModule.getKbn(dao, Constants.JOSO_DIS_KBN, (String) syuMap.get("JOSO_DIS_KBN")));
		syuDataMap.put("FKSR001_1_043", decimalFormat.format(new BigDecimal(syuMap.get("MES_KOB").toString())));
		syuDataMap.put("FKSR001_1_044", decimalFormat.format(new BigDecimal(syuMap.get("MES_JOSSK").toString())));
		syuDataMap.put("FKSR001_1_045", syuMap.get("TDFK_NAME").toString().substring(0, 4));
		syuDataMap.put("FKSR001_1_046", syuMap.get("TDFK_NAME").toString().substring(4));
		syuDataMap.put("FKSR001_1_047", syuMap.get("OOA_TSH_NAME"));
		syuDataMap.put("FKSR001_1_048", syuMap.get("BKN_ACM"));
		syuDataMap.put("FKSR001_1_049", syuMap.get("BKN_CBN"));
		syuDataMap.put("FKSR001_1_050", syuMap.get("OLD_SYSH_TDFK_NAME").toString().substring(0, 4));
		syuDataMap.put("FKSR001_1_051", syuMap.get("OLD_SYSH_TDFK_NAME").toString().substring(4));
		syuDataMap.put("FKSR001_1_052", syuMap.get("OLD_SYSH_OOA_TSH_NAME"));
		syuDataMap.put("FKSR001_1_053", syuMap.get("OLD_SYSH_ACM"));
		syuDataMap.put("FKSR001_1_054", syuMap.get("OLD_SYSH_CBN"));
		syuDataMap.put("FKSR001_1_055", syuMap.get("OLD_SYSH_NAME"));
		syuDataMap.put("FKSR001_1_056", nfNum.format(Long.parseLong(syuMap.get("KYYU_MCBN_BUNS").toString())));
		syuDataMap.put("FKSR001_1_057", nfNum.format(Long.parseLong(syuMap.get("KYYU_MCBN_BUIB").toString())));
		if (kichoDateList.size() > 1) {
			syuDataMap.put("FKSR001_1_058", "***");
		} else {
			syuDataMap.put("FKSR001_1_058", "");
		}
		syuDataMap.put("FKSR001_1_059", CommonModule.formatJPEijiYMD(kichoDateLMap.get("KAIKE_KICHO_DATE").toString()));
		syuDataMap.put("FKSR001_1_060", nfNum.format(Long.parseLong(chobMap.get("CHOB_GENK_ZAN_KIN").toString())));
		syuDataMap.put("FKSR001_1_061", nfNum.format(Long.parseLong(chobMap.get("FUTKIN").toString())));
		syuDataMap.put("FKSR001_1_062", nfNum.format(Long.parseLong(chobMap.get("GENS_SONS_SUM_KIN").toString())));
		return syuDataMap;
	}

	/**
	 * �d���Ǘ�����(1�y�[�W��)�\�����e���擾���܂��B.
	 * @param dao 			DAO
	 * @param chfkKnrList 	�d���Ǘ����
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getDetailChfkKnrData(CommonDAO dao, List<Map<String, Object>> chfkKnrList) throws Exception {
		Map<String, Object> detailChfkKnrData = new HashMap<String, Object>();

		//�����_�ȉ��Q���t�H�[�}�b�g
		DecimalFormat decimalFormat = new DecimalFormat("#,###,###,###.00");
		decimalFormat.setMaximumFractionDigits(2);
		decimalFormat.setMinimumFractionDigits(2);

		int itemId = 101;
		int lineNum = 0;
		while (LINE_MAX > lineNum) {
			if (lineNum < chfkKnrList.size()) {
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("SYU_NO"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("WBS_YOS"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("WBS_NAME"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("SSN_NO"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("DAI_KKSH_NAME"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("GNB_KKSH_NAME"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), CommonModule.getKbn(dao, Constants.KMK_CD, ((String) chfkKnrList.get(lineNum).get("KMK_CD"))));
				if ("0".equals(chfkKnrList.get(lineNum).get("SNH_KBN").toString())) {
					detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), MOJI_ARI);
				} else {
					detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				}
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("KAN_CD"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("KAN_NAME"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), chfkKnrList.get(lineNum).get("GENK_CTR_NAME"));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(chfkKnrList.get(lineNum).get("MES_KOB").toString())));
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(chfkKnrList.get(lineNum).get("MES_JOSSK").toString())));
			} else {
				//��s�o��
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_1_" + String.valueOf(itemId++), "");
			}
			lineNum++;
		}

		return detailChfkKnrData;
	}

	/**
	 * �ݕt�_��(1�y�[�W��)�\�����e���擾���܂��B.
	 * @param kstKykList 	�ݕt�_����
 	 * @return �ݕt�_��\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getKasKykData(List<Map<String, Object>> kstKykList) throws Exception {
		Map<String, Object> kasKykData = new HashMap<String, Object>();

		//�����_�ȉ��Q���t�H�[�}�b�g
		DecimalFormat decimalFormat = new DecimalFormat("#,###,###.00");
		decimalFormat.setMaximumFractionDigits(2);
		decimalFormat.setMinimumFractionDigits(2);

		int itemId = 201;
		int lineNum = 0;
		while (LINE_MAX > lineNum) {
			if (lineNum < kstKykList.size()) {
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYK_NO"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_ADD_YUB_NO_UP_3"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_ADD_YUB_NO_DWN_4"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_TDFK_NAME").toString().substring(0, 4));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_TDFK_NAME").toString().substring(4));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_OOA_TSH_NAME"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_ACM"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_CBN"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_NAME"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), kstKykList.get(lineNum).get("KYKSH_TEL_NO"));
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(kstKykList.get(lineNum).get("KAST_SUM_MES").toString())));
			} else {
				//��s�o��
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_1_" + String.valueOf(itemId++), "");
			}
			lineNum++;
		}
		return kasKykData;
	}

	/**
	 * ������e��i�\�����e���擾���܂��B.
	 * @param dao 			DAO
	 * @param idoRrkList 	�ٓ��������
 	 * @return ������e�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getIdoRrkUpData(CommonDAO dao, List<Map<String, Object>> idoRrkList) throws Exception {
		Map<String, Object> idoRrkUpData = new HashMap<String, Object>();

		int itemId = 301;
		int lineNum = 0;
		while (RRK_LINE_MAX > lineNum) {
			if (lineNum < idoRrkList.size()) {
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), String.valueOf(lineNum + 1));
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), CommonModule.getKbn(dao, Constants.IDO_SBT_SYU, ((String) idoRrkList.get(lineNum).get("SYU_IDO_SBT"))));
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(idoRrkList.get(lineNum).get("RRK_IDO_DATE").toString()));
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), idoRrkList.get(lineNum).get("IDO_KKTS_NO"));
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(idoRrkList.get(lineNum).get("IDO_KIT_DATE").toString()));
			} else {
				//��s�o��
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkUpData.put("FKSR001_1_" + String.valueOf(itemId++), "");
			}
			lineNum++;

		}

		return idoRrkUpData;
	}

	/**
	 * ������e���i�\�����e���擾���܂��B.
	 * @param idoRrkList 	�ٓ��������
 	 * @return ������e�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getIdoRrkDwnData(List<Map<String, Object>> idoRrkList) throws Exception {
		Map<String, Object> idoRrkDwnData = new HashMap<String, Object>();

		int itemId = 401;
		int lineNum = 0;
		while (RRK_LINE_MAX > lineNum) {
			if (lineNum < idoRrkList.size()) {
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), String.valueOf(lineNum + 1));
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(idoRrkList.get(lineNum).get("BKO_IDO_DATE").toString()));
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), idoRrkList.get(lineNum).get("SYU_TCH_BKO"));
			} else {
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), "");
				idoRrkDwnData.put("FKSR001_1_" + String.valueOf(itemId++), "");
			}
			lineNum++;
		}

		return idoRrkDwnData;
	}

	/**
	 * �d���Ǘ�����(2�y�[�W�ڈȍ~)�\�����e���擾���܂��B.
	 * @param dao 			DAO
	 * @param chfkKnrList 	�d���Ǘ����
	 * @param startId		�J�nID
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getDetailChfkKnrData2(CommonDAO dao, List<Map<String, Object>> chfkKnrList, int startId) throws Exception {
		Map<String, Object> detailChfkKnrData = new HashMap<String, Object>();

		//�����_�ȉ��Q���t�H�[�}�b�g
		DecimalFormat decimalFormat = new DecimalFormat("#,###,###,###.00");
		decimalFormat.setMaximumFractionDigits(2);
		decimalFormat.setMinimumFractionDigits(2);

		int itemId = 101;
		int lineNum = 0;
		while (LINE_MAX_2 > lineNum) {
			if (startId < chfkKnrList.size()) {
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("SYU_NO"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("WBS_YOS"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("WBS_NAME"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("SSN_NO"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("DAI_KKSH_NAME"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("GNB_KKSH_NAME"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), CommonModule.getKbn(dao, Constants.KMK_CD, ((String) chfkKnrList.get(startId).get("KMK_CD"))));
				if ("0".equals(chfkKnrList.get(startId).get("SNH_KBN").toString())) {
					detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), MOJI_ARI);
				} else {
					detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				}
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("KAN_CD"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("KAN_NAME"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), chfkKnrList.get(startId).get("GENK_CTR_NAME"));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(chfkKnrList.get(startId).get("MES_KOB").toString())));
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(chfkKnrList.get(startId).get("MES_JOSSK").toString())));
			} else {
				//��s�o��
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				detailChfkKnrData.put("FKSR001_2_" + String.valueOf(itemId++), "");
			}

			startId++;
			lineNum++;
		}

		return detailChfkKnrData;
	}

	/**
	 * �ݕt�_��(2�y�[�W��)�\�����e���擾���܂��B.
	 * @param kstKykList 	�ݕt�_����
	 * @param startId		�J�nID
 	 * @return �ݕt�_��\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getKasKykData2(List<Map<String, Object>> kstKykList, int startId) throws Exception {
		Map<String, Object> kasKykData = new HashMap<String, Object>();

		//�����_�ȉ��Q���t�H�[�}�b�g
		DecimalFormat decimalFormat = new DecimalFormat("#,###,###.00");
		decimalFormat.setMaximumFractionDigits(2);
		decimalFormat.setMinimumFractionDigits(2);

		int itemId = 301;
		int lineNum = 0;
		while (LINE_MAX_2 > lineNum) {
			if (startId < kstKykList.size()) {
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYK_NO"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_ADD_YUB_NO_UP_3"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_ADD_YUB_NO_DWN_4"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_TDFK_NAME").toString().substring(0, 4));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_TDFK_NAME").toString().substring(4));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_OOA_TSH_NAME"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_ACM"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_CBN"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_NAME"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), kstKykList.get(startId).get("KYKSH_TEL_NO"));
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), decimalFormat.format(new BigDecimal(kstKykList.get(startId).get("KAST_SUM_MES").toString())));
			} else {
				//��s�o��
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
				kasKykData.put("FKSR001_2_" + String.valueOf(itemId++), "");
			}
			startId++;
			lineNum++;
		}

		return kasKykData;
	}

	/**
	 * ���X�g�T�C�Y�ɑ΂���ő�y�[�W�����擾���܂��B.
	 * @param listSize ���X�g�T�C�Y
	 * @return �ő�y�[�W��
	 */
	private int getPageMax(int listSize) {
		if (listSize > LINE_MAX) {
			return ((listSize - LINE_MAX - 1) / LINE_MAX_2) + 1;
		}

		return 1;
	}

	/**
	 * �t�@�C��ID���쐬���܂��B.
	 * �t�@�C��ID = ���[ID_���t(�N���������b)_�Ǘ��ӏ��R�[�h
	 * @param kkshCd �䒠�Ǘ��ӏ��R�[�h
	 * @return �t�@�C��ID
	 */
	private String getFileID(String kkshCd) {
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());
		String fileId = REPORT_ID + "_" + timeStr + "_" + kkshCd;
		return fileId;
	}

	/**
	 * �o�c�Ǘ��ƁC���댴���̈�v����.
	 * @param chobList	���떾�׏��
	 * @param snhKbn	�ݔp�敪
	 * @return ���茋��
	 */
	private boolean isMatch(List<Map<String, Object>> chobList, String snhKbn) {
		if (!NASHI_FLG.equals(snhKbn) || chobList == null || chobList.size() == 0) {
			return false;
		}
		Map<String, Object> chobMap = chobList.get(0);
		String chobGenksttsFlg = chobMap.get("CHOB_GENK_STTS_FLG").toString();
		String futkinUmuFlg = chobMap.get("FUTKIN_UMU_FLG").toString();
		String gensSonsSumKinUmuFlg = chobMap.get("GENS_SONS_SUM_KIN_UMU_FLG").toString();

		if (NASHI_FLG.equals(chobGenksttsFlg)) {
			return false;
		}
		if ((NASHI_FLG.equals(futkinUmuFlg) || SPACE.equals(futkinUmuFlg))
				&& (NASHI_FLG.equals(gensSonsSumKinUmuFlg) || SPACE.equals(gensSonsSumKinUmuFlg))) {
			return false;
		}

		return true;
	}
}
