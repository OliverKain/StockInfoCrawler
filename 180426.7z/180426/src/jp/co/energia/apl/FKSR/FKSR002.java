/**
 * FKSR002.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSR;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.enecom.framework.config.SystemConfiguration;
import jp.co.enecom.framework.constants.FrameworkConstants;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �ЗL�䒠���[�쐬�p�N���X�ł��B.
 * Ver.00.00.00 2018/04/17 : Kiennlt - Brand New
 */
public class FKSR002 {

	/** REPORT_ID. */
	private static final String REPORT_ID = "FKSR002";
	/** REPORT_ID_TEMPLATE_1. */
	private static final String REPORT_ID_1 = "FKSR002_1";
	/** REPORT_ID_TEMPLATE_2. */
	private static final String REPORT_ID_2 = "FKSR002_2";
	/** Record per page. */
	private static final int RECORD_PER_PAGE = 20;
	/** Decimal format 1. */
	private static final String DECIMAL_FORMAT_1 = "#,###,##0,00";
	/** Decimal format 2. */
	private static final String DECIMAL_FORMAT_2 = "###,###,###,##0";
	/** Decimal format 3. */
	private static final String DECIMAL_FORMAT_3 = "#,###,##0";
	/** Decimal format 4. */
	private static final String DECIMAL_FORMAT_4 = "##,###,###,##0";
	/** �Ȃ��i�t���O�j. */
	private static final String NASHI_FLG = "0";

	/** �R���X�g���N�^. */
	public FKSR002() { };


	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @param param ���[�쐬�p�����[�^
	 * @return �_�E�����[�h���
	 * @throws Exception ��O
	 */
	public Map<String, String> makePrinFile(CommonDAO dao, Map<String, Object>param) throws Exception {

		// SQL�擾
		List<Map<String, Object>> sql1 = dao.getQueryResult(param, "FKSR002_SELECT_001", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql2 = dao.getQueryResult(param, "FKSR002_SELECT_002", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql3 = dao.getQueryResult(param, "FKSR002_SELECT_003", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql4 = dao.getQueryResult(param, "FKSR002_SELECT_004", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql5 = dao.getQueryResult(param, "FKSR002_SELECT_005", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql6 = dao.getQueryResult(param, "FKSR002_SELECT_006", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> sql7 = dao.getQueryResult(param, "FKSR002_SELECT_007", CommonDAO.PRINT_SQL);

		// ���׍s�̕ҏW
		List<Map<String, Object>> detailParams = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> detailParams2 = new ArrayList<Map<String, Object>>();
		int totalPage = ((sql5.size() - 5 - 1) / RECORD_PER_PAGE) + 2;
		int currentPage = 1;

		// Have data
		Map<String, Object> recordData = new HashMap<String, Object>();

		// Header
		recordData.putAll(getHeaderData(dao, sql1, totalPage, currentPage, true));

		// Detail
		recordData.putAll(groupDetailData(dao, sql1, sql2, sql3, sql4, sql5, sql6, sql7));

		int totalPagePrint = totalPage;
		int startIndex = 5;
		int endIndex = 5 + RECORD_PER_PAGE;

		// �E�������ׂ�5�s�𒴂����ꍇ�C�ؗp�䒠�i2�j���o�͂���B
		if (sql5.size() > 5) {
			while (totalPage > 1) {
				Map<String, Object> recordData2 = new HashMap<String, Object>();
				currentPage += 1;

				// Header
				recordData2.putAll(getHeaderData(dao, sql1, totalPagePrint, currentPage, false));
				// Init before put detail data
				recordData2.putAll(initForReportTwo(startIndex, endIndex));

				// Get index of total record
				if (endIndex > sql5.size()) {
					endIndex = sql5.size();
				}
				// Put detail data
				recordData2.putAll(editForReportTwo(dao, sql5, startIndex, endIndex));

				// Footer
				recordData2.putAll(getFooterData(sql1, false));

				startIndex += RECORD_PER_PAGE;
				endIndex += RECORD_PER_PAGE;

				detailParams2.add(recordData2);
				totalPage--;
			}
		}

		// Footer
		recordData.putAll(getFooterData(sql1, true));
		detailParams.add(recordData);

		// �o�͐�t�@�C�����w�肷��B
		String exportTempFolder = SystemConfiguration.get(FrameworkConstants.EXPORT_TEMPORARY_FOLDER);
		// TODO
		String kkshCd = Constants.EMPTY;
		String outFile = CommonModule.getRealPath(exportTempFolder + File.separator + getFileID(kkshCd));

		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = CommonModule.getTemplateFileName(Constants.TEMPLATE_MAP.get(REPORT_ID_1));
		String templateFileName2 = CommonModule.getTemplateFileName(Constants.TEMPLATE_MAP.get(REPORT_ID_2));

		// �o�̓t�@�C��������ɍ쐬�ł��Ă��邱�ƁB
		JasperPrint jasper = JasperFillManager.fillReport(templateFileName,
														  new HashMap<String, Object>(),
														  new JRBeanCollectionDataSource(detailParams));
		JasperPrint jasper2 = JasperFillManager.fillReport(templateFileName2,
														   new HashMap<String, Object>(),
														   new JRBeanCollectionDataSource(detailParams2));

		//���[��ǉ�
		for (JRPrintPage page : jasper2.getPages()) {
			jasper.addPage(page);
		}

		// ����C���[�W��PDF�t�@�C���ɏo�͂���B
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		Map<String, String> fileInfo = new HashMap<String, String>();
		fileInfo.put(Constants.DOWNLOAD_PATH_KEY, outFile + ".pdf");
		fileInfo.put(Constants.DOWNLOAD_NAME_KEY, getFileID(kkshCd) + ".pdf");

		return fileInfo;
	}

	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao CommonDAO
	 * @param dMap1 ���[�쐬�p�����[�^
	 * @param dMap2 ���[�쐬�p�����[�^
	 * @param dMap3 ���[�쐬�p�����[�^
	 * @param dMap4 ���[�쐬�p�����[�^
	 * @param dMap5 ���[�쐬�p�����[�^
	 * @param dMap6 ���[�쐬�p�����[�^
	 * @param dMap7 ���[�쐬�p�����[�^
	 * @return �_�E�����[�h���
	 */
	private Map<String, Object> groupDetailData(CommonDAO dao,
			  									List<Map<String, Object>> dMap1,
			  									List<Map<String, Object>> dMap2,
			  									List<Map<String, Object>> dMap3,
			  									List<Map<String, Object>> dMap4,
			  									List<Map<String, Object>> dMap5,
			  									List<Map<String, Object>> dMap6,
			  									List<Map<String, Object>> dMap7) {

		Map<String, Object> detailData = new HashMap<String, Object>();

		try {
			detailData.putAll(getFirstDetailData(dao, dMap1, dMap2));
			detailData.putAll(getSecondDetailData(dao, dMap2));
			detailData.putAll(getThirdDetailData(dao, dMap3));
			detailData.putAll(initFourDetailData(3));
			detailData.putAll(getFourDetailData(dao, dMap4, dMap4.size()));
			detailData.putAll(initFiveDetailData(5));
			detailData.putAll(getFiveDetailData(dao, dMap5, dMap5.size()));
			detailData.putAll(initSixDetailData(5));
			detailData.putAll(getSixDetailData(dao, dMap6, dMap6.size()));
			detailData.putAll(initSevenDetailData(5));
			detailData.putAll(getSevenDetailData(dao, dMap7, dMap7.size()));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return detailData;
	}

	/**
	 * �w�b�_�\�����e���擾���܂��B.
	 * @param dao 	     CommonDAO
	 * @param hList 	     �ЗL�䒠���
	 * @param totalPage   Total page in report
	 * @param currentPage Current page
	 * @param isFirstPage If current page is first page -> true
 	 * @return �w�b�_�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getHeaderData(CommonDAO dao,
											  List<Map<String, Object>> hList,
											  int totalPage,
											  int currentPage,
											  boolean isFirstPage) throws Exception {

		Map<String, Object> headerMap = new HashMap<String, Object>();
		if (hList.size() != 0) {
			Map<String, Object> hMap = hList.get(0);

			String reportTemp = "1";
			// If using report template 2.
			if (!isFirstPage) {
				reportTemp = "2";
				headerMap.put("FKSR002_2_009", Constants.EMPTY);
				// �Ȃ��i�t���O�j
				if (NASHI_FLG.equals(CommonModule.cnvStr(headerMap.get("SNH_KBN")))) {
					headerMap.put("FKSR002_2_009", "�i�����j");
				}
			}

			// ���t��
			headerMap.put("FKSR002_" + reportTemp + "_001" , hMap.get("SFSK_CD"));
			// ���t�於
			headerMap.put("FKSR002_" + reportTemp + "_002" , hMap.get("SFSK_NAME"));
			// �䒠�Ǘ��ӏ�
			headerMap.put("FKSR002_" + reportTemp + "_003" , hMap.get("DAI_KKSH_NAME"));
			// ����y�n�Ǘ��ӏ�
			headerMap.put("FKSR002_" + reportTemp + "_004" , hMap.get("JUT_KKSH_NAME"));
			// ���Ӄ��b�Z�[�W
			if (!isFirstPage) {
				// TODO
			} else {
				headerMap.put("FKSR002_" + reportTemp + "_005" , hMap.get("-"));
			}

			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Date date = new Date();
			// ���ݔN����
			headerMap.put("FKSR002_" + reportTemp + "_006" , CommonModule.formatJPEijiYMD(dateFormat.format(date)));
			// ���ݕ�
			headerMap.put("FKSR002_" + reportTemp + "_007" , String.valueOf(currentPage));
			// �S��
			headerMap.put("FKSR002_" + reportTemp + "_008" , String.valueOf(totalPage));
		}

		return headerMap;
	}

	/**
	 * �d���Ǘ�����(1�y�[�W��)�\�����e���擾���܂��B.
	 * @param dao 	 CommonDAO
	 * @param dMap 	 FKSR002_SELECT_001
	 * @param dMap2  FKSR002_SELECT_002
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFirstDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap,
											  List<Map<String, Object>> dMap2) throws Exception {

		Map<String, Object> detailData = new HashMap<String, Object>();
		Map<String, Object> detaiMap = dMap.get(0);

		// �_��ԍ�
		detailData.put("FKSR002_1_009" , CommonModule.cnvStr(detaiMap.get("KYK_NO")));
		// ���Y�ԍ�
		detailData.put("FKSR002_1_010" , CommonModule.cnvStr(detaiMap.get("SSN_NO")));
		// �����Z���^
		detailData.put("FKSR002_1_011" , CommonModule.cnvStr(detaiMap.get("GENK_CTR_NAME")));
		// �ݔ��Ȗ�
		detailData.put("FKSR002_1_012" , CommonModule.cnvStr(
												CommonModule.getKbn(
														dao, Constants.KMK_CD, CommonModule.cnvStr(detaiMap.get("KMK_CD")))));
		// �������
		detailData.put("FKSR002_1_013" , CommonModule.cnvStr(
												CommonModule.getKbn(
														dao, Constants.KNRI_SBT_CD, CommonModule.cnvStr(detaiMap.get("KNRI_SBT")))));
		// ���c�P��
		detailData.put("FKSR002_1_014" , CommonModule.cnvStr(
												CommonModule.getKbn(
														dao, Constants.TND_KYOG_TNK, CommonModule.cnvStr(detaiMap.get("KYOG_TNK_CMK_KBN")))));
		// �v�a�r�v�f
		detailData.put("FKSR002_1_015" , CommonModule.cnvStr(detaiMap.get("WBS_YOS")));
		// �v�a�r����
		detailData.put("FKSR002_1_016" , CommonModule.cnvStr(detaiMap.get("WBS_NAME")));
		// �_��
		detailData.put("FKSR002_1_017" , CommonModule.cnvStr(
												CommonModule.getKbn(
														dao, Constants.SEBJKY_CD, CommonModule.cnvStr(detaiMap.get("KYKS_KBN")))));
		// �����́i�R�[�h�j
		detailData.put("FKSR002_1_018" , CommonModule.cnvStr(detaiMap.get("KAN_CD")));
		// ������
		detailData.put("FKSR002_1_019" , CommonModule.cnvStr(detaiMap.get("KAN_NAME")));
		// �����}
		detailData.put("FKSR002_1_020" , CommonModule.cnvStr(
												CommonModule.getKbn(
														dao, Constants.SEBJKY_CD, CommonModule.cnvStr(detaiMap.get("JOSSK_Z_KBN")))));
		// ��n���́i�R�[�h�j
		detailData.put("FKSR002_1_021" , CommonModule.cnvStr(detaiMap.get("KKT_CD")));
		// ��n����
		detailData.put("FKSR002_1_022" , CommonModule.cnvStr(detaiMap.get("KKT_NAME")));
		// �o�^�Ϗ�
		detailData.put("FKSR002_1_023" , CommonModule.cnvStr(
												CommonModule.getKbn(dao, Constants.SEBJKY_CD,
														CommonModule.cnvStr(detaiMap.get("TKSS_KBN")))));
		// ���Č��菑�ԍ�
		detailData.put("FKSR002_1_024" , CommonModule.cnvStr(detaiMap.get("RIT_KIT_NO")));
		// ���Č���N
		detailData.put("FKSR002_1_025" , CommonModule.formatJPEijiYMD(
												CommonModule.cnvStr(detaiMap.get("RIT_KIT_DATE"))));
		// �p�r
		detailData.put("FKSR002_1_026" , CommonModule.cnvStr(
												CommonModule.getKbn(dao, Constants.YOT_CD,
														CommonModule.cnvStr(detaiMap.get("YOT_CD")))));
		// �ؒn���v�ʐ�
		detailData.put("FKSR002_1_027" , CommonModule.decimalFormat(
											new BigDecimal(
												CommonModule.cnvStr(detaiMap.get("SHKT_SUM_MES"))), DECIMAL_FORMAT_1));
		// �d���_��{��
		detailData.put("FKSR002_1_028" , CommonModule.cnvStr(detaiMap.get("DNC_KYK_SU")));
		// �������N����
		detailData.put("FKSR002_1_029" , CommonModule.formatJPEijiYMD(
												CommonModule.cnvStr(detaiMap.get("NXT_KATE_DATE"))));
		// �_��N
		detailData.put("FKSR002_1_030" , CommonModule.formatJPEijiYMD(
												CommonModule.cnvStr(detaiMap.get("KYK_DATE"))));
		// �����X�V
		detailData.put("FKSR002_1_031" , CommonModule.cnvStr(detaiMap.get("AUTO_UPD_SKI")));
		// �_��Ώۊ��ԁi���j�N����
		detailData.put("FKSR002_1_032" , CommonModule.formatJPEijiYMD(
												CommonModule.cnvStr(detaiMap.get("KYK_KKN_STA"))));
		// �_��Ώۊ��ԁi���j�N����
		detailData.put("FKSR002_1_033" , CommonModule.formatJPEijiYMD(
												CommonModule.cnvStr(detaiMap.get("KYK_KKN_END"))));
		// �x������
		detailData.put("FKSR002_1_034" , CommonModule.getKbn(dao, Constants.UKB_SKI_CD,
												CommonModule.cnvStr(detaiMap.get("SHR_SKI_KBN"))));
		// �x�����
		detailData.put("FKSR002_1_035" , CommonModule.cnvStr(
												CommonModule.getKbn(dao, Constants.SHR_SBT,
														CommonModule.cnvStr(detaiMap.get("SHR_SBT")))));
		// �x������Ȗ�
		detailData.put("FKSR002_1_036" , insertHyphen(CommonModule.cnvStr(detaiMap.get("SHR_KANJ_KMK_CD"))));
		// ���v��p�����ӏ�
		detailData.put("FKSR002_1_037" , CommonModule.cnvStr(detaiMap.get("SEK_HIY_HSE_KSH_NAME")));
		// �~�����
		detailData.put("FKSR002_1_038" , CommonModule.cnvStr(
												CommonModule.getKbn(dao, Constants.SKK_FLG,
														CommonModule.cnvStr(detaiMap.get("SKK_KBN")))));
		// �~�����z
		detailData.put("FKSR002_1_039" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(detaiMap.get("SKK"))), DECIMAL_FORMAT_2));
		// �~������Ȗ�
		detailData.put("FKSR002_1_040" , insertHyphen(CommonModule.cnvStr(detaiMap.get("SKK_SHR_KMK"))));
		// �~�����v�Z���^
		detailData.put("FKSR002_1_041" , CommonModule.cnvStr(detaiMap.get("REK_CTR_NAME")));

		String kykshNo = CommonModule.cnvStr(detaiMap.get("REK_CTR_NAME"));
		// �a�����
		detailData.put("FKSR002_1_042" , CommonModule.getKykknInfMap(kykshNo).get("YKIN_SBT"));
		// �����ԍ�
		detailData.put("FKSR002_1_043" , CommonModule.getKykknInfMap(kykshNo).get("KOZ_NO"));
		// �U������Z�@��
		detailData.put("FKSR002_1_044" , CommonModule.getKykknInfMap(kykshNo).get("FURI_KYKKN"));
		// �������`�l
		detailData.put("FKSR002_1_045" , CommonModule.getKykknInfMap(kykshNo).get("KOZ_MEGNIN"));

		// �����L�敪
		if (dMap2.size() > 1) {
			detailData.put("FKSR002_1_046"	, "***");
		} else {
			detailData.put("FKSR002_1_046"	, Constants.EMPTY);
		}
		// ��v�L���N����
		detailData.put("FKSR002_1_047" , CommonModule.formatJPEijiYMD(
													CommonModule.cnvStr(dMap2.get(0).get("KAIKE_KICHO_DATE"))));
		// ���L�����i���q�j
		detailData.put("FKSR002_1_048" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(detaiMap.get("KYYU_MCBN_BUNS"))), DECIMAL_FORMAT_3));
		// ���L�����i����j
		detailData.put("FKSR002_1_049" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(detaiMap.get("KYYU_MCBN_BUIB"))), DECIMAL_FORMAT_3));
		// �_�񑊎��_�X�֔ԍ���3��
		detailData.put("FKSR002_1_050" , CommonModule.cnvStr(detaiMap.get("KYKSH_ADD_YUB_NO_UP_3")));
		// �_�񑊎��_�X�֔ԍ���4��
		detailData.put("FKSR002_1_051" , CommonModule.cnvStr(detaiMap.get("KYKSH_ADD_YUB_NO_DWN_4")));
		// �_�񑊎��_�Z��1
		detailData.put("FKSR002_1_052" , subStringItem(
												CommonModule.cnvStr(detaiMap.get("KYKSH_TDFK_NAME")), false));
		// �_�񑊎��_�Z��2
		detailData.put("FKSR002_1_053" , subStringItem(
												CommonModule.cnvStr(detaiMap.get("KYKSH_TDFK_NAME")), true));
		// �_�񑊎��_�Z��3
		detailData.put("FKSR002_1_054" , CommonModule.cnvStr(detaiMap.get("KYKSH_OOA_TSH_NAME")));
		// �_�񑊎��_�Z��4
		detailData.put("FKSR002_1_055" , CommonModule.cnvStr(detaiMap.get("KYKSH_ACM")));
		// �_�񑊎��_�Z��5
		detailData.put("FKSR002_1_056" , CommonModule.cnvStr(detaiMap.get("KYKSH_CBN")));
		// �_�񑊎��_����
		detailData.put("FKSR002_1_057" , CommonModule.cnvStr(detaiMap.get("KYKSH_NAME")));
		// �_�񑊎��_�d�b�ԍ�
		detailData.put("FKSR002_1_058" , CommonModule.cnvStr(detaiMap.get("KYKSH_TEL_NO")));

		// ���x���z
		if ("0".equals(CommonModule.cnvStr(detaiMap.get("SNH_KBN")))) {
			detailData.put("FKSR002_1_063"	, "�i�����j");
		} else {
			detailData.put("FKSR002_1_063"	, Constants.EMPTY);
		}

		return detailData;
	}

	/**
	 * FKSR002_SELECT_002 detail data.
	 * @param dao 	CommonDAO
	 * @param dMap 	�d���Ǘ����
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getSecondDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		// ��v�L���N����
		detailData.put("FKSR002_1_047", CommonModule.formatJPEijiYMD(
										CommonModule.cnvStr(dMap.get(0).get("KAIKE_KICHO_DATE"))));

		return detailData;
	}

	/**
	 * FKSR002_SELECT_003 detail data.
	 * @param dao 	CommonDAO
	 * @param dMap 	�d���Ǘ����
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getThirdDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		// ���떾��_���댴��
		detailData.put("FKSR002_1_059" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(dMap.get(0).get("CHOB_GENK"))), DECIMAL_FORMAT_4));
		// ���떾��_���S���z
		detailData.put("FKSR002_1_060" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(dMap.get(0).get("FUTKIN"))), DECIMAL_FORMAT_4));
		// ���떾��_���������݌v�z
		detailData.put("FKSR002_1_061" , CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(dMap.get(0).get("GENS_SONS"))), DECIMAL_FORMAT_4));

		return detailData;
	}

	/**
	 * Init for FKSR002_SELECT_004 detail data.
	 * Edit for 101-124
	 * @param listSize 	Maximum record
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> initFourDetailData(int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 101;
		for (int count = 0; count < listSize; count++) {
			// �i��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �x������Ȗ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ��ڕ�WBS�v�f
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ��ڕ�WBS����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ؒn���i����x���z�j
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// BU�敪
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// BU�敪����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ŋ��敪
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
		}

		return detailData;
	}


	/**
	 * FKSR002_SELECT_004 detail data.
	 * Edit for 101-124
	 * @param dao 	CommonDAO
	 * @param dMap 	�d���Ǘ����
	 * @param listSize 	Total record get from SQL4
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFourDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap,
											  int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		// ���x���z
		detailData.put("FKSR002_1_062", CommonModule.decimalFormat(
											new BigDecimal(
													CommonModule.cnvStr(dMap.get(0).get("PAY_PRC"))), DECIMAL_FORMAT_4));

		int itemId = 101;
		for (int count = 0; count < listSize; count++) {
			// �i��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.SEBJKY_CD,
																				CommonModule.cnvStr(dMap.get(count).get("HMK_KBN")))));
			// �x������Ȗ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("SHR_KANJ_KMK_CD")));
			// ��ڕ�WBS�v�f
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("HMK_WBS_YOS")));
			// ��ڕ�WBS����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("SHR_KMK_HMK_WBS_NAME")));
			// �ؒn���i����x���z�j
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(CommonModule.cnvStr(dMap.get(count).get("SHR_KIN"))));
			// BU�敪
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("BU_KBN")));
			// BU�敪����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("BU_KBN_NAME")));
			// �ŋ��敪
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("ZEI_KBN")));
		}

		return detailData;
	}

	/**
	 * Init for FKSR002_SELECT_005 detail data.
	 * Edit for 201-280
	 * @param listSize 	Total record get from SQL5
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> initFiveDetailData(int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 201;
		for (int count = 0; count < listSize; count++) {

			// �����ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �S���ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��1
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��2
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��3
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��4
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��5
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ���H��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �d�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �͈�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �n�E��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �n�E��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �y�n���i
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �⏞�Ή�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ʐό���
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ݒ�ʐ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
		}

		return detailData;
	}

	/**
	 * FKSR002_SELECT_005 detail data.
	 * Edit for 201-280
	 * @param dao 	CommonDAO
	 * @param dMap 	�d���Ǘ����
	 * @param listSize 	Total record get from SQL5
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFiveDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap,
											  int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 201;
		for (int count = 0; count < listSize; count++) {

			// �����ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(dMap.get(count).get("BKN_NO")));
			// �S���ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
					CommonModule.cnvStr(dMap.get(count).get("TET_NO_NO")) + "-" + CommonModule.cnvStr(dMap.get(count).get("TET_NO_DNO")));
			// �Z��1
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									subStringItem(CommonModule.cnvStr(dMap.get(count).get("TDFK_NAME")), false));
			// �Z��2
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									subStringItem(CommonModule.cnvStr(dMap.get(count).get("TDFK_NAME")), true));
			// �Z��3
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									CommonModule.cnvStr(dMap.get(count).get("OOA_TSH_NAME")));
			// �Z��4
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									CommonModule.cnvStr(dMap.get(count).get("BKN_ACM")));
			// �Z��5
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									CommonModule.cnvStr(dMap.get(count).get("BKN_CBN")));
			// ���H��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
									CommonModule.getSnrName(dao, CommonModule.cnvStr(dMap.get(count).get("DNC_NO_1"))));
			// �d�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.DNC_SBT,
																						CommonModule.cnvStr(dMap.get(count).get("DNC_SBT")))));
			// �͈�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.SHKT_HAI_KBN,
																				CommonModule.cnvStr(dMap.get(count).get("SHKT_HAI_KBN")))));
			// �n�E��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.CMK_CD,
																				CommonModule.cnvStr(dMap.get(count).get("CMK_KOB_KBN")))));
			// �n�E��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.CMK_CD,
																				CommonModule.cnvStr(dMap.get(count).get("CMK_GEK_KBN")))));
			// �y�n���i
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
											CommonModule.cnvStr(dMap.get(count).get("TCH_KIN")));
			// �⏞�Ή�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
											CommonModule.cnvStr(dMap.get(count).get("HSH_TKA")));
			// �ʐό���
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
											CommonModule.cnvStr(dMap.get(count).get("MES_KOB")));
			// �ݒ�ʐ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
											CommonModule.cnvStr(dMap.get(count).get("STE_MES")));
		}

		return detailData;
	}

	/**
	 * Init for FKSR002_SELECT_006 detail data.
	 * Edit for 301-325
	 * @param listSize 	Total record get from SQL6
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> initSixDetailData(int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 301;
		for (int count = 0; count < listSize; count++) {
			// �ٓ�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ٓ����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ٓ��N����..
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ���菑�ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ����N����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
		}

		return detailData;
	}

	/**
	 * FKSR002_SELECT_006 detail data.
	 * Edit for 301-325
	 * @param dao 	CommonDAO
	 * @param dMap 	�d���Ǘ����
	 * @param listSize 	Total record get from SQL6
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getSixDetailData(CommonDAO dao,
											  List<Map<String, Object>> dMap,
											  int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 301;
		for (int count = 0; count < listSize; count++) {
			// �ٓ�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(count + 1));
			// �ٓ����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(
																		CommonModule.getKbn(dao, Constants.IDO_SBT,
																				CommonModule.cnvStr(dMap.get(count).get("KRUK_IDO_SBT")))));
			// �ٓ��N����..
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(
																CommonModule.cnvStr(dMap.get(count).get("IDO_DATE"))));
			// ���菑�ԍ�
			detailData.put("FKSR002_1_" + String.valueOf(itemId++),
																CommonModule.cnvStr(dMap.get(count).get("IDO_KKTS_NO")));
			// ����N����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(
																CommonModule.cnvStr(dMap.get(count).get("IDO_KIT_DATE"))));
		}

		return detailData;
	}

	/**
	 * Init for FKSR002_SELECT_007 detail data.
	 * Edit for 401-415
	 * @param listSize 	Total record get from SQL7
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> initSevenDetailData(int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 401;
		for (int count = 0; count < listSize; count++) {

			// �ٓ�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ٓ��N����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
			// ���l��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), Constants.EMPTY);
		}

		return detailData;
	}

	/**
	 * FKSR002_SELECT_007 detail data.
	 * Edit for 401-415
	 * @param dao	CommonDAO
	 * @param dMap 	�d���Ǘ����
	 * @param listSize 	Total record get from SQL7
 	 * @return �d���Ǘ����ו\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getSevenDetailData(CommonDAO dao,
											       List<Map<String, Object>> dMap,
											       int listSize) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 401;
		for (int count = 0; count < listSize; count++) {

			// �ٓ�����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), String.valueOf(count + 1));
			// �ٓ��N����
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.formatJPEijiYMD(
																		CommonModule.cnvStr(dMap.get(count).get("IDO_DATE"))));
			// ���l��
			detailData.put("FKSR002_1_" + String.valueOf(itemId++), CommonModule.cnvStr(dMap.get(count).get("BKO")));
		}

		return detailData;
	}

	/**
	 * Init for report two.
	 * @param startIndex Start position to get data
	 * @param endIndex   End position to get data
 	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> initForReportTwo(int startIndex,
										         int endIndex) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 101;
		for (int count = startIndex; count < endIndex; count++) {
			// �����ԍ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �S���ԍ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��1
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��2
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��3
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��4
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �Z��5
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// ���H��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �d�����
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �͈�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �n�E��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �n�E��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �y�n���i
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �⏞�Ή�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ʐό���
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
			// �ݒ�ʐ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), Constants.EMPTY);
		}

		return detailData;
	}

	/**
	 * Edit for report two.
	 * @param dao CommonDAO
	 * @param dMap Result of FKSR002_SELECT_005
	 * @param startIndex Start position to get data
	 * @param endIndex   End position to get data
 	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> editForReportTwo(CommonDAO dao,
										         List<Map<String, Object>> dMap,
										         int startIndex,
										         int endIndex) throws Exception {
		Map<String, Object> detailData = new HashMap<String, Object>();

		int itemId = 101;
		for (int count = startIndex; count < endIndex; count++) {
			// �����ԍ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("BKN_NO")));
			// �S���ԍ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("TET_NO_NO"))
														+ "-" + CommonModule.cnvStr(dMap.get(count).get("TET_NO_DNO")));
			// �Z��1
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("TDFK_NAME")));
			// �Z��2
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("TDFK_NAME")));
			// �Z��3
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("OOA_TSH_NAME")));
			// �Z��4
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("BKN_ACM")));
			// �Z��5
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
												CommonModule.cnvStr(dMap.get(count).get("BKN_CBN")));
			// ���H��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(
																CommonModule.getSnrName(dao,
																		CommonModule.cnvStr(dMap.get(count).get("DNC_NO_1")))));
			// �d�����
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(
																	CommonModule.getKbn(dao, Constants.DNC_SBT,
																			CommonModule.cnvStr(dMap.get(count).get("DNC_SBT")))));
			// �͈�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(
																CommonModule.getKbn(dao, Constants.SHKT_HAI_KBN,
																		CommonModule.cnvStr(dMap.get(count).get("SHKT_HAI_KBN")))));
			// �n�E��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(
																CommonModule.getKbn(dao, Constants.SHKT_HAI_KBN,
																		CommonModule.cnvStr(dMap.get(count).get("CMK_KOB_KBN")))));
			// �n�E��
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(
																CommonModule.getKbn(dao, Constants.CMK_CD,
																		CommonModule.cnvStr(dMap.get(count).get("CMK_GEK_KBN")))));
			// �y�n���i
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(dMap.get(count).get("TCH_KIN")));
			// �⏞�Ή�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++), dMap.get(count).get("HSH_TKA"));
			// �ʐό���
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(dMap.get(count).get("MES_KOB")));
			// �ݒ�ʐ�
			detailData.put("FKSR002_2_" + String.valueOf(itemId++),
															CommonModule.cnvStr(dMap.get(count).get("STE_MES")));
		}

		return detailData;
	}

	/**
	 * �t�b�^�\�����e���擾���܂��B.
	 * @param fList Result of FKSR002_SELECT_001
	 * @param isFirstPage If current page is first page -> true
 	 * @return �t�b�^�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getFooterData(List<Map<String, Object>> fList, boolean isFirstPage) throws Exception {
		Map<String, Object> footerData = new HashMap<String, Object>();
		Map<String, Object> fMap = fList.get(0);

		// Item Id
		String itemId = Constants.EMPTY;
		if (!isFirstPage) {
			itemId = "2";
		} else {
			itemId = "1";
		}

		// ��Ж�
		footerData.put("FKSR002_" + itemId + "_501" , CommonModule.cnvStr(fMap.get("CMPY_NAME")));

		return fMap;
	}

	/**
	 * �t�@�C��ID���쐬���܂��B.
	 * @param kkshCd �䒠�Ǘ��ӏ��R�[�h
	 * @return �t�@�C��ID
	 */
	private String getFileID(String kkshCd) {
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());
		String fileId = REPORT_ID + "_" + timeStr + "_" + kkshCd;
		return fileId;
	}

	/**
	 * SubString item.
 	 * @param item Item get from Database (Convert to string)
	 * @param lengthFlg Using to distinguish length of string after sub
	 * @return �t�@�C��ID
	 */
	private String subStringItem(String item, Boolean lengthFlg) {
		if (item.length() >= 4) {
			if (lengthFlg) {
				return item.substring(4);
			} else {
				return item.substring(0, 4);
			}
		}
		return Constants.EMPTY;
	}

	/**
	 * Insert hyphen.
 	 * @param item Item get from Database (Convert to string)
	 * @return item after insert hyphen
	 */
	private String insertHyphen(String item) {

		StringBuffer result = new StringBuffer();
		if (item.length() == 10) {
			result.append(item.substring(0, 3));
			result.append(Constants.HYPHEN);
			result.append(item.substring(3, 4));
			result.append(Constants.HYPHEN);
			result.append(item.substring(4, 6));
			result.append(Constants.HYPHEN);
			result.append(item.substring(6, 8));
			result.append(Constants.HYPHEN);
			result.append(item.substring(8, 10));
		} else {
			return Constants.EMPTY;
		}

		return result.toString();
	}
}

