/**
 * FKSR008.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSR;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.enecom.framework.config.SystemConfiguration;
import jp.co.enecom.framework.constants.FrameworkConstants;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �ЗL�䒠���[�쐬�p�N���X�ł��B.
 * Ver.00.00.00 2018/3/22 : Y.Tani - Original
 */
public class FKSR008 {

	 /** ���[ID�i���n�����Ώۓy�n�ꗗ�\�j. */
	public static final String REPORT_ID = "FKSR008";

	/** �ЗL�ԍ�.*/
	public static final String COMPANY_NUMBER = "FKSR008";
	/** �R���X�g���N�^. */
	public FKSR008() { };


	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @param param ���[�쐬�p�����[�^
	 * @return �_�E�����[�h���
	 * @throws Exception ��O
	 */
	public Map<String, String> makePintFile(CommonDAO dao, Map<String, Object>param) throws Exception {

		// �ЗL�ԍ�
		String  formInfo = param.get("COMPANY_NUMBER").toString();

		List<Map<String, Object>> list001 = dao.getQueryResult(param, "FKSR008_SELECT_001", CommonDAO.PRINT_SQL);
		List<Map<String, Object>> list002 = dao.getQueryResult(param, "FKSR008_SELECT_002", CommonDAO.PRINT_SQL);

		List<Map<String, Object>> listParams = new ArrayList<Map<String, Object>>();

		if (formInfo.equals(COMPANY_NUMBER)) {
			for (int i = 0; i < list001.size(); i++) {
				Map<String, Object> beanParam = new HashMap<String, Object>();
				beanParam.putAll(getHeaderData(list001, i));
				beanParam.put("FKSR008_003", Constants.EMPTY);
				beanParam.put("FKSR008_004", list002.get(0).get("SYU_NO"));
				String str = (list002.get(i).get("SYU_TCH_HOSHI")).toString();
				String strsyu = "";
				for (int j = 0; j < str.length(); j++ ) {
					if ((j > 0) && (j % 30 == 0)) {
						strsyu += "\r\n" + str.charAt(j);
					} else {
						strsyu += str.charAt(j);
					}
				}
				beanParam.put("FKSR008_005" , strsyu);
				beanParam.putAll(getDetailData(list001, i));
				listParams.add(beanParam);
			}
		} else {
			for (int i = 0; i < list002.size(); i++) {
				Map<String, Object> beanParam = new HashMap<String, Object>();
				beanParam.putAll(getHeaderData(list002, i));
				beanParam.put("FKSR008_004", Constants.EMPTY);
				beanParam.put("FKSR008_003", list002.get(0).get("KYK_NO"));
				String str = (list002.get(i).get("HOSHI")).toString();
				String strsyu = "";
				for (int j = 0; j < str.length(); j++ ) {
					if ((j > 0) && (j % 30 == 0)) {
						strsyu += "\r\n" + str.charAt(j);
					} else {
						strsyu += str.charAt(j);
					}
				}
				beanParam.put("FKSR008_005" , strsyu);
				beanParam.putAll(getDetailData(list002, i));
				listParams.add(beanParam);
			}
		}

		// �o�͐�t�@�C�����w�肷��B
		String exportTempFolder = SystemConfiguration.get(FrameworkConstants.EXPORT_TEMPORARY_FOLDER);
		String outFile = CommonModule.getRealPath(exportTempFolder + File.separator + getFileID());

		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = CommonModule.getTemplateFileName(Constants.TEMPLATE_MAP.get(REPORT_ID));

		// �o�̓t�@�C��������ɍ쐬�ł��Ă��邱�ƁB
		JasperPrint jasper = JasperFillManager.fillReport(templateFileName, new HashMap<String, Object>(), new JRBeanCollectionDataSource(listParams));

		// ����C���[�W��PDF�t�@�C���ɏo�͂���B
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		// �ԋp�l�ݒ�
		Map<String, String> fileInfo = new HashMap<String, String>();
		fileInfo.put(Constants.DOWNLOAD_PATH_KEY, outFile + ".pdf");
		fileInfo.put(Constants.DOWNLOAD_NAME_KEY, getFileID() + ".pdf");
		return fileInfo;
	}

	/**
	 * �w�b�_�\�����e���擾���܂��B.
	 * @param syuList �ЗL�䒠���
	 * @param lineNum lineNum
	 * @return �w�b�_�\�����e
	 * @throws Exception ��O
	 */
	private Map<String, Object> getHeaderData(List<Map<String, Object>> syuList, int lineNum) throws Exception {
		Map<String, Object> headerMap = new HashMap<String, Object>();
		Map<String, Object> sfskMap = syuList.get(lineNum);
		headerMap.put("FKSR008_001"	,  CommonModule.formatYMD((new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD)).format(new Date())));
		headerMap.put("FKSR008_002"	, sfskMap.get("BKN_NO"));
		return headerMap;
	}

	/**
	 * �d���Ǘ����ו\�����e���擾���܂��B.
	 * @param syuList �ЗL�䒠���
	 * @param lineNum lineNum
	 * @return �d���Ǘ����ו\�����e���擾���܂��B.
	 * @throws Exception ��O
	 */
	private Map<String, Object> getDetailData(List<Map<String, Object>> syuList, int lineNum) throws Exception {
		Map<String, Object> detailChfkKnrData = new HashMap<String, Object>();
		detailChfkKnrData.put("FKSR008_006" , syuList.get(lineNum).get("CMPY_NAME"));
		return detailChfkKnrData;
	}

	/**
	 *
	 * @return �t�@�C��ID
	 */
	private String getFileID() {
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());
		String fileId = REPORT_ID + "_" + timeStr;
		return fileId;
	}

}

