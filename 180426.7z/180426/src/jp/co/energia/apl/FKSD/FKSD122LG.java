/**
 * FKSD122.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSD;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import jp.co.enecom.framework.constants.FrameworkConstants;
import jp.co.enecom.framework.session.EcSession;
import jp.co.enecom.framework.template.print.AbstractEasyPrintLGManagedBean;
import jp.co.energia.apl.FKSR.FKSR001;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;

/**
 * ������䒠�쐬�Ɩ�-�䒠������\��_�ЗL�䒠��ʂ̃r�W�l�X���W�b�N�N���X�ł��B.
 * <p>
 * Ver.00.00.00 2018/2/20 : EC-tani - Original
 */
public class FKSD122LG extends AbstractEasyPrintLGManagedBean {

	/** �Ȗ�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KMK 			= "37";
	/** �������_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KNRI_SBT 		= "42";
	/** �p�r_�敪��ʃR�[�h. */
	private static final String KBN_SBT_YOT 			= "45";
	/** �n��_�敪��ʃR�[�h. */
	private static final String KBN_SBT_CMK	 			= "41";
	/** ���F�Ώ�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KNNK_TSH 		= "02";
	/** ���F���_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KNNK_SBT 		= "03";
	/** �ЗL�n����_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SYU_KENCH 		= "04";
	/** �d�����_�敪��ʃR�[�h. */
	private static final String KBN_SBT_DNC_SBT 		= "05";
	/** �ݔ��Ȗ�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SETB_KMK 		= "130";
	/** �s�s�v��p�r_�敪��ʃR�[�h. */
	private static final String KBN_SBT_TSK_YOT 		= "52";
	/** ���o�L���R_�敪��ʃR�[�h. */
	private static final String KBN_SBT_MTKIT_RYU 		= "51";
	/** �擾���R_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SHK_JIY 		= "44";
	/** ������_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SIB 			= "53";
	/** �Œ莑�Y�œ���敪_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KTSS_ZEI_TOKR 	= "60";
	/** �����n_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KKCH 			= "50";
	/** �V�x�w��y�n_�敪��ʃR�[�h. */
	private static final String KBN_SBT_YKYU_STE_TCH	= "48";
	/** �����Z��@_�敪��ʃR�[�h. */
	private static final String KBN_SBT_JK_SNTH 		= "07";
	/** �v��n_�L. */
	private static final String YEK_ARI					= "�L";
	/** �_�E�����[�h�t���O_1. */
	private static final String DOWNLOAD_FLG_ON 		= "1";
	/**
	 * �����\�����̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	@Override
	public String init() throws Exception {
		//��ʊԈ��p�����ڎ擾
		@SuppressWarnings("unchecked")
		Map<String, Object> fksd116 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD116");

		CommonDAO dao = (CommonDAO) getDao();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("BKN_NO_W01", fksd116.get("LBL_BKN_NO_01"));
		param.put("SYU_NO_W01", fksd116.get("LBL_SYU_NO_01"));
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		list = dao.getQueryResult(param, "FKSD122_SELECT_001", CommonDAO.BUSINESS_SQL);

		param.clear();
		param.put("SYU_NO_W01", list.get(0).get("SYU_NO"));
		param.put("BKN_NO_W01", list.get(0).get("BKN_NO"));
		param.put("SSN_NO_W01", list.get(0).get("SSN_NO"));
		List<Map<String, Object>> bokList = new ArrayList<Map<String, Object>>();
		bokList = dao.getQueryResult(param, "FKSD122_SELECT_002", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> zmnList = new ArrayList<Map<String, Object>>();
		zmnList = dao.getQueryResult(param, "FKSD122_SELECT_003", CommonDAO.BUSINESS_SQL);

		param.put("SYU_NO_W02", list.get(0).get("SYU_NO"));
		List<Map<String, Object>> bkoList = new ArrayList<Map<String, Object>>();
		bkoList = dao.getQueryResult(param, "FKSD122_SELECT_004", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> yechCntList = new ArrayList<Map<String, Object>>();
		yechCntList = dao.getQueryResult(param, "FKSD122_SELECT_005", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> dncList = new ArrayList<Map<String, Object>>();
		dncList = dao.getQueryResult(param, "FKSD122_SELECT_006", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> zeiList = new ArrayList<Map<String, Object>>();
		zeiList = dao.getQueryResult(param, "FKSD122_SELECT_007", CommonDAO.BUSINESS_SQL);

		//��ʍ��e�[�u���ݒ�
		getForm().put("LBL_SYU_NO_00"					, list.get(0).get("SYU_NO"));
		getForm().put("LBL_BKN_NO_00"					, list.get(0).get("BKN_NO"));
		getForm().put("LBL_SHK_DATE_00"					, list.get(0).get("SHK_DATE"));
		getForm().put("LBL_DAI_KKSH_CD_00"				, list.get(0).get("DAI_KKSH_CD"));
		getForm().put("LBL_DAI_KKSH_NAME_01"			, list.get(0).get("DAI_KKSH_NAME"));
		getForm().put("LBL_GNB_KKSH_CD_00"				, list.get(0).get("GNB_KKSH_CD"));
		getForm().put("LBL_GNB_KKSH_NAME_01"			, list.get(0).get("GNB_KKSH_NAME"));
		getForm().put("LBL_JUT_KKSH_CD_00"				, list.get(0).get("JUT_KKSH_CD"));
		getForm().put("LBL_JUT_KKSH_NAME_01"			, list.get(0).get("JUT_KKSH_NAME"));
		getForm().put("LBL_KMK_NAME_00"					, CommonModule.getKbn(dao, KBN_SBT_KMK, ((String) list.get(0).get("KMK_CD"))));
		getForm().put("LBL_KNRI_SBT_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_KNRI_SBT, ((String) list.get(0).get("KNRI_SBT"))));
		getForm().put("LBL_YOT_NAME_00"					, CommonModule.getKbn(dao, KBN_SBT_YOT, ((String) list.get(0).get("YOT_CD"))));
		getForm().put("LBL_GENK_CTR_CD_00"				, list.get(0).get("GENK_CTR_CD"));
		getForm().put("LBL_GENK_CTR_NAME_01"			, list.get(0).get("GENK_CTR_NAME"));
		getForm().put("LBL_WBS_YOS_00"					, list.get(0).get("WBS_YOS"));
		getForm().put("LBL_WBS_NAME_01"					, list.get(0).get("WBS_NAME"));
		getForm().put("LBL_KAN_CD_00"					, list.get(0).get("KAN_CD"));
		getForm().put("LBL_KAN_NAME_01"					, list.get(0).get("KAN_NAME"));
		getForm().put("LBL_KKK_CD_00"					, list.get(0).get("KKK_CD"));
		getForm().put("LBL_TET_NO_NO_00"				, (String) list.get(0).get("TET_NO_NO") + "-" + (String) list.get(0).get("TET_NO_DNO"));
		getForm().put("LBL_KKT_CD_00"					, list.get(0).get("KKT_CD"));
		getForm().put("LBL_KKT_NAME_01"					, list.get(0).get("KKT_NAME"));
		getForm().put("LBL_RIT_KIT_NO_00"				, list.get(0).get("RIT_KIT_NO"));
		getForm().put("LBL_RIT_KIT_DATE_00"				, list.get(0).get("RIT_KIT_DATE"));
		getForm().put("LBL_SZC_TDFK_CD_00"				, list.get(0).get("TDFK_CD"));
		getForm().put("LBL_SZC_TDFK_NAME_01"			, list.get(0).get("TDFK_NAME"));
		getForm().put("LBL_SZC_OOA_TSH_CD_00"			, list.get(0).get("BKN_OOA_TSH_CD"));
		getForm().put("LBL_SZC_OOA_TSH_NAME_01"			, list.get(0).get("OOA_TSH_NAME"));
		getForm().put("LBL_SZC_ACM_00"					, list.get(0).get("BKN_ACM"));
		getForm().put("LBL_SZC_CBN_00"					, list.get(0).get("BKN_CBN"));
		getForm().put("LBL_CMK_KOB_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_CMK, ((String) list.get(0).get("CMK_KOB_KBN"))));
		getForm().put("LBL_CMK_GEK_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_CMK, ((String) list.get(0).get("CMK_GEK_KBN"))));
		getForm().put("LBL_MES_KOB_00"					, list.get(0).get("MES_KOB"));
		getForm().put("LBL_MES_JOSSK_00"				, list.get(0).get("MES_JOSSK"));
		getForm().put("LBL_KNNK_TSH_KBN_00"				, list.get(0).get("KNNK_TSH_KBN"));
		getForm().put("LBL_KNNK_TSH_KBN_NAME_01"		, CommonModule.getKbn(dao, KBN_SBT_KNNK_TSH, ((String) list.get(0).get("KNNK_TSH_KBN"))));
		getForm().put("LBL_KNNK_SBT_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_KNNK_SBT, ((String) list.get(0).get("KNNK_SBT"))));
		getForm().put("LBL_KYKA_NO_00"					, list.get(0).get("KYKA_NO"));
		getForm().put("LBL_KYKA_KKN_ST_00"				, list.get(0).get("NNK_KKN_ST"));
		getForm().put("LBL_KYKA_KKN_EN_00"				, list.get(0).get("NNK_KKN_EN"));
		getForm().put("LBL_SYU_KENCH_KBN_00"			, list.get(0).get("SYU_KENCH_KBN"));
		getForm().put("LBL_SYU_KENCH_KBN_NAME_01"		, CommonModule.getKbn(dao, KBN_SBT_SYU_KENCH, (String) list.get(0).get("SYU_KENCH_KBN")));

		List<Map<String, Object>> tblTBL1RowList = new ArrayList<Map<String, Object>>();
		DataModel<List<Map<String, Object>>> tableData = new ListDataModel<List<Map<String, Object>>>();

		//�d�����ݒ�
		for (Map<String, Object> dncListRow : dncList) {
			Map<String, Object> tableMap = new HashMap<String, Object>();

			tableMap.put("LBL_DNC_SBT_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_DNC_SBT, ((String) dncListRow.get("DNC_SBT"))));
			tableMap.put("LBL_DNC_SU_00"					, dncListRow.get("DNC_SU"));
			tableMap.put("LBL_SETB_KMK_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_SETB_KMK, ((String) dncListRow.get("SETB_KMK_KBN"))));
			tableMap.put("LBL_SCR_DNC_NO_00"				, dncListRow.get("DNC_NO"));

			tblTBL1RowList.add(tableMap);
		}

		tableData.setWrappedData(tblTBL1RowList);
		getForm().put("TBL_TBL1", tableData);

		//��ʍ����e�[�u���ݒ�
		getForm().put("LBL_SSN_NO_00"					, list.get(0).get("SSN_NO"));
		getForm().put("LBL_DHY_KKT_CD_00"				, list.get(0).get("DHY_KKT_CD"));
		getForm().put("LBL_DHY_KKT_NAME_01"				, list.get(0).get("DHY_KKT_NAME"));
		getForm().put("LBL_MES_KOB_01"					, zeiList.get(0).get("ZEI_INF_MES_KOB"));
		getForm().put("LBL_MES_JOSSK_01"				, zeiList.get(0).get("ZEI_INF_MES_CMK"));
		getForm().put("LBL_TSK_YOT_KBN_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_TSK_YOT, ((String) list.get(0).get("TSK_YOT_KBN"))));

		//�v��n�ݒ�
		if (Integer.parseInt(yechCntList.get(0).get("COUNT").toString()) > 0) {
			getForm().put("LBL_YEK_SYU_NO_00"				, YEK_ARI);
		}

		getForm().put("LBL_SHK_KIN_00"					, list.get(0).get("SHK_KIN"));
		if (bokList.size() > 0) {
			getForm().put("LBL_CHOB_GENK_00"				, bokList.get(0).get("CHOB_GENK_ZAN_KIN"));
			getForm().put("LBL_FUTKIN_00"					, bokList.get(0).get("FUTKIN"));
			getForm().put("LBL_GENS_SONS_SUM_KIN_00"		, bokList.get(0).get("GENS_SONS_SUM_KIN"));
			getForm().put("LBL_SHK_KAIKE_KICHO_DATE_00"		, bokList.get(0).get("SHK_KAIKE_KICHO_DATE"));
		}

		//��ʉE�e�[�u���ݒ�
		getForm().put("LBL_OLD_SYSH_TDFK_CD_00"			, list.get(0).get("OLD_SYSH_TDFK_CD"));
		getForm().put("LBL_OLD_SYSH_TDFK_NAME_01"		, list.get(0).get("OLD_SYSH_TDFK_NAME"));
		getForm().put("LBL_OLD_SYSH_OOA_TSH_CD_00"		, list.get(0).get("OLD_SYSH_OOA_TSH_CD"));
		getForm().put("LBL_OLD_SYSH_OOA_TSH_NAME_01"	, list.get(0).get("OLD_SYSH_OOA_TSH_NAME"));
		getForm().put("LBL_OLD_SYSH_ACM_00"				, list.get(0).get("OLD_SYSH_ACM"));
		getForm().put("LBL_OLD_SYSH_CBN_00"				, list.get(0).get("OLD_SYSH_CBN"));
		getForm().put("LBL_OLD_SYSH_NAME_00"			, list.get(0).get("OLD_SYSH_NAME"));
		getForm().put("LBL_SHK_KIN_01"					, list.get(0).get("SHK_KIN"));
		getForm().put("LBL_TKI_DATE_00"					, list.get(0).get("TKI_DATE"));
		getForm().put("LBL_MTKIT_RYU_KBN_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_MTKIT_RYU, ((String) list.get(0).get("MTKIT_RYU_KBN"))));
		getForm().put("LBL_SHK_JIY_KBN_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_SHK_JIY, ((String) list.get(0).get("SHK_JIY_KBN"))));
		getForm().put("LBL_TKSS_KBN_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_SIB, ((String) list.get(0).get("TKSS_KBN"))));
		getForm().put("LBL_KYKS_KBN_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_SIB, ((String) list.get(0).get("KYKS_KBN"))));
		getForm().put("LBL_JOSSK_Z_KBN_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_SIB, ((String) list.get(0).get("JOSSK_Z_KBN"))));
		getForm().put("LBL_TSK_YOT_KBN_NAME_01"			, CommonModule.getKbn(dao, KBN_SBT_TSK_YOT, ((String) list.get(0).get("TSK_YOT_KBN"))));
		getForm().put("LBL_KTSS_ZEI_TOKR_KBN_NAME_00"	, CommonModule.getKbn(dao, KBN_SBT_KTSS_ZEI_TOKR, ((String) list.get(0).get("KTSS_ZEI_TOKR_KBN"))));
		getForm().put("LBL_KYYU_MCBN_BUNS_00"			, list.get(0).get("KYYU_MCBN_BUNS"));
		getForm().put("LBL_KYYU_MCBN_BUIB_00"			, list.get(0).get("KYYU_MCBN_BUIB"));
		getForm().put("LBL_KKCH_KBN_00"					, list.get(0).get("KKCH_KBN"));
		getForm().put("LBL_KKCH_KBN_NAME_01"			, CommonModule.getKbn(dao, KBN_SBT_KKCH, (String) list.get(0).get("KKCH_KBN")));
		getForm().put("LBL_YKYU_STE_TCH_KBN_00"			, list.get(0).get("YKYU_STE_TCH_KBN"));
		getForm().put("LBL_YKYU_STE_TCH_KBN_NAME_01"	, CommonModule.getKbn(dao, KBN_SBT_YKYU_STE_TCH, (String) list.get(0).get("YKYU_STE_TCH_KBN")));
		getForm().put("LBL_YKYU_KNR_NO_00"				, list.get(0).get("YKYU_KNR_NO"));
		getForm().put("LBL_YKYU_STE_TCH_DATE_00"		, list.get(0).get("YKYU_STE_TCH_DATE"));
		getForm().put("LBL_JK_SNTH_KBN_00"				, list.get(0).get("JK_SNTH_KBN"));
		getForm().put("LBL_JK_SNTH_KBN_NAME_01"			, CommonModule.getKbn(dao, KBN_SBT_JK_SNTH, (String) list.get(0).get("JK_SNTH_KBN")));
		getForm().put("LBL_SUITE_JK_00"					, list.get(0).get("SUITE_JK"));
		if (bkoList.size() > 0) {
			getForm().put("LBL_BKO_00"						, bkoList.get(0).get("SYU_TCH_BKO"));
		}
		getForm().put("LBL_SYU_TCH_HOSHI_00"			, list.get(0).get("SYU_TCH_HOSHI"));

		//�}�ʁE�_�񏑃f�[�^�Y�t�ݒ�
		List<Map<String, Object>> tblTBL2RowList = new ArrayList<Map<String, Object>>();
		DataModel<List<Map<String, Object>>> tableLinkData = new ListDataModel<List<Map<String, Object>>>();
		int maxRowNum = 1;
		for (Map<String, Object> zmnListRow : zmnList) {

			Map<String, Object> tableLinkMap = new HashMap<String, Object>();

			tableLinkMap.put("LBL_ZMN_KYKS_DIS_FILE_NAME_00", zmnListRow.get("ZMN_KYKS_DIS_FILE_NAME"));
			tableLinkMap.put("HDN_ZMN_KYKS_DIS_FILE_PASS_00", zmnListRow.get("ZMN_KYKS_PASS"));
			tblTBL2RowList.add(tableLinkMap);

			maxRowNum++;
			if (maxRowNum > 10) {
				break;
			}
		}
		tableLinkData.setWrappedData(tblTBL2RowList);
		getForm().put("TBL_TBL2", tableLinkData);

		return getForward("/xhtml/FKSD122.xhtml");
	}

	/**
	 * �䒠�C���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter() throws Exception {
		Map<String, Object> fksd122 = new HashMap<String, Object>();
		fksd122.put("LBL_SYU_NO_00"	, getForm().get("LBL_SYU_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD122"	, fksd122);
		return getForward("/xhtml/FKSD004.xhtml");
	}

	/**
	 * �䒠����{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String print() throws Exception {
		CommonDAO dao = (CommonDAO) getDao();

		FKSR001 fksr001 = new FKSR001();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("SYU_NO_W01", getForm().get("LBL_SYU_NO_00"));
		Map<String, String> fileInfo = fksr001.makePrintFile(dao, param);

		File file = new File(fileInfo.get(Constants.DOWNLOAD_PATH_KEY));
		exportFile(fileInfo.get(Constants.DOWNLOAD_NAME_KEY), file);

		return getForward("/xhtml/FKSD122.xhtml");
	}

	/**
	 * �뉿����\���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter2() throws Exception {
		//���փ`�F�b�N
		if (isE0007("E0007_SEL_001")) {
			//�G���[���b�Z�[�W�o��
			setErrorMessage("E0007");
			return getForward("/xhtml/FKSD122.xhtml");
		}
		Map<String, Object> fksd122 = new HashMap<String, Object>();
		fksd122.put("LBL_SYU_NO_00"	, getForm().get("LBL_SYU_NO_00"));
		fksd122.put("LBL_BKN_NO_00"	, getForm().get("LBL_BKN_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD122"	, fksd122);
		return getForward("/xhtml/FKSD128.xhtml");
	}

	/**
	 * ���l����\���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter3() throws Exception {
		//���փ`�F�b�N
		if (isE0007("E0007_SEL_002")) {
			//�G���[���b�Z�[�W�o��
			setErrorMessage("E0007");
			return getForward("/xhtml/FKSD122.xhtml");
		}
		Map<String, Object> fksd122 = new HashMap<String, Object>();
		fksd122.put("LBL_SYU_NO_00"	, getForm().get("LBL_SYU_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD122"	, fksd122);
		return getForward("/xhtml/FKSD129.xhtml");
	}

	/**
	 * �⎆���\���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter4() throws Exception {
		//���փ`�F�b�N
		if (isE0007("E0007_SEL_003")) {
			//�G���[���b�Z�[�W�o��
			setErrorMessage("E0007");
			return getForward("/xhtml/FKSD122.xhtml");
		}
		Map<String, Object> fksd122 = new HashMap<String, Object>();
		fksd122.put("LBL_SYU_NO_00"	, getForm().get("LBL_SYU_NO_00"));
		fksd122.put("LBL_BKN_NO_00"	, getForm().get("LBL_BKN_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD122"	, fksd122);
		return getForward("/xhtml/FKSD130.xhtml");
	}

	/**
	 * �Y�t���������N�������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String file_link() throws Exception {

		File file = new File((String) getSelectedRow().get("HDN_ZMN_KYKS_DIS_FILE_PASS_00"));
        exportFile((String) getSelectedRow().get("LBL_ZMN_KYKS_DIS_FILE_NAME_00"), file);

        return getForward("/xhtml/FKSD122.xhtml");
	}

    /**
     * �o�̓t�@�C���̕ۑ��ꏊ��ݒ肵�A�_�E�����[�h�p�̏����\�z���܂��B.
     * @param printName
     *             ���[��
     * @param fileOut
     *             excel�t�@�C��
     * @throws Exception
     *             ��O
     */
    private void exportFile(String printName, File fileOut) throws Exception {
        // �t�@�C���_�E�����[�h�̏����������s���B
        setSession(EcSession.PAGE_SCOPE, FrameworkConstants.REQUEST_ATTRIBUTE_FILE, fileOut.getAbsolutePath());
        setSession(EcSession.PAGE_SCOPE, FrameworkConstants.REQUEST_ATTRIBUTE_FILE_NAME, printName);
        getForm().put("HDN_DOWNLOAD_FLG_00", DOWNLOAD_FLG_ON);
    }


	/**
     * �_�E�����[�h�{�^���������̏������s���܂��B.
     * @return �t�H���[�h��
     * @throws Exception
     *             ��O
     */
    public String download() throws Exception {
        return super.print();
    }

	/**
	 * �߂�{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String back() throws Exception {
		return getForward("/xhtml/FKSD116.xhtml");
	}

	/**
	 * E0007�̑��փ`�F�b�N���s���܂��B.
	 * @param sqlName SQL��
	 * @return ���փ`�F�b�N����
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE0007(String sqlName) throws Exception {
		CommonDAO dao = (CommonDAO) getDao();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("SYU_NO_W01"	, getForm().get("LBL_SYU_NO_00"));
		param.put("BKN_NO_W01"	, getForm().get("LBL_BKN_NO_00"));
		List<Map<String, Object>> countList = new ArrayList<Map<String, Object>>();
		countList = dao.getQueryResult(param, sqlName, CommonDAO.CHECK_SQL);

		if (Integer.parseInt(countList.get(0).get("COUNT").toString()) == 0) {
			return true;
		}
		return false;
	}
}
