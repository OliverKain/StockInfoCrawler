/**
 * FKSD141.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSD;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import jp.co.enecom.framework.jsf.AbstractLGManagedBean;
import jp.co.energia.apl.common.authenticate.PrincipalImpl;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;

/**
 * �}�X�^�����e�Ɩ�_���Ə��}�X�^�̃r�W�l�X���W�b�N�N���X�ł��B.
 * <p>
 * Ver.00.00.00 2018/1/9 : y.kanamori - Original
 */
public class FKSD141LG extends AbstractLGManagedBean {

	/** ���p�X�y�[�X. */
	private static final String HALF_SPACE = " ";

	/** �敪��ʃR�[�h. */
	private static final String KBN_SBT_DAT_YORYO = "109";
	/**
	 * �����\�����̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	@Override
	public String init() throws Exception {
		CommonDAO dao = (CommonDAO) getDao();
		//�f�[�^�e�ʃ��X�g�̐���
		List<SelectItem> dtCpList = new ArrayList<SelectItem>();
		dtCpList = CommonModule.getItemList(dao, KBN_SBT_DAT_YORYO, true);
		//��ʏ��̎擾
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		list = dao.getQueryResult(null, "FKSD141_SELECT_001", CommonDAO.BUSINESS_SQL);

		if (list.size() == 0) {
			getForm().put("HDN_TBL_DSP_FLG_00", "1");
			getPageItemStyle("BTN_ENTRY_00").setDisabled(true);
		} else {
			getForm().put("HDN_TBL_DSP_FLG_00", "0");
		}
		//��ʍ��ڂ̕ҏW
		List<Map<String, Object>> list1 = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();

		DataModel<List<Map<String, Object>>> tableData1 = new ListDataModel<List<Map<String, Object>>>();
		DataModel<List<Map<String, Object>>> tableData2 = new ListDataModel<List<Map<String, Object>>>();

		for (Map<String, Object> resultRow : list) {
			Map<String, Object> tableMap1 = new HashMap<String, Object>();
			Map<String, Object> tableMap2 = new HashMap<String, Object>();
			tableMap1.put("TXT_DAI_KKSH_CD_00"			, CommonModule.trim((String) resultRow.get("JGSH_CD")));
			tableMap1.put("TXT_DAI_KKSH_NAME_00"		, CommonModule.trim((String) resultRow.get("JGSH_NAME")));
			tableMap1.put("SLC_DAT_YORYO_KBN_00"		, resultRow.get("DAT_YORYO_KBN"));
			tableMap1.put("LST_DAT_YORYO_KBN_00"		, dtCpList);
			tableMap1.put("TXT_SHRCHS_DAT_KKSH_CD_00"	, CommonModule.trim((String) resultRow.get("SHRCHS_DAT_KKSH_CD")));
			tableMap2.put("TXT_JGSH_ADD_1_00"			, CommonModule.trim((String) resultRow.get("JGSH_ADD_1")));
			tableMap2.put("TXT_JGSH_ADD_2_01"			, CommonModule.trim((String) resultRow.get("JGSH_ADD_2")));
			tableMap2.put("TXT_JGSH_TEL_NO_00"			, CommonModule.trim((String) resultRow.get("JGSH_TEL_NO")));
			tableMap2.put("TXT_JGSH_BKO_00"				, CommonModule.trim((String) resultRow.get("JGSH_BKO")));
			list1.add(tableMap1);
			list2.add(tableMap2);
		}
		tableData1.setWrappedData(list1);
		tableData2.setWrappedData(list2);
		getForm().put("TBL_TBL1", tableData1);
		getForm().put("TBL_TBL2", tableData2);

		return getForward("/xhtml/FKSD141.xhtml");
	}

	/**
	 * ���Ə��ǉ����̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String soshiki_insert() throws Exception {
		//�e�[�u�������擾
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL1List = (ListDataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL1");
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL2List = (ListDataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL2");
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tableList1 = (List<Map<String, Object>>) tblTBL1List.getWrappedData();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tableList2 = (List<Map<String, Object>>) tblTBL2List.getWrappedData();

		DataModel<List<Map<String, Object>>> tableData1 = new ListDataModel<List<Map<String, Object>>>();
		DataModel<List<Map<String, Object>>> tableData2 = new ListDataModel<List<Map<String, Object>>>();

		CommonDAO dao = (CommonDAO) getDao();

		Map<String, Object> tableMap1 = new HashMap<String, Object>();
		Map<String, Object> tableMap2 = new HashMap<String, Object>();

		List<SelectItem> dtCpList = new ArrayList<SelectItem>();
		dtCpList = CommonModule.getItemList(dao, KBN_SBT_DAT_YORYO, true);

		tableMap1.put("TXT_DAI_KKSH_CD_00"			, "");
		tableMap1.put("TXT_DAI_KKSH_NAME_00"		, "");
		tableMap1.put("SLC_DAT_YORYO_KBN_00"		, "");
		tableMap1.put("LST_DAT_YORYO_KBN_00"		, dtCpList);
		tableMap1.put("TXT_SHRCHS_DAT_KKSH_CD_00"	, "");
		tableMap2.put("TXT_JGSH_ADD_1_00"			, "");
		tableMap2.put("TXT_JGSH_ADD_2_01"			, "");
		tableMap2.put("TXT_JGSH_TEL_NO_00"			, "");
		tableMap2.put("TXT_JGSH_BKO_00"				, "");
		tableList1.add(0, tableMap1);
		tableList2.add(0, tableMap2);

		tableData1.setWrappedData(tableList1);
		tableData2.setWrappedData(tableList2);
		getForm().put("HDN_TBL_DSP_FLG_00", "0");
		getForm().put("TBL_TBL1", tableData1);
		getForm().put("TBL_TBL2", tableData2);

		return getForward("/xhtml/FKSD141.xhtml");
	}

	/**
	 * �폜���̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String soshiki_delete() throws Exception {
		//�e�[�u�������擾
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL1List = (DataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL1");
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL2List = (DataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL2");
		//�e�[�u���f�[�^
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tb1list = (List<Map<String, Object>>) tblTBL1List.getWrappedData();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tb2list = (List<Map<String, Object>>) tblTBL2List.getWrappedData();

		if (tb1list.size() == 1) {
			getForm().put("HDN_TBL_DSP_FLG_00", "1");
		}

		// �폜�Ώۂ̃C���f�b�N�X���擾
		int targetIndex = tblTBL1List.getRowIndex();
		//�폜�Ώۂ̍s���Z�b�V��������폜
		tb1list.remove(targetIndex);
		tb2list.remove(targetIndex);

		//��ʍ��ڂ�ҏW
		DataModel<List<Map<String, Object>>> tableData1 = new ListDataModel<List<Map<String, Object>>>();
		DataModel<List<Map<String, Object>>> tableData2 = new ListDataModel<List<Map<String, Object>>>();
		tableData1.setWrappedData(tb1list);
		tableData2.setWrappedData(tb2list);
		getForm().put("TBL_TBL1", tableData1);
		getForm().put("TBL_TBL2", tableData2);

		return getForward("/xhtml/FKSD141.xhtml");
	}

	/**
	 * �o�^���̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String entry() throws Exception {
		//�e�[�u�������擾
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL1List = (DataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL1");
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL2List = (DataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL2");
		//�e�[�u���f�[�^
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tb1list = (List<Map<String, Object>>) tblTBL1List.getWrappedData();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tb2list = (List<Map<String, Object>>) tblTBL2List.getWrappedData();

		CommonDAO dao = (CommonDAO) getDao();
		dao.executeSQL(null, "FKSD141_DELETE_001", CommonDAO.BUSINESS_SQL);

		// �v�����V�p�������擾����B
		PrincipalImpl principal = (PrincipalImpl) getPrincipal();

		int i = 0;
		for (Map<String, Object> tb1listMap : tb1list) {

			Map<String, Object> param = new HashMap<String, Object>();
			param.put("JGSH_CD"				, tb1listMap.get("TXT_DAI_KKSH_CD_00"));
			param.put("JGSH_NAME"			, tb1listMap.get("TXT_DAI_KKSH_NAME_00"));
			param.put("DAT_YORYO_KBN"			, tb1listMap.get("SLC_DAT_YORYO_KBN_00"));
			param.put("SHRCHS_DAT_KKSH_CD"	, tb1listMap.get("TXT_SHRCHS_DAT_KKSH_CD_00"));
			param.put("JGSH_ADD_1"			, tb2list.get(i).get("TXT_JGSH_ADD_1_00"));
			param.put("JGSH_ADD_2"			, tb2list.get(i).get("TXT_JGSH_ADD_2_01"));
			param.put("JGSH_TEL_NO"			, tb2list.get(i).get("TXT_JGSH_TEL_NO_00"));
			if (CommonModule.trim((String) tb2list.get(i).get("TXT_JGSH_BKO_00")).equals("")) {
				param.put("JGSH_BKO"		, HALF_SPACE);
			} else {
				param.put("JGSH_BKO"		, tb2list.get(i).get("TXT_JGSH_BKO_00"));
			}
			param.put("DHY_SFSK_KBN"		, HALF_SPACE);
			param.put("UPD_USR"				, principal.getUserId());
			param.put("UPD_DATE"			, (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSSSSS)).format(getRequestTime()));
			i++;
			dao.executeSQL(param, "FKSD141_INSERT_001", CommonDAO.BUSINESS_SQL);
		}
		dao.commit();

		return getForward("/xhtml/FKSD001.xhtml");
	}
}
