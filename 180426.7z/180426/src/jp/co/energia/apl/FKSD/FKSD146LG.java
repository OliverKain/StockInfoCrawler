/**
 * FKSD146.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSD;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import jp.co.enecom.framework.session.EcSession;
import jp.co.enecom.framework.template.list.AbstractListLGManagedBean;
import jp.co.enecom.framework.template.list.AbstractListObject;
import jp.co.enecom.framework.template.list.RowNumListObject;
import jp.co.energia.apl.common.authenticate.PrincipalImpl;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;

import org.picketbox.util.StringUtil;

/**
 * �}�X�^�����e�Ɩ�_�ٓ������Ǘ��̃r�W�l�X���W�b�N�N���X�ł��B.
 * <p>
 * Ver.00.00.00 2018/3/5 : y.kanamori - Original
 */
public class FKSD146LG extends AbstractListLGManagedBean {
	/** �\�����׍s��. */
	private static final int MAX_ROW = 100;
	/** �e�[�u���\���L. */
	private static final String TABLE_FLG_ON = "1";
	/** �e�[�u���\����. */
	private static final String TABLE_FLG_OFF = "0";
	/** �ٓ���ʁi�ЗL�j. */
	private static final String IDO_SYU = "125";
	/** �ٓ���ʁi�n���j. */
	private static final String IDO_CECJ = "126";
	/** �ٓ���ʁi�ݕt�j. */
	private static final String IDO_KAS = "128";
	/** �ٓ���ʁi�ؗp�j. */
	private static final String IDO_SYKY = "127";
	/** �ٓ���ʁi��p�j. */
	private static final String IDO_SEY = "129";
	/** �����F0. */
	private static final String ZERO = "0";
	/**
	 * �����\�����̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String init() throws Exception {
		//�����t�H�[����������Ԃɂ���B
		initializeSearch();
		//���׍s���\���ɂ���B
		getForm().put("HDN_TBL_DSP_FLG_00", TABLE_FLG_OFF);
		//�u�o�^�v�C�u���Z�b�g�v�{�^����ی삷��B
		setSession(EcSession.PAGE_SCOPE	, "BTN_DISABLED_MODE"	, Boolean.TRUE);
		return super.init();
	}
	/**
	 * �����{�^���������̏������s���܂��B.
	 * @return true:�G���[�Ȃ�,false:�G���[����
	 * @throws Exception
	 *             ��O
	 */
	public String search() throws Exception {
		String actionName = (String) getSession(EcSession.PAGE_SCOPE, "actionName");
		//�����������Z�b�V�����ɕێ�����B
		Map<String, Object> searchTerms = new HashMap<String, Object>();
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTermsExist = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		//�u�o�^�v�C�u���Z�b�g�v�{�^���������̓Z�b�V�����������������Ƃ���B
		if ("entry".equals(actionName) || "reset".equals(actionName)) {
			searchTerms.put("SLC_LST_SBT_00", searchTermsExist.get("SLC_LST_SBT_00"));
			searchTerms.put("TXT_SYU_NO_00"	, searchTermsExist.get("TXT_SYU_NO_00"));
			searchTerms.put("TXT_KYK_NO_00"	, searchTermsExist.get("TXT_KYK_NO_00"));
			removeSession(EcSession.PAGE_SCOPE, "actionName");
		} else {
			searchTerms.put("SLC_LST_SBT_00", getForm().get("SLC_LST_SBT_00"));
			searchTerms.put("TXT_SYU_NO_00"	, getForm().get("TXT_SYU_NO_00"));
			searchTerms.put("TXT_KYK_NO_00"	, getForm().get("TXT_KYK_NO_00"));
		}
		setSession(EcSession.PAGE_SCOPE	, "FKSD146"	, searchTerms);
		//���׍s��\������B
		getForm().put("HDN_TBL_DSP_FLG_00"	, TABLE_FLG_ON);
		setSession(EcSession.PAGE_SCOPE	, "BTN_DISABLED_MODE", Boolean.FALSE);
		return super.search();
	}
	/**
	 * ���׍s�̏��������s���܂��B.
	 * @return �ꗗ���
	 * @throws Exception
	 *             ��O
	 * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#initList()
	 */
	@Override
	protected AbstractListObject initList() throws Exception {
		// �ꗗ���𐶐�����B
		RowNumListObject rowList = new RowNumListObject("getQueryResult", MAX_ROW, getDao());
		return rowList;
	}
	/**
	 * ����������ݒ肵�܂��B.
	 * @return �ꗗ���
	 * @throws Exception
	 *             ��O
	 * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#initSearchParam()
	 */
	@Override
	protected AbstractListObject initSearchParam() throws Exception {
		// �ꗗ���𐶐�����B
		RowNumListObject list = new RowNumListObject("getQueryResult", MAX_ROW, getDao());
		Map<String, Object> param = new HashMap<String, Object>();
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		param.put("SLC_LST_SBT_W01"	, searchTerms.get("SLC_LST_SBT_00"));
		param.put("SYU_NO_W01"		, searchTerms.get("TXT_SYU_NO_00"));
		param.put("KYK_NO_W01"		, searchTerms.get("TXT_KYK_NO_00"));
		list.setParam(param);
		return list;
	}
	/**
	 * �������s���O�̎��O�`�F�b�N�������s���܂��B.
	 * @return true:�G���[�Ȃ�,false:�G���[����
	 * @throws Exception
	 *             ��O
	 * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#checkBeforeSearch()
	 */
	@Override
	protected boolean checkBeforeSearch() throws Exception {
		CommonDAO dao = (CommonDAO) getDao();
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
		//�䒠��ʁF�ЗL�䒠
		case Constants.SYU_DAI:
			//DAO�N���X��SQL����ݒ�
			dao.setSqlName("FKSD146_SELECT_001_CNT");
			//�����Ώۃf�[�^����ݒ�
			getMaxRownum("getQueryResult");
			//DAO�N���X��SQL�����Đݒ�
			dao.setSqlName("FKSD146_SELECT_001");
			return true;
			//�䒠��ʁF�n�����E�n�㌠�䒠
		case Constants.CECJ_DAI:
			dao.setSqlName("FKSD146_SELECT_002_CNT");
			getMaxRownum("getQueryResult");
			dao.setSqlName("FKSD146_SELECT_002");
			return true;
			//�䒠��ʁF�ݕt�䒠
		case Constants.KAS_DAI:
			dao.setSqlName("FKSD146_SELECT_003_CNT");
			getMaxRownum("getQueryResult");
			dao.setSqlName("FKSD146_SELECT_003");
			return true;
			//�䒠��ʁF�ؗp�䒠
		case Constants.SYKY_DAI:
			dao.setSqlName("FKSD146_SELECT_004_CNT");
			getMaxRownum("getQueryResult");
			dao.setSqlName("FKSD146_SELECT_004");
			return true;
			//�䒠��ʁF��p�䒠
		case Constants.SEY_DAI:
			dao.setSqlName("FKSD146_SELECT_005_CNT");
			getMaxRownum("getQueryResult");
			dao.setSqlName("FKSD146_SELECT_005");
			return true;
		default:
			return false;
		}
	}
	/**
	 * �������ʖ������̏������s���܂��B.
	 * @throws Exception
	 *             ��O
	 * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#doNotFound()
	 */
	@Override
	protected void doNotFound() throws Exception {
		setErrorMessage("E0007");
	}
	/**
	 * �\������f�[�^��ҏW���܂��B.
	 * @param map
	 *            1�y�[�W���̕\���f�[�^
	 * @throws Exception
	 *             ��O
	 * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#editPage(java.util.Map)
	 */
	@Override
	protected void editPage(Map<Integer, Object> map) throws Exception {
		//����������ݒ肷��B
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		if (searchTerms != null) {
			getForm().put("SLC_LST_SBT_00"	, searchTerms.get("SLC_LST_SBT_00"));
			getForm().put("TXT_SYU_NO_00"	, searchTerms.get("TXT_SYU_NO_00"));
			getForm().put("TXT_KYK_NO_00"	, searchTerms.get("TXT_KYK_NO_00"));
			//����������\������B
			getForm().put("LBL_SRCH_RESLT_00"	, getList().getMaxRownum());
		}
		// ���׍s��ҏW����B
		CommonDAO dao = (CommonDAO) getDao();
		DataModel<List<Map<String, Object>>> tableData = new ListDataModel<List<Map<String, Object>>>();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		//�s�ԍ���ݒ肷��B
		int rowNum = 1;
		List<SelectItem> idoSbtList = new ArrayList<SelectItem>();
		for (Map.Entry<Integer, Object>  resultEntry : map.entrySet()) {
			Map<String, Object> tableMap = new HashMap<String, Object>();
			@SuppressWarnings("unchecked")
			Map<String, Object> resultRow = (Map<String, Object>) resultEntry.getValue();
			tableMap.put("LBL_GYO_NO_00"			, rowNum);
			tableMap.put("TXT_IDO_DATE_00"			, resultRow.get("IDO_DATE"));
			switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
			//�䒠��ʁF�ЗL�䒠
			case Constants.SYU_DAI:
				tableMap.put("SLC_IDO_SBT_CD_00"		, resultRow.get("SYU_IDO_SBT"));
				tableMap.put("HDN_SYU_IDO_RRK_RNO_00"	, resultRow.get("SYU_IDO_RRK_RNO"));
				idoSbtList = CommonModule.getItemList(dao, IDO_SYU, true);
				break;
				//�䒠��ʁF�n�����E�n�㌠�䒠
			case Constants.CECJ_DAI:
				tableMap.put("SLC_IDO_SBT_CD_00"		, resultRow.get("CECJ_IDO_SBT"));
				tableMap.put("HDN_CECJ_IDO_RNO_00"		, resultRow.get("CECJ_IDO_RNO"));
				idoSbtList = CommonModule.getItemList(dao, IDO_CECJ, true);
				break;
				//�䒠��ʁF�ݕt�䒠
			case Constants.KAS_DAI:
				tableMap.put("SLC_IDO_SBT_CD_00"		, resultRow.get("KAS_IDO_SBT"));
				tableMap.put("HDN_KAS_IDO_RNO_00"		, resultRow.get("KAS_IDO_RNO"));
				idoSbtList = CommonModule.getItemList(dao, IDO_KAS, true);
				break;
				//�䒠��ʁF�ؗp�䒠
			case Constants.SYKY_DAI:
				tableMap.put("SLC_IDO_SBT_CD_00"		, resultRow.get("KRUK_IDO_SBT"));
				tableMap.put("HDN_KRUK_IDO_RNO_00"		, resultRow.get("KRUK_IDO_RNO"));
				idoSbtList = CommonModule.getItemList(dao, IDO_SYKY, true);
				break;
				//�䒠��ʁF��p�䒠
			case Constants.SEY_DAI:
				tableMap.put("SLC_IDO_SBT_CD_00"		, resultRow.get("SEY_IDO_SBT"));
				tableMap.put("HDN_SEY_IDO_RNO_00"		, resultRow.get("SEY_IDO_RNO"));
				idoSbtList = CommonModule.getItemList(dao, IDO_SEY, true);
				break;
			default:
				break;
			}
			tableMap.put("LST_IDO_SBT_CD_00"		, idoSbtList);
			tableMap.put("TXT_IDO_KIT_DATE_00"		, resultRow.get("IDO_KIT_DATE"));
			tableMap.put("TXT_IDO_KKTS_NO_00"		, resultRow.get("IDO_KKTS_NO"));
			rowNum++;
			list.add(tableMap);
		}
		//��ʍ��ڂ�ҏW����B
		tableData.setWrappedData(list);
		getForm().put("TBL_TBL1", tableData);
	}
	/**
	 * �����폜�{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String delete_terms() throws Exception {
		//�����t�H�[����������Ԃɂ���B
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		if (searchTerms != null) {
			removeSession(EcSession.PAGE_SCOPE, "FKSD146");
		}
		initializeSearch();
		//�u�o�^�v�C�u���Z�b�g�v�{�^����ی삷��B
		setSession(EcSession.PAGE_SCOPE	, "BTN_DISABLED_MODE"	, Boolean.TRUE);
		return getForward("/xhtml/FKSD146.xhtml");
	}
	/**
	 * �o�^�{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String entry() throws Exception {
		//���փ`�F�b�N���s���B
		if (isError()) {
			return getForward("/xhtml/FKSD146.xhtml");
		}
		//��ʏ����擾����B
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL1List = (ListDataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL1");
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tblTBL1Row = (List<Map<String, Object>>) tblTBL1List.getWrappedData();
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		CommonDAO dao = (CommonDAO) getDao();
		//�o�^�ԍ����擾����B
		String tokNo = null;
		switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
			//�䒠��ʁF�ЗL�䒠
		case Constants.SYU_DAI:
			tokNo = CommonModule.getSyuTokNo(dao);
			break;
			//�䒠��ʁF�n�����E�n�㌠�䒠
		case Constants.CECJ_DAI:
			tokNo = CommonModule.getCecjTokNo(dao);
			break;
			//�䒠��ʁF�ݕt�䒠
		case Constants.KAS_DAI:
			tokNo = CommonModule.getKasTokNo(dao);
			break;
			//�䒠��ʁF�ؗp�䒠
		case Constants.SYKY_DAI:
			tokNo = CommonModule.getKrukTokNo(dao);
			break;
			//�䒠��ʁF��p�䒠
		case Constants.SEY_DAI:
			tokNo = CommonModule.getSeyTokNo(dao);
			break;
		default:
			break;
		}
		int renNo = 1;
		//�c�a�ɓo�^����B
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			Map<String, Object> param = new HashMap<String, Object>();
			param = putParams(tblTBL1RowMap);
			switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
			//�䒠��ʁF�ЗL�䒠
			case Constants.SYU_DAI:
				param.put("SYU_TOK_NO"			, Integer.parseInt(tokNo));
				param.put("SYU_TOK_RRK_SSE_RNO"	, renNo);
				//����敪�F�V�K
				if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
					param.put("SYU_NO"				, searchTerms.get("TXT_SYU_NO_00"));
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_00"));
					param.put("SYU_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					dao.executeSQL(param, "FKSD146_INSERT_001", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_004", CommonDAO.BUSINESS_SQL);
					//����敪�F�C��
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_01"));
					param.put("SYU_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					param.put("SYU_NO_W01"			, searchTerms.get("TXT_SYU_NO_00"));
					param.put("SYU_IDO_RRK_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_SYU_IDO_RRK_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_UPDATE_001", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_004", CommonDAO.BUSINESS_SQL);
					//����敪�F�폜
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_02"));
					param.put("SYU_NO_W01"			, searchTerms.get("TXT_SYU_NO_00"));
					param.put("SYU_IDO_RRK_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_SYU_IDO_RRK_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_DELETE_001", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_004", CommonDAO.BUSINESS_SQL);
				}
				break;
				//�䒠��ʁF�n�����E�n�㌠�䒠
			case Constants.CECJ_DAI:
				param.put("CECJ_TOK_NO"			, Integer.parseInt(tokNo));
				param.put("CECJ_IDO_RRK_SSE_RNO", renNo);
				if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
					param.put("KYK_NO"				, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_00"));
					param.put("CECJ_IDO_SBT"		, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					dao.executeSQL(param, "FKSD146_INSERT_005", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_008", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_01"));
					param.put("CECJ_IDO_SBT"		, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("CECJ_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_CECJ_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_UPDATE_002", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_008", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_02"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("CECJ_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_CECJ_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_DELETE_002", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_008", CommonDAO.BUSINESS_SQL);
				}
				break;
				//�䒠��ʁF�ݕt�䒠
			case Constants.KAS_DAI:
				param.put("KAS_TOK_NO"			, Integer.parseInt(tokNo));
				param.put("KAS_IDO_RRK_SSE_RNO"	, renNo);
				if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
					param.put("KYK_NO"				, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_00"));
					param.put("KAS_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					dao.executeSQL(param, "FKSD146_INSERT_009", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_012", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_01"));
					param.put("KAS_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KAS_IDO_RNO_W01"	,	 Integer.parseInt(tblTBL1RowMap.get("HDN_KAS_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_UPDATE_003", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_012", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_02"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KAS_IDO_RNO_W01"		, Integer.parseInt(tblTBL1RowMap.get("HDN_KAS_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_DELETE_003", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_012", CommonDAO.BUSINESS_SQL);
				}
				break;
				//�䒠��ʁF�ؗp�䒠
			case Constants.SYKY_DAI:
				param.put("KRUK_TOK_NO"				, Integer.parseInt(tokNo));
				param.put("KRUK_IDO_RRK_SSE_RNO"	, renNo);
				if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
					param.put("KYK_NO"				, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_00"));
					param.put("KRUK_IDO_SBT"		, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					dao.executeSQL(param, "FKSD146_INSERT_013", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_016", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_01"));
					param.put("KRUK_IDO_SBT"		, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KRUK_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_KRUK_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_UPDATE_004", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_016", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_02"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KRUK_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_KRUK_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_DELETE_004", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_016", CommonDAO.BUSINESS_SQL);
				}
				break;
				//�䒠��ʁF��p�䒠
			case Constants.SEY_DAI:
				param.put("SEY_TOK_NO"			, Integer.parseInt(tokNo));
				param.put("SEY_IDO_RRK_SSE_RNO"	, renNo);
				if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
					param.put("KYK_NO"				, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_00"));
					param.put("SEY_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					dao.executeSQL(param, "FKSD146_INSERT_017", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_020", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_01"));
					param.put("SEY_IDO_SBT"			, tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SEY_IDO_RNO_W01"		, Integer.parseInt(tblTBL1RowMap.get("HDN_SEY_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_UPDATE_005", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_020", CommonDAO.BUSINESS_SQL);
				} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
					param.put("SS_KBN"				, tblTBL1RowMap.get("RDO_SS_KBN_02"));
					param.put("KYK_NO_W01"			, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SEY_IDO_RNO_W01"		, Integer.parseInt(tblTBL1RowMap.get("HDN_SEY_IDO_RNO_00").toString()));
					dao.executeSQL(param, "FKSD146_DELETE_005", CommonDAO.BUSINESS_SQL);
					dao.executeSQL(param, "FKSD146_INSERT_020", CommonDAO.BUSINESS_SQL);
				}
				break;
			default:
				break;
			}
			renNo++;
		}
		//�u�o�^�v�A�N�V�������Z�b�V�����ɕێ�����B
		setSession(EcSession.PAGE_SCOPE, "actionName", "entry");
		//��ʏ����ĕ\������B
		search();
		//�R�~�b�g����B
		dao.commit();
		setSession(EcSession.PAGE_SCOPE	, "BTN_DISABLED_MODE"	, Boolean.FALSE);
		return getForward("/xhtml/FKSD146.xhtml");
	}
	/**
	 * ���Z�b�g���̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String reset() throws Exception {
		//��ʍ��ڂ�ݒ肷��B
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		getForm().put("SLC_LST_SBT_00"	, searchTerms.get("SLC_LST_SBT_00"));
		getForm().put("TXT_SYU_NO_00"	, searchTerms.get("TXT_SYU_NO_00"));
		getForm().put("TXT_KYK_NO_00"	, searchTerms.get("TXT_KYK_NO_00"));
		setSession(EcSession.PAGE_SCOPE, "actionName", "reset");
		return search();
	}
	/**
	 * �e���\�b�h�O�Ɏ��s����鏈�����s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	@Override
	public String start() throws Exception {
		CommonDAO dao = (CommonDAO) getDao();
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		if (searchTerms != null) {
			switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
			case Constants.SYU_DAI:
				dao.setSqlName("FKSD146_SELECT_001");
				break;
			case Constants.CECJ_DAI:
				dao.setSqlName("FKSD146_SELECT_002");
				break;
			case Constants.KAS_DAI:
				dao.setSqlName("FKSD146_SELECT_003");
				break;
			case Constants.SYKY_DAI:
				dao.setSqlName("FKSD146_SELECT_004");
				break;
			case Constants.SEY_DAI:
				dao.setSqlName("FKSD146_SELECT_005");
				break;
			default:
				break;
			}
		}
		return super.start();
	}
	/**
	 * ���\�b�h�̎��s��ɌĂяo����鏈�����s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	@Override
	public String end() throws Exception {
		Boolean btnDisabledMode = (Boolean) getSession(EcSession.PAGE_SCOPE, "BTN_DISABLED_MODE");
		if (btnDisabledMode != null && btnDisabledMode) {
			// �u�o�^�v�{�^����ی삷��B
			getPageItemStyle("BTN_ENTRY_00").setDisabled(true);
			// �u���Z�b�g�v�{�^����ی삷��B
			getPageItemStyle("BTN_RESET_00").setDisabled(true);
		}
		return super.end();
	}
	/**
	 * ���փ`�F�b�N���s���܂��B.
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isError() throws Exception {
		@SuppressWarnings("unchecked")
		DataModel<List<Map<String, Object>>> tblTBL1List = (ListDataModel<List<Map<String, Object>>>) getForm().get("TBL_TBL1");
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tblTBL1Row = (List<Map<String, Object>>) tblTBL1List.getWrappedData();
		//���삪���ׂăX�y�[�X�̎��C�G���[�Ƃ���B
		if (isE2007(tblTBL1Row)) {
			return true;
		}
		//���삪�X�y�[�X�ȊO�̎��C�ٓ��N�����C�ٓ���ʂ��X�y�[�X�̏ꍇ�C�G���[�Ƃ���B
		if (isE2008(tblTBL1Row)) {
			return true;
		}
		//���삪�Q(�C��)�C�R(�폜)�̎��C�ٓ������c�a(*1)�ɑ��݂��Ȃ��ꍇ�C�G���[�Ƃ���B
		if (isE2009(tblTBL1Row)) {
			return true;
		}
		//1�D�ٓ��N�������X�y�[�X�̎��C����C�ٓ���ʁC����N�����C���菑�ԍ����X�y�[�X�ȊO�̏ꍇ�C�G���[�Ƃ���B
		//2�D�ٓ��N�������X�y�[�X�ȊO�̎��C�ٓ���ʂ��X�y�[�X�̏ꍇ�C�G���[�Ƃ���B
		if (isE2010(tblTBL1Row)) {
			return true;
		}
		//���삪�X�y�[�X�ȊO�̎��C�ٓ��N����������N�����łȂ��ꍇ�C�G���[�Ƃ���B
		if (isE2011(tblTBL1Row)) {
			return true;
		}
		return false;
	}
	/**
	 * ���փ`�F�b�N�iE2007�j���s���܂��B.
	 * @param tblTBL1Row
	 *             ���׍s
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE2007(List<Map<String, Object>> tblTBL1Row) throws Exception {
		boolean dbUpdFlg = 	true;
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			//����敪�F�V�K
			if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))) {
				dbUpdFlg = false;
				//����敪�F�C��
			} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))) {
				dbUpdFlg = false;
				//����敪�F�폜
			} else if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
				dbUpdFlg = false;
			}
		}
		if (dbUpdFlg) {
			setErrorMessage("E2007");
			for (int rowNo = 0; rowNo < tblTBL1Row.size(); rowNo++ ) {
				getPageItemStyle("TBL_TBL1", rowNo, "RDO_SS_KBN_00").setError(true);
				getPageItemStyle("TBL_TBL1", rowNo, "RDO_SS_KBN_01").setError(true);
				getPageItemStyle("TBL_TBL1", rowNo, "RDO_SS_KBN_02").setError(true);
			}
			return true;
		}
		return false;
	}
	/**
	 * ���փ`�F�b�N�iE2008�j���s���܂��B.
	 * @param tblTBL1Row
	 *             ���׍s
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE2008(List<Map<String, Object>> tblTBL1Row) throws Exception {
		int rowNo = 0;
		List<Map<String, Object>> errorList = new ArrayList<Map<String, Object>>();
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))
					|| StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01"))
					|| StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
				if (StringUtil.isNullOrEmpty(tblTBL1RowMap.get("TXT_IDO_DATE_00").toString())) {
					Map<String, Object> errorMap = new HashMap<String, Object>();
					errorMap.put("rowNo", rowNo);
					errorMap.put("errorItem", "TXT_IDO_DATE_00");
					errorList.add(errorMap);
				}
				if (StringUtil.isNullOrEmpty(tblTBL1RowMap.get("SLC_IDO_SBT_CD_00").toString().trim())) {
					Map<String, Object> errorMap = new HashMap<String, Object>();
					errorMap.put("rowNo", rowNo);
					errorMap.put("errorItem", "SLC_IDO_SBT_CD_00");
					errorList.add(errorMap);
				}
			}
			rowNo++;
		}
		if (errorList.size() != 0) {
			for (int i = 0; i < errorList.size(); i++) {
				getPageItemStyle("TBL_TBL1", Integer.parseInt(errorList.get(i).get("rowNo").toString()), errorList.get(i).get("errorItem").toString()).setError(true);
			}
			setErrorMessage("E2008");
			return true;
		}
		return false;
	}
	/**
	 * ���փ`�F�b�N�iE2009�j���s���܂��B.
	 * @param tblTBL1Row
	 *             ���׍s
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE2009(List<Map<String, Object>> tblTBL1Row) throws Exception {
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		CommonDAO dao = (CommonDAO) getDao();
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			//���삪�u�C���v�C�u�폜�v�̏ꍇ
			if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01")) || StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
				Map<String, Object> param = new HashMap<String, Object>();
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
				//�䒠��ʁF�ЗL�䒠
				case Constants.SYU_DAI:
					param.put("SYU_NO_W01"			, searchTerms.get("TXT_SYU_NO_00"));
					param.put("SYU_IDO_RRK_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_SYU_IDO_RRK_RNO_00").toString()));
					list = dao.getQueryResult(param, "E2009_SEL_001", CommonDAO.CHECK_SQL);
					//�������ʂ�0���̏ꍇ
					if (ZERO.equals(list.get(0).get("COUNT").toString())) {
						setErrorMessage("E2009");
						return true;
					}
					break;
					//�䒠��ʁF�n�����E�n�㌠�䒠
				case Constants.CECJ_DAI:
					param.put("KYK_NO_W01"		, searchTerms.get("TXT_KYK_NO_00"));
					param.put("CECJ_IDO_RNO_W01", Integer.parseInt(tblTBL1RowMap.get("HDN_CECJ_IDO_RNO_00").toString()));
					list = dao.getQueryResult(param, "E2009_SEL_002", CommonDAO.CHECK_SQL);
					//�������ʂ�0���̏ꍇ
					if (ZERO.equals(list.get(0).get("COUNT").toString())) {
						setErrorMessage("E2009");
						return true;
					}
					break;
					//�䒠��ʁF�ݕt�䒠
				case Constants.KAS_DAI:
					param.put("KYK_NO_W01"		, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KAS_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_KAS_IDO_RNO_00").toString()));
					list = dao.getQueryResult(param, "E2009_SEL_003", CommonDAO.CHECK_SQL);
					//�������ʂ�0���̏ꍇ
					if (ZERO.equals(list.get(0).get("COUNT").toString())) {
						setErrorMessage("E2009");
						return true;
					}
					break;
					//�䒠��ʁF�ؗp�䒠
				case Constants.SYKY_DAI:
					param.put("KYK_NO_W01"		, searchTerms.get("TXT_KYK_NO_00"));
					param.put("KRUK_IDO_RNO_W01", Integer.parseInt(tblTBL1RowMap.get("HDN_KRUK_IDO_RNO_00").toString()));
					list = dao.getQueryResult(param, "E2009_SEL_004", CommonDAO.CHECK_SQL);
					//�������ʂ�0���̏ꍇ
					if (ZERO.equals(list.get(0).get("COUNT").toString())) {
						setErrorMessage("E2009");
						return true;
					}
					break;
					//�䒠��ʁF��p�䒠
				case Constants.SEY_DAI:
					param.put("KYK_NO_W01"		, searchTerms.get("TXT_KYK_NO_00"));
					param.put("SEY_IDO_RNO_W01"	, Integer.parseInt(tblTBL1RowMap.get("HDN_SEY_IDO_RNO_00").toString()));
					list = dao.getQueryResult(param, "E2009_SEL_005", CommonDAO.CHECK_SQL);
					//�������ʂ�0���̏ꍇ
					if (ZERO.equals(list.get(0).get("COUNT").toString())) {
						setErrorMessage("E2009");
						return true;
					}
					break;
				default:
					break;
				}
			}
		}
		return false;
	}
	/**
	 * ���փ`�F�b�N�iE2010�j���s���܂��B.
	 * @param tblTBL1Row
	 *             ���׍s
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE2010(List<Map<String, Object>> tblTBL1Row) throws Exception {
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			if (StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("TXT_IDO_DATE_00"))) {
				if (!(StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("RDO_SS_KBN_00"))
						&& StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"))
						&& StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("TXT_IDO_KIT_DATE_00"))
						&& StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("TXT_IDO_KKTS_NO_00")))) {
					setErrorMessage("E2010");
					return true;
				}
			} else {
				if (StringUtil.isNullOrEmpty((String) tblTBL1RowMap.get("SLC_IDO_SBT_CD_00"))) {
					setErrorMessage("E2010");
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * ���փ`�F�b�N�iE2011�j���s���܂��B.
	 * @param tblTBL1Row
	 *             ���׍s
	 * @return �^�U�l
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE2011(List<Map<String, Object>> tblTBL1Row) throws Exception {
		@SuppressWarnings("unchecked")
		Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "FKSD146");
		CommonDAO dao = (CommonDAO) getDao();
		for (Map<String, Object> tblTBL1RowMap : tblTBL1Row) {
			//���삪�X�y�[�X�ȊO�̏ꍇ
			if (StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_00")) || StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_01")) || StringUtil.isNotNull((String) tblTBL1RowMap.get("RDO_SS_KBN_02"))) {
				Map<String, Object> param = new HashMap<String, Object>();
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				param.put("KYK_NO_W01"	, searchTerms.get("TXT_KYK_NO_00"));
				switch ((String) searchTerms.get("SLC_LST_SBT_00")) {
				//�䒠��ʁF�ЗL�䒠
				case Constants.SYU_DAI:
					break;
					//�䒠��ʁF�n�����E�n�㌠�䒠
				case Constants.CECJ_DAI:
					list = dao.getQueryResult(param, "E2011_SEL_001", CommonDAO.CHECK_SQL);
					if (tblTBL1RowMap.get("TXT_IDO_DATE_00").toString().compareTo(list.get(0).get("KYK_DATE").toString()) < 0) {
						setErrorMessage("E2011");
						return true;
					}
					break;
					//�䒠��ʁF�ݕt�䒠
				case Constants.KAS_DAI:
					list = dao.getQueryResult(param, "E2011_SEL_003", CommonDAO.CHECK_SQL);
					if (tblTBL1RowMap.get("TXT_IDO_DATE_00").toString().compareTo(list.get(0).get("KYK_DATE").toString()) < 0) {
						setErrorMessage("E2011");
						return true;
					}
					break;
					//�䒠��ʁF�ؗp�䒠
				case Constants.SYKY_DAI:
					list = dao.getQueryResult(param, "E2011_SEL_002", CommonDAO.CHECK_SQL);
					if (tblTBL1RowMap.get("TXT_IDO_DATE_00").toString().compareTo(list.get(0).get("KYK_DATE").toString()) < 0) {
						setErrorMessage("E2011");
						return true;
					}
					break;
					//�䒠��ʁF��p�䒠
				case Constants.SEY_DAI:
					list = dao.getQueryResult(param, "E2011_SEL_004", CommonDAO.CHECK_SQL);
					if (tblTBL1RowMap.get("TXT_IDO_DATE_00").toString().compareTo(list.get(0).get("KYKA_DATE").toString()) < 0) {
						setErrorMessage("E2011");
						return true;
					}
					break;
				default:
					break;
				}
			}
		}
		return false;
	}
	/**
	 * �����t�H�[���̏��������s���܂��B.
	 * @throws Exception
	 *             ��O
	 */
	public void initializeSearch() throws Exception {
		//�䒠��ʃ��X�g�{�b�N�X���쐬����B
		List<SelectItem> daiSbtList =  new ArrayList<SelectItem>();
		daiSbtList.add(new SelectItem(""					, ""));
		daiSbtList.add(new SelectItem(Constants.SYU_DAI		, "�ЗL�䒠"));
		daiSbtList.add(new SelectItem(Constants.KAS_DAI		, "�ݕt�䒠"));
		daiSbtList.add(new SelectItem(Constants.SYKY_DAI	, "�ؗp�䒠"));
		daiSbtList.add(new SelectItem(Constants.SEY_DAI		, "��p�䒠"));
		daiSbtList.add(new SelectItem(Constants.CECJ_DAI	, "�n�����E�n�㌠�䒠"));
		//�����t�H�[����������Ԃɂ���B
		getForm().put("SLC_LST_SBT_00"	, "");
		getForm().put("LST_LST_SBT_00"	, daiSbtList);
		getForm().put("TXT_SYU_NO_00"	, "");
		getForm().put("TXT_KYK_NO_00"	, "");
	}
	/**
	 * �p�����[�^��}�����܂��B.
	 * @param tblRowMap
	 *             �P�s���̃f�[�^����
	 * @throws Exception
	 *             ��O
	 * @return param
	 */
	public Map<String, Object> putParams(Map<String, Object> tblRowMap) throws Exception {
		// �v�����V�p�������擾����B
		PrincipalImpl principal = (PrincipalImpl) getPrincipal();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("IDO_DATE"	, tblRowMap.get("TXT_IDO_DATE_00"));
		param.put("IDO_DATE"	, tblRowMap.get("TXT_IDO_DATE_00"));
		param.put("IDO_SBT"		, tblRowMap.get("SLC_IDO_SBT_CD_00"));
		param.put("IDO_KIT_DATE", tblRowMap.get("TXT_IDO_KIT_DATE_00"));
		param.put("IDO_KKTS_NO"	, tblRowMap.get("TXT_IDO_KKTS_NO_00"));
		param.put("UPD_USR"		, principal.getUserId());
		param.put("UPD_DATE"	, (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSSSSS)).format(getRequestTime()));
		return param;
	}
}

