/**
 * FKSD130.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSD;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import jp.co.enecom.framework.session.EcSession;
import jp.co.enecom.framework.template.list.AbstractListLGManagedBean;
import jp.co.enecom.framework.template.list.AbstractListObject;
import jp.co.enecom.framework.template.list.RowNumListObject;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.constants.Constants;

/**
 * �����E�䒠�쐬�Ɩ�_�⎆���\���̃r�W�l�X���W�b�N�N���X�ł��B.
 * <p>
 * Ver.00.00.00 2018/3/8 : EC-kadoya - Original
 */
public class FKSD130LG extends AbstractListLGManagedBean {

    /** �J�ڌ��v�����j���[. */
    private static final String PULL_MENU = "1";
    /** �\�����׍s��. */
    private static final int MAX_ROW = 100;
    /** �e�[�u���\��. */
    private static final int TBL_OFF = 1;
    /** �e�[�u����\��. */
    private static final int TBL_ON = 0;
    /** �䒠��ʋ�. */
    private static final String SPACE_DAI = "";

    /**
     * �����\�����̏������s���܂��B.
     * @return �t�H���[�h��
     * @throws Exception
     *             ��O
     */
    public String init() throws Exception {

        String[] param = getRequestParameter().get("flg");
        //�J�ڌ���ʔ���
        if (param != null && PULL_MENU.equals(param[0])) {
            clearSession(EcSession.FUNCTION_SCOPE);
        }

        //�䒠��ʃ��X�g�{�b�N�X�쐬
        List<SelectItem> daikList =  new ArrayList<SelectItem>();
        daikList.add(new SelectItem(SPACE_DAI, ""));
        daikList.add(new SelectItem(Constants.SYU_DAI, "�ЗL�䒠"));
        daikList.add(new SelectItem(Constants.KAS_DAI, "�ݕt�䒠"));
        daikList.add(new SelectItem(Constants.SYKY_DAI, "�ؗp�䒠"));
        daikList.add(new SelectItem(Constants.SEY_DAI, "��L�䒠"));
        daikList.add(new SelectItem(Constants.CECJ_DAI, "�n�����E�n�㌠�䒠"));
        getForm().put("LST_DAI_SRCH_KBN_00", daikList);

        @SuppressWarnings("unchecked")
        Map<String, Object> fksd122 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD122");

        @SuppressWarnings("unchecked")
        Map<String, Object> fksd123 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD123");

        @SuppressWarnings("unchecked")
        Map<String, Object> fksd124 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD124");

        @SuppressWarnings("unchecked")
        Map<String, Object> fksd125 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD125");

        @SuppressWarnings("unchecked")
        Map<String, Object> fksd126 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD126");

        if (fksd122 != null) {
            getForm().put("SLC_DAI_SRCH_KBN_00", Constants.SYU_DAI);
            getForm().put("HDN_TBL_DSP_FLG_00" , TBL_ON);
            getForm().put("TXT_SYU_NO", fksd122.get("LBL_SYU_NO_00") );
            getForm().put("TXT_BKN_NO", fksd122.get("LBL_BKN_NO_00") );
            return search();
        } else if (fksd123 != null) {
            getForm().put("SLC_DAI_SRCH_KBN_00", Constants.KAS_DAI);
            getForm().put("HDN_TBL_DSP_FLG_00" , TBL_ON);
            getForm().put("TXT_KYK_NO", fksd123.get("LBL_KYK_NO_00") );
            return search();
       } else if (fksd124 != null) {
            getForm().put("SLC_DAI_SRCH_KBN_00", Constants.SYKY_DAI);
            getForm().put("HDN_TBL_DSP_FLG_00" , TBL_ON);
            getForm().put("TXT_KYK_NO", fksd124.get("LBL_KYK_NO_00") );
            getForm().put("TXT_BKN_NO", fksd124.get("LBL_BKN_NO_00") );
           return search();
       } else if (fksd125 != null) {
            getForm().put("SLC_DAI_SRCH_KBN_00", Constants.SEY_DAI);
            getForm().put("HDN_TBL_DSP_FLG_00" , TBL_ON);
            getForm().put("TXT_KYK_NO", fksd125.get("LBL_KYK_NO_00") );
            getForm().put("TXT_BKN_NO", fksd125.get("LBL_BKN_NO_00") );
           return search();
       } else if (fksd126 != null) {
            getForm().put("SLC_DAI_SRCH_KBN_00", Constants.CECJ_DAI);
            getForm().put("HDN_TBL_DSP_FLG_00" , TBL_ON);
            getForm().put("TXT_KYK_NO", fksd126.get("LBL_KYK_NO_00") );
            getForm().put("TXT_BKN_NO", fksd126.get("LBL_BKN_NO_00") );
           return search();
       }

        // ��ʍ��ڂ�ҏW����B
        getForm().put("HDN_TBL_DSP_FLG_00" , TBL_OFF);
        return super.init();
    }

    /**
     * �����{�^���������̏������s���܂��B.
     * @return true:�G���[�Ȃ�,false:�G���[����
     * @throws Exception
     *             ��O
     */
    public String search() throws Exception {
        //�����������Z�b�V�����ɕێ�
        Map<String, Object> searchTerms = new HashMap<String, Object>();
        searchTerms.put("LST_DAI_SRCH_KBN_00"	, getForm().get("LST_DAI_SRCH_KBN_00"));
        searchTerms.put("SLC_DAI_SRCH_KBN_00"	, getForm().get("SLC_DAI_SRCH_KBN_00"));
        searchTerms.put("TXT_SYU_NO"			, getForm().get("TXT_SYU_NO"));
        searchTerms.put("TXT_KYK_NO"			, getForm().get("TXT_KYK_NO"));
        searchTerms.put("TXT_BKN_NO"			, getForm().get("TXT_BKN_NO"));
        setSession(EcSession.PAGE_SCOPE	, "SEARCH_TERMS"	, searchTerms);
        getForm().put("HDN_TBL_DSP_FLG_00", TBL_ON);
        return super.search();
    }

    /**
     * ���׍s�̏��������s���܂��B.
     * @return �ꗗ���
     * @throws Exception
     *             ��O
     * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#initList()
     */
    @Override
    protected AbstractListObject initList() throws Exception {
        // �ꗗ���𐶐�����B
        RowNumListObject rowList = new RowNumListObject("getQueryResult", MAX_ROW, getDao());
        return rowList;
    }

    /**
     * ����������ݒ肵�܂��B.
     * @return �ꗗ���
     * @throws Exception
     *             ��O
     * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#initSearchParam()
     */
    @Override
    protected AbstractListObject initSearchParam() throws Exception {
        // �ꗗ���𐶐�����B
        RowNumListObject list = null;
        list = new RowNumListObject("getQueryResult", MAX_ROW, getDao());
        Map<String, Object> param = new HashMap<String, Object>();
        String srchKbn = (String) getForm().get("SLC_DAI_SRCH_KBN_00");

        if (Constants.SYU_DAI.equals(srchKbn)) {
            param.put("SYU_NO_W01"	, escapeSQLParam(getForm().get("TXT_SYU_NO")) + Constants.PERCENT);
            param.put("BKN_NO_W01"	, escapeSQLParam(getForm().get("TXT_BKN_NO")) + Constants.PERCENT);
        } else if (Constants.KAS_DAI.equals(srchKbn) || Constants.SYKY_DAI.equals(srchKbn)
                   || Constants.SEY_DAI.equals(srchKbn) || Constants.CECJ_DAI.equals(srchKbn)) {
            param.put("KYK_NO_W01"	, escapeSQLParam(getForm().get("TXT_KYK_NO")) + Constants.PERCENT);
            param.put("BKN_NO_W01"	, escapeSQLParam(getForm().get("TXT_BKN_NO")) + Constants.PERCENT);
        }
        list.setParam(param);
        return list;
    }

    /**
     * �������s���O�̎��O�`�F�b�N�������s���܂��B.
     * @return true:�G���[�Ȃ�,false:�G���[����
     * @throws Exception
     *             ��O
     * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#checkBeforeSearch()
     */
    @Override
    protected boolean checkBeforeSearch() throws Exception {
        CommonDAO dao = (CommonDAO) getDao();
        String srchKbn = (String) getForm().get("SLC_DAI_SRCH_KBN_00");

        if (Constants.SYU_DAI.equals(srchKbn)) {
            //DAO�N���X��SQL����ݒ�
            dao.setSqlName("FKSD130_SELECT_001_CNT");
            //�����Ώۃf�[�^����ݒ�
            getMaxRownum("getQueryResult");
            //DAO�N���X��SQL�����Đݒ�
            dao.setSqlName("FKSD130_SELECT_001");
            return true;
        } else if (Constants.KAS_DAI.equals(srchKbn)) {
            //DAO�N���X��SQL����ݒ�
            dao.setSqlName("FKSD130_SELECT_005_CNT");
            //�����Ώۃf�[�^����ݒ�
            getMaxRownum("getQueryResult");
            //DAO�N���X��SQL�����Đݒ�
            dao.setSqlName("FKSD130_SELECT_005");
            return true;
        } else if (Constants.SYKY_DAI.equals(srchKbn)) {
            dao.setSqlName("FKSD130_SELECT_003_CNT");
            //�����Ώۃf�[�^����ݒ�
            getMaxRownum("getQueryResult");
            //DAO�N���X��SQL�����Đݒ�
            dao.setSqlName("FKSD130_SELECT_003");
            return true;
        } else if (Constants.SEY_DAI.equals(srchKbn)) {
            dao.setSqlName("FKSD130_SELECT_004_CNT");
            //�����Ώۃf�[�^����ݒ�
            getMaxRownum("getQueryResult");
            //DAO�N���X��SQL�����Đݒ�
            dao.setSqlName("FKSD130_SELECT_004");
            return true;
        } else if (Constants.CECJ_DAI.equals(srchKbn)) {
            dao.setSqlName("FKSD130_SELECT_002_CNT");
            //�����Ώۃf�[�^����ݒ�
            getMaxRownum("getQueryResult");
            //DAO�N���X��SQL�����Đݒ�
            dao.setSqlName("FKSD130_SELECT_002");
            return true;
        }
        return false;
    }

    /**
     * �������ʖ������̏������s���܂��B.
     * @throws Exception
     *             ��O
     * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#doNotFound()
     */
    @Override
    protected void doNotFound() throws Exception {
    }

    /**
     * �\������f�[�^��ҏW���܂��B.
     * @param map
     *            1�y�[�W���̕\���f�[�^
     * @throws Exception
     *             ��O
     * @see jp.co.enecom.framework.template.list.AbstractListLGManagedBean#editPage(java.util.Map)
     */
    @Override
    protected void editPage(Map<Integer, Object> map) throws Exception {
        //���������ݒ�
        @SuppressWarnings("unchecked")
        Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "SEARCH_TERMS");
        if (searchTerms != null) {
            getForm().put("LST_DAI_SRCH_KBN_00"	, searchTerms.get("LST_DAI_SRCH_KBN_00"));
            getForm().put("SLC_DAI_SRCH_KBN_00"	, searchTerms.get("SLC_DAI_SRCH_KBN_00"));
            getForm().put("TXT_SYU_NO"			, searchTerms.get("TXT_SYU_NO"));
            getForm().put("TXT_BKN_NO"			, searchTerms.get("TXT_BKN_NO"));
            getForm().put("TXT_KYK_NO"			, searchTerms.get("TXT_KYK_NO"));

            //�����\��
            getForm().put("LBL_SRCH_RESLT_00"	, getList().getMaxRownum());
        } else {
            getForm().put("LBL_SRCH_RESLT_00"	, 0);
        }

        DataModel<List<Map<String, Object>>> tableData = new ListDataModel<List<Map<String, Object>>>();
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        // ���׍s�̕ҏW
        //�sNo
        int rowNum = 1;
        for (Map.Entry<Integer, Object>  resultEntry : map.entrySet()) {
            Map<String, Object> tableMap = new HashMap<String, Object>();
            @SuppressWarnings("unchecked")
            Map<String, Object> resultRow = (Map<String, Object>) resultEntry.getValue();
            String searchKbn = (String) searchTerms.get("SLC_DAI_SRCH_KBN_00");

            //�s�ԍ��ݒ�
            tableMap.put("LBL_LINE_NO_00" 		, rowNum++);

            //�⎆���
            tableMap.put("LBL_SCR_HOSHI_00"		, resultRow.get("HOSHI"));

            //�ЗL�ԍ�
            if (Constants.SYU_DAI.equals(searchKbn)) {
                tableMap.put("LBL_SYU_00"		, resultRow.get("SYU_NO"));
            } else {
                tableMap.put("LBL_SYU_00"		, " ");
            }

            //�_��ԍ�
            if (Constants.SYU_DAI.equals(searchKbn)) {
                tableMap.put("LBL_KYK_00"		, " ");
            } else {
                tableMap.put("LBL_KYK_00"		, resultRow.get("KYK_NO"));
            }

            //�����ԍ�
            tableMap.put("LBL_BKN_00"			, resultRow.get("BKN_NO"));

            list.add(tableMap);
        }

        //��ʍ��ڂ�ҏW
        tableData.setWrappedData(list);
        getForm().put("TBL_TBL1"	, tableData);
    }

    /**
     * �����폜�{�^���������̏������s���܂��B.
     * @return �t�H���[�h��
     * @throws Exception
     *             ��O
     */
    public String delete_terms() throws Exception {

        //�����t�H�[����������Ԃɂ���
        @SuppressWarnings("unchecked")
        Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "SEARCH_TERMS");
        if (searchTerms != null) {
            searchTerms.clear();
        }

        getForm().put("SLC_DAI_SRCH_KBN_00", SPACE_DAI);

        getForm().put("TXT_SYU_NO", "");

        getForm().put("TXT_KYK_NO", "");

        getForm().put("TXT_BKN_NO", "");

        return getForward("/xhtml/FKSD130.xhtml");
    }

    /**
     * �e���\�b�h�O�Ɏ��s����鏈�����s���܂��B.
     * @return �t�H���[�h��
     * @throws Exception
     *             ��O
     */
    @Override
    public String start() throws Exception {
        CommonDAO dao = (CommonDAO) getDao();

        @SuppressWarnings("unchecked")
        Map<String, Object> searchTerms = (Map<String, Object>) getSession(EcSession.PAGE_SCOPE, "SEARCH_TERMS");
        String srchKbn = (String) getForm().get("SLC_DAI_SRCH_KBN_00");

        if (searchTerms != null ) {
             if (Constants.SYU_DAI.equals(srchKbn)) {
                 dao.setSqlName("FKSD130_SELECT_001");
             } else if (Constants.KAS_DAI.equals(srchKbn)) {
                 dao.setSqlName("FKSD130_SELECT_005");
             } else  if (Constants.SYKY_DAI.equals(srchKbn)) {
                 dao.setSqlName("FKSD130_SELECT_003");
             } else if (Constants.SEY_DAI.equals(srchKbn)) {
                 dao.setSqlName("FKSD130_SELECT_004");
             } else if (Constants.CECJ_DAI.equals(srchKbn)) {
                 dao.setSqlName("FKSD130_SELECT_002");
             }
        }
        return super.start();
    }
}
