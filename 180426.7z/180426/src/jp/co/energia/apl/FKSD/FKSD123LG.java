/**
 * ECSD123LG.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.apl.FKSD;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import jp.co.enecom.framework.constants.FrameworkConstants;
import jp.co.enecom.framework.session.EcSession;
import jp.co.enecom.framework.template.print.AbstractEasyPrintLGManagedBean;
import jp.co.energia.apl.FKSR.FKSR003;
import jp.co.energia.apl.common.dao.CommonDAO;
import jp.co.energia.apl.common.module.CommonModule;
import jp.co.energia.apl.constants.Constants;

/**
 * ������䒠�쐬�Ɩ�-�䒠������\��_�ݕt�䒠��ʂ̃r�W�l�X���W�b�N�N���X�ł��B.
 * <p>
 * Ver.00.00.00 2018/3/7 : EC-tani - Original
 */
public class FKSD123LG extends AbstractEasyPrintLGManagedBean {

	/** �}�ʁE�_�񏑃f�[�^���X�g�\������. */
	private static final int ZMN_MAX_ROW 			= 10;
	/** �ݕt�Ώۓy�n�e�[�u���\�����׍s��. */
	private static final int KAS_MAX_ROW 			= 13;
	/** �ݕt�Ώۓy�n�e�[�u���\��_�L. */
	private static final String KAS_TBL_ON 			= "1";
	/** �ݕt�Ώۓy�n�e�[�u���\��_��. */
	private static final String KAS_TBL_OFF 		= "0";
	/** �Ȗ�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KMK 		= "37";
	/** �p�r_�敪��ʃR�[�h. */
	private static final String KBN_SBT_YOT 		= "45";
	/** ������_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SIB 		= "53";
	/** �ݒn�͈�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KAST_HANI 	= "22";
	/** �~���t���O_�敪��ʃR�[�h. */
	private static final String KBN_SBT_SKK 		= "19";
	/** ��������_�敪��ʃR�[�h. */
	private static final String KBN_SBT_NYK_SKI		= "15";
	/** �������_�敪��ʃR�[�h. */
	private static final String KBN_SBT_NYK_SBT 	= "16";
	/** �֘A���_�敪��ʃR�[�h. */
	private static final String KBN_SBT_KNRE_CMPY 	= "72";
	/**�i��_�敪��ʃR�[�h. */
	private static final String KBN_SBT_HMK 		= "18";
	/**�ŋ�_�敪��ʃR�[�h. */
	private static final String KBN_SBT_ZEI 		= "17";
	/** �_�E�����[�h�t���O_1. */
	private static final String DOWNLOAD_FLG_ON 	= "1";

	/**
	 * �����\�����̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	@Override
	public String init() throws Exception {

		//��ʊԈ��p�����ڎ擾
		@SuppressWarnings("unchecked")
		Map<String, Object> fksd117 = (Map<String, Object>) getSession(EcSession.FUNCTION_SCOPE, "FKSD117");

		CommonDAO dao = (CommonDAO) getDao();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("KYK_NO_W01", fksd117.get("LBL_KYK_NO_01"));
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		list = dao.getQueryResult(param, "FKSD123_SELECT_004", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> ukeKmkList = new ArrayList<Map<String, Object>>();
		ukeKmkList = dao.getQueryResult(param, "FKSD123_SELECT_005", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> zmnList = new ArrayList<Map<String, Object>>();
		zmnList = dao.getQueryResult(param, "FKSD123_SELECT_006", CommonDAO.BUSINESS_SQL);

		List<Map<String, Object>> kasTshList = new ArrayList<Map<String, Object>>();
		kasTshList = dao.getQueryResult(param, "FKSD123_SELECT_007", CommonDAO.BUSINESS_SQL);

		param.put("KYK_NO_W02", fksd117.get("LBL_KYK_NO_01"));
		List<Map<String, Object>> bkoList = new ArrayList<Map<String, Object>>();
		bkoList = dao.getQueryResult(param, "FKSD123_SELECT_008", CommonDAO.BUSINESS_SQL);

		//��ʍ���e�[�u���ݒ�
		setUpperLeftTable(list, bkoList, zmnList);
		//��ʍ����e�[�u���ݒ�
		setBottomLeftTable(kasTshList);
		//��ʉE�e�[�u���ݒ�
		setRightTable(list, ukeKmkList);

		return getForward("/xhtml/FKSD123.xhtml");

	}

	/**
	 * ��ʍ���e�[�u�����ڂ̐ݒ���s���܂��B.
	 * @param list SQL�擾���X�g
	 * @param bkoList ���l
	 * @param zmnList �}�ʁE�_�񏑃f�[�^
	 * @throws Exception
	 *             ��O
	 */
	public void setUpperLeftTable(List<Map<String, Object>> list, List<Map<String, Object>> bkoList, List<Map<String, Object>> zmnList) throws Exception {

		CommonDAO dao = (CommonDAO) getDao();

		getForm().put("LBL_KYK_NO_00"				, list.get(0).get("KYK_NO"));
		getForm().put("LBL_DAI_KKSH_CD_00"			, list.get(0).get("DAI_KKSH_CD"));
		getForm().put("LBL_DAI_KKSH_NAME_01"		, list.get(0).get("DAI_KKSH_NAME"));
		getForm().put("LBL_GNB_KKSH_CD_00"			, list.get(0).get("GNB_KKSH_CD"));
		getForm().put("LBL_GNB_KKSH_NAME_01"		, list.get(0).get("GNB_KKSH_NAME"));
		getForm().put("LBL_JUT_KKSH_CD_00"			, list.get(0).get("JUT_KKSH_CD"));
		getForm().put("LBL_JUT_KKSH_NAME_01"		, list.get(0).get("JUT_KKSH_NAME"));
		getForm().put("LBL_GENK_CTR_CD_00"			, list.get(0).get("GENK_CTR_CD"));
		getForm().put("LBL_GENK_CTR_NAME_01"		, list.get(0).get("GENK_CTR_NAME"));
		getForm().put("LBL_KMK_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_KMK, ((String) list.get(0).get("KMK_CD"))));
		getForm().put("LBL_YOT_NAME_00"				, CommonModule.getKbn(dao, KBN_SBT_YOT, ((String) list.get(0).get("YOT_CD"))));
		getForm().put("LBL_WBS_YOS_00"				, list.get(0).get("WBS_YOS"));
		getForm().put("LBL_WBS_NAME_01"				, list.get(0).get("WBS_NAME"));
		getForm().put("LBL_KAN_CD_00"				, list.get(0).get("KAN_CD"));
		getForm().put("LBL_KAN_NAME_01"				, list.get(0).get("KAN_NAME"));
		getForm().put("LBL_RIT_KIT_NO_00"			, list.get(0).get("RIT_KIT_NO"));
		getForm().put("LBL_RIT_KIT_DATE_00"			, list.get(0).get("RIT_KIT_DATE"));
		getForm().put("LBL_KYK_DATE_00"				, list.get(0).get("KYK_DATE"));
		getForm().put("LBL_KYK_KKN_STA_00"			, list.get(0).get("KYK_KKN_STA"));
		getForm().put("LBL_KYK_KKN_END_00"			, list.get(0).get("KYK_KKN_END"));
		getForm().put("LBL_AUTO_UPD_SKI_00"			, list.get(0).get("AUTO_UPD_SKI"));
		getForm().put("LBL_KAST_SUM_MES_00"			, list.get(0).get("KAST_SUM_MES"));
		getForm().put("LBL_DNC_KYK_SU_00"			, list.get(0).get("DNC_KYK_SU"));
		getForm().put("LBL_KYKS_KBN_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_SIB, ((String) list.get(0).get("KYKS_KBN"))));
		getForm().put("LBL_JOSSK_Z_KBN_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_SIB, ((String) list.get(0).get("JOSSK_Z_KBN"))));
		if (bkoList.size() > 0) {
			getForm().put("LBL_BKO_00"					, bkoList.get(0).get("BKO"));
		}
		getForm().put("LBL_KAS_HOSHI_00"			, list.get(0).get("KAS_HOSHI"));
		//�}�ʁE�_�񏑃f�[�^�Y�t�ݒ�
		List<Map<String, Object>> tblTBL5RowList = new ArrayList<Map<String, Object>>();
		DataModel<List<Map<String, Object>>> tableLinkData = new ListDataModel<List<Map<String, Object>>>();
		int maxRowNum = 1;
		for (Map<String, Object> zmnListRow : zmnList) {

			Map<String, Object> tableLinkMap = new HashMap<String, Object>();

			tableLinkMap.put("LBL_ZMN_KYKS_DIS_FILE_NAME_00", zmnListRow.get("ZMN_KYKS_DIS_FILE_NAME"));
			tableLinkMap.put("HDN_ZMN_KYKS_DIS_FILE_PASS_00", zmnListRow.get("ZMN_KYKS_PASS"));
			tblTBL5RowList.add(tableLinkMap);

			//�ő�\��10��
			maxRowNum++;
			if (maxRowNum > ZMN_MAX_ROW) {
				break;
			}
		}
		tableLinkData.setWrappedData(tblTBL5RowList);
		getForm().put("TBL_TBL5", tableLinkData);
	}

	/**
	 * ��ʍ����e�[�u���i�ݕt�Ώۓy�n�j���ڂ̐ݒ���s���܂��B.
	 * @param kasTshList �ݕt�Ώۓy�n�f�[�^
	 * @throws Exception
	 *             ��O
	 */
	public void setBottomLeftTable(List<Map<String, Object>> kasTshList) throws Exception {
		//�ݕt�Ώۓy�n�e�[�u���\��
		if (kasTshList.size() > KAS_MAX_ROW * 3) {
			getForm().put("HDN_TBL_DSP_FLG_00", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_01", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_02", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_03", KAS_TBL_ON);
		} else if (kasTshList.size() > KAS_MAX_ROW * 2) {
			getForm().put("HDN_TBL_DSP_FLG_00", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_01", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_02", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_03", KAS_TBL_OFF);
		} else if (kasTshList.size() > KAS_MAX_ROW) {
			getForm().put("HDN_TBL_DSP_FLG_00", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_01", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_02", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_03", KAS_TBL_OFF);
		} else if (kasTshList.size() > 0) {
			getForm().put("HDN_TBL_DSP_FLG_00", KAS_TBL_ON);
			getForm().put("HDN_TBL_DSP_FLG_01", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_02", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_03", KAS_TBL_OFF);
		} else {
			getForm().put("HDN_TBL_DSP_FLG_00", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_01", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_02", KAS_TBL_OFF);
			getForm().put("HDN_TBL_DSP_FLG_03", KAS_TBL_OFF);
		}

		getForm().put("TBL_TBL1", getKasTshTable(kasTshList, "00", 0));
		getForm().put("TBL_TBL2", getKasTshTable(kasTshList, "01", KAS_MAX_ROW));
		getForm().put("TBL_TBL3", getKasTshTable(kasTshList, "02", KAS_MAX_ROW * 2));
		getForm().put("TBL_TBL4", getKasTshTable(kasTshList, "03", KAS_MAX_ROW * 3));

	}

	/**
	 * �ݕt�Ώۃf�[�^���e�[�u���ɐݒ肵�܂��B.
	 * @param kasTshList �ݕt�Ώۓy�n�f�[�^
	 * @param renNo �A��
	 * @param listNum �ݒ�J�n���X�g�ԍ�
	 * @return �e�[�u���f�[�^
	 * @throws Exception
	 *             ��O
	 */
	public DataModel<List<Map<String, Object>>> getKasTshTable(List<Map<String, Object>> kasTshList, String renNo, int listNum) throws Exception {

		CommonDAO dao = (CommonDAO) getDao();

		List<Map<String, Object>> tblTBLRowList = new ArrayList<Map<String, Object>>();
		DataModel<List<Map<String, Object>>> tableData = new ListDataModel<List<Map<String, Object>>>();
		int rowCount = 0;
		for (int i = listNum; i < kasTshList.size(); i++) {
			Map<String, Object> tableMap = new HashMap<String, Object>();

			tableMap.put("LBL_SYU_NO_" + renNo				, kasTshList.get(i).get("SYU_NO"));
			tableMap.put("LBL_KAST_HAI_KBN_NAME_" + renNo	, CommonModule.getKbn(dao, KBN_SBT_KAST_HANI, ((String) kasTshList.get(i).get("KAST_HAI_KBN"))));
			tblTBLRowList.add(tableMap);

			rowCount++;
			if (rowCount == KAS_MAX_ROW) {
				break;
			}
		}
		tableData.setWrappedData(tblTBLRowList);
		return tableData;
	}

	/**
	 * ��ʉE�e�[�u�����ڂ̐ݒ���s���܂��B.
	 * @param list SQL�擾���X�g
	 * @param ukeKmkList �������Ȗڃ��X�g
	 * @throws Exception
	 *             ��O
	 */
	public void setRightTable(List<Map<String, Object>> list, List<Map<String, Object>> ukeKmkList) throws Exception {

		CommonDAO dao = (CommonDAO) getDao();

		String skkKmkCd = (String) list.get(0).get("SKK_KMK_CD");

		getForm().put("LBL_KYKSH_NO_00"				, list.get(0).get("KYKSH_NO"));
		getForm().put("LBL_AITES_ADD_CD_1_00"		, list.get(0).get("KYKSH_TDFK_CD"));
		getForm().put("LBL_AITES_TDFK_NAME_01"		, list.get(0).get("KYKSH_TDFK_NAME"));
		getForm().put("LBL_AITES_ADD_CD_2_00"		, list.get(0).get("KYKSH_OOA_TSH_CD"));
		getForm().put("LBL_AITES_OOA_TSH_NAME_01"	, list.get(0).get("KYKSH_OOA_TSH_NAME"));
		getForm().put("LBL_AITES_ACM_NAME_00"		, list.get(0).get("KYKSH_ACM"));
		getForm().put("LBL_AITES_BNCH_00"			, list.get(0).get("KYKSH_CBN"));
		getForm().put("LBL_KYKSH_TEL_NO_00"			, list.get(0).get("KYKSH_TEL_NO"));
		getForm().put("LBL_KYKSH_ADD_YUB_NO_UP_3_KYKSH_ADD_YUB_NO_DWN_4_00", list.get(0).get("KYKSH_ADD_YUB_NO"));
		getForm().put("LBL_AITES_NAME_00"			, list.get(0).get("KYKSH_NAME"));
		getForm().put("LBL_SKK_KBN_NAME_00" 		, CommonModule.getKbn(dao, KBN_SBT_SKK, ((String) list.get(0).get("SKK_KBN"))));
		getForm().put("LBL_SKK_00"					, list.get(0).get("SKK"));
		getForm().put("LBL_SKK_SHR_KMK_00"			, skkKmkCd.substring(0, 3) + "-" + skkKmkCd.substring(3, 4) + "-" + skkKmkCd.substring(4, 6) + "-" + skkKmkCd.substring(6, 8) + "-" + skkKmkCd.substring(8));
		getForm().put("LBL_NYK_SKI_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_NYK_SKI, ((String) list.get(0).get("NYK_SKI"))));
		getForm().put("LBL_NYK_SBT_NAME_00"			, CommonModule.getKbn(dao, KBN_SBT_NYK_SBT, ((String) list.get(0).get("NYK_SBT"))));
		getForm().put("LBL_KNRE_CMPY_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_KNRE_CMPY, ((String) list.get(0).get("KNRE_CMPY_KBN"))));
		getForm().put("LBL_SEK_HIY_HSE_KSH_CD_00"	, list.get(0).get("SEK_HIY_HSE_KSH_CD"));
		getForm().put("LBL_SEK_HIY_HSE_KSH_NAME_01"	, list.get(0).get("SEK_HIY_HSE_KSH_NAME"));

		//�������Ȗ�
		List<Map<String, Object>> tblTBL6RowList = new ArrayList<Map<String, Object>>();
		DataModel<List<Map<String, Object>>> tableData = new ListDataModel<List<Map<String, Object>>>();

		for (Map<String, Object> ukeKmkListRow : ukeKmkList) {
			String ukeKmkCd = (String) ukeKmkListRow.get("UKE_KMK_UKE_KMK_CD");
			String hmkWbsYos = (String) ukeKmkListRow.get("UKE_KMK_HMK_WBS_YOS");
			Map<String, Object> tableMap = new HashMap<String, Object>();

			tableMap.put("LBL_HMK_KBN_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_HMK, ((String) ukeKmkListRow.get("HMK_KBN"))));
			tableMap.put("LBL_UKE_KMK_UKE_KMK_CD_00", ukeKmkCd.substring(0, 3) + "-" + ukeKmkCd.substring(3, 4) + "-" + ukeKmkCd.substring(4, 6) + "-" + ukeKmkCd.substring(6, 8) + "-" + ukeKmkCd.substring(8));
			tableMap.put("LBL_HMK_WBS_YOS_00"		, hmkWbsYos.substring(0, 3) + "-" + hmkWbsYos.substring(3, 4) + "-" + hmkWbsYos.substring(4, 6) + "-" + hmkWbsYos.substring(6, 8) + "-" + hmkWbsYos.substring(8));
			tableMap.put("LBL_HMK_WBS_NAME_00"		, ukeKmkListRow.get("HMK_WBS_NAME"));
			tableMap.put("LBL_BU_KBN_00"			, ukeKmkListRow.get("BU_KBN"));
			tableMap.put("LBL_BU_KBN_NAME_00"		, ukeKmkListRow.get("BU_KBN_NAME"));
			tableMap.put("LBL_ZEI_KBN_NAME_00"		, CommonModule.getKbn(dao, KBN_SBT_ZEI, ((String) ukeKmkListRow.get("UKE_KMK_ZEI_KBN"))));
			tableMap.put("LBL_NYK_KIN_00"			, ukeKmkListRow.get("NYK_KIN"));

			tblTBL6RowList.add(tableMap);
		}

		tableData.setWrappedData(tblTBL6RowList);
		getForm().put("TBL_TBL6", tableData);

		getForm().put("LBL_NYK_DATE_DYMT_00"		, list.get(0).get("NYK_DATE_DYMT"));
		getForm().put("LBL_KAST_KIN_DYMT_00"		, list.get(0).get("KAST_KIN_DYMT"));
		getForm().put("LBL_TSH_KKN_ST_DYMT_00"		, list.get(0).get("TSH_KKN_ST_DYMT"));
		getForm().put("LBL_TSH_KKN_EN_DYMT_00"		, list.get(0).get("TSH_KKN_EN_DYMT"));
		getForm().put("LBL_NYK_DATE_TEKIK_00"		, list.get(0).get("NYK_DATE_TEKIK"));
		getForm().put("LBL_KAST_KIN_TEKIK_00"		, list.get(0).get("KAST_KIN_TEKIK"));
		getForm().put("LBL_TSH_KKN_ST_TEKIK_00"		, list.get(0).get("TSH_KKN_ST_TEKIK"));
		getForm().put("LBL_TSH_KKN_EN_TEKIK_00"		, list.get(0).get("TSH_KKN_EN_TEKIK"));

	}

	/**
	 * �䒠�C���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter() throws Exception {
		Map<String, Object> fksd123 = new HashMap<String, Object>();
		fksd123.put("LBL_KYK_NO_00"	, getForm().get("LBL_KYK_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD123"	, fksd123);
		return getForward("/xhtml/FKSD072.xhtml");
	}

	/**
	 * �䒠����{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String print() throws Exception {
		CommonDAO dao = (CommonDAO) getDao();

		FKSR003 fksr003 = new FKSR003();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("KYK_NO_W01", getForm().get("LBL_KYK_NO_00"));
		Map<String, String> fileInfo = fksr003.makePintFile(dao, param);

		File file = new File(fileInfo.get(Constants.DOWNLOAD_PATH_KEY));
		exportFile(fileInfo.get(Constants.DOWNLOAD_NAME_KEY), file);

		return getForward("/xhtml/FKSD123.xhtml");
	}

	/**
	 * ���l����\���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter3() throws Exception {
		//���փ`�F�b�N
		if (isE0007("E0007_SEL_004")) {
			//�G���[���b�Z�[�W�o��
			setErrorMessage("E0007");
			return getForward("/xhtml/FKSD123.xhtml");
		}
		Map<String, Object> fksd123 = new HashMap<String, Object>();
		fksd123.put("LBL_KYK_NO_00"	, getForm().get("LBL_KYK_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD123"	, fksd123);
		return getForward("/xhtml/FKSD129.xhtml");
	}

	/**
	 * �⎆���\���{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String enter4() throws Exception {
		//���փ`�F�b�N
		if (isE0007("E0007_SEL_005")) {
			//�G���[���b�Z�[�W�o��
			setErrorMessage("E0007");
			return getForward("/xhtml/FKSD123.xhtml");
		}
		Map<String, Object> fksd123 = new HashMap<String, Object>();
		fksd123.put("LBL_KYK_NO_00"	, getForm().get("LBL_KYK_NO_00"));
		setSession(EcSession.FUNCTION_SCOPE	, "FKSD123"	, fksd123);
		return getForward("/xhtml/FKSD130.xhtml");
	}

	/**
	 * �Y�t���������N�������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String file_link() throws Exception {

		File file = new File((String) getSelectedRow().get("HDN_ZMN_KYKS_DIS_FILE_PASS_00"));
        exportFile((String) getSelectedRow().get("LBL_ZMN_KYKS_DIS_FILE_NAME_00"), file);

        return getForward("/xhtml/FKSD123.xhtml");
	}

    /**
     * �o�̓t�@�C���̕ۑ��ꏊ��ݒ肵�A�_�E�����[�h�p�̏����\�z���܂��B.
     * @param printName
     *             ���[��
     * @param fileOut
     *             excel�t�@�C��
     * @throws Exception
     *             ��O
     */
    private void exportFile(String printName, File fileOut) throws Exception {
        // �t�@�C���_�E�����[�h�̏����������s���B
        setSession(EcSession.PAGE_SCOPE, FrameworkConstants.REQUEST_ATTRIBUTE_FILE, fileOut.getAbsolutePath());
        setSession(EcSession.PAGE_SCOPE, FrameworkConstants.REQUEST_ATTRIBUTE_FILE_NAME, printName);
        getForm().put("HDN_DOWNLOAD_FLG_00", DOWNLOAD_FLG_ON);
    }


	/**
     * �_�E�����[�h�{�^���������̏������s���܂��B.
     * @return �t�H���[�h��
     * @throws Exception
     *             ��O
     */
    public String download() throws Exception {
        return super.print();
    }

	/**
	 * �߂�{�^���������̏������s���܂��B.
	 * @return �t�H���[�h��
	 * @throws Exception
	 *             ��O
	 */
	public String back() throws Exception {
		return getForward("/xhtml/FKSD117.xhtml");
	}


	/**
	 * E0007�̑��փ`�F�b�N���s���܂��B.
	 * @param sqlName SQL��
	 * @return ���փ`�F�b�N����
	 * @throws Exception
	 *             ��O
	 */
	public boolean isE0007(String sqlName) throws Exception {
		CommonDAO dao = (CommonDAO) getDao();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("KYK_NO_W01"	, getForm().get("LBL_KYK_NO_00"));
		List<Map<String, Object>> countList = new ArrayList<Map<String, Object>>();
		countList = dao.getQueryResult(param, sqlName, CommonDAO.CHECK_SQL);

		if (Integer.parseInt(countList.get(0).get("COUNT").toString()) == 0) {
			return true;
		}
		return false;
	}

}
