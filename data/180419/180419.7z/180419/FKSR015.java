/**
 * FKSR015.java
 * All Rights Reserved.Copyright�@2018,Energia�@Communications.Inc
 */
package jp.co.energia.batch.FKSR;

import java.io.File;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.energia.batch.common.dao.CommonDAO;
import jp.co.energia.batch.common.module.CommonModule;
import jp.co.energia.batch.constants.Constants;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * �������������B.
 * Ver.00.00.00 2018/4/17 : AIT-Myhq - Original
 */
public class FKSR015 {

    /** ���[ID�i�������������j. */
    public static final String REPORT_ID = "FKSR015";
	/** ���[���. */
	private static final String CHOHY_SBT = "15";
	/** �e���v���[�g�t�@�C����. */
	private static final String TEMPLATE_FILE_NAME = "FKSR015.jasper";
	/** NUM_FORMAT. */
	private static final String NUM_FORMAT = "###,###,###,###";
	/** DEC_FORMAT. */
	private static final String DEC_FORMAT = "###,###,###,###.##";

	/** �R���X�g���N�^. */
	public FKSR015() { };

	/**
	 * ���[�t�@�C���̍쐬���s���܂��B.
	 * @param dao DAO
	 * @throws Exception ��O
	 */
	public void makePintFile(CommonDAO dao) throws Exception {

		// ���[�쐬�����iyyyyMMddHHmmss�j�擾
		String timeStr = (new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDDHHMMSS)).format(new Date());

		// ���[�o�^�����iyyyyMMddHHmmssSSS�j�擾
		String trkTime = (new SimpleDateFormat(Constants.DATE_FMT_YYYYMMDDHHMMSSSSS)).format(new Date());

		List<Map<String, Object>> paramList = createParamList(dao);

		exportPDF(dao, timeStr, trkTime, paramList);
	}

	/**
	 * Create param list for exporting.
	 * @param dao DAO
	 * @return current page
	 * @throws Exception ��O
	 */
	private List<Map<String, Object>> createParamList(CommonDAO dao) throws Exception {
		// Param list for exporting
		List<Map<String, Object>> paramList = new ArrayList<Map<String, Object>>();

		// �w�b�_�[�����̎擾
		List<Map<String, Object>> sql01Result = dao.getQueryResult(new HashMap<String, Object>(), "FKSR015_SELECT_001");

		// Page index
		int pageIdx = 0;
		int totalPage = sql01Result.size();
		for (Map<String, Object> sql01Row : sql01Result) {
			// Page index
			pageIdx++;

			// Page map
			Map<String, Object> page = new HashMap<String, Object>();

			// ���׍s�̕ҏW
			page.putAll(getTitlePart(sql01Row, pageIdx, totalPage));

			// ���ו����̎擾
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("CHOHY_RNO_W01", sql01Row.get("CHOHY_RNO"));
			List<Map<String, Object>> sql02Result = dao.getQueryResult(param, "FKSR015_SELECT_002");

			// ���ו��̕ҏW
			page.putAll(getDetailPart(sql02Result));

			// �t�b�^�[���̕ҏW
			page.putAll(getFooterPart(sql01Row));

			// Add detail into paramlist
			paramList.add(page);
		}

		return paramList;
	}

	/**
	 *
	 * @param dao DAO
	 * @param timeStr ���[�쐬�����iyyyyMMddHHmmss�j�擾
	 * @param trkTime ���[�o�^�����iyyyyMMddHHmmssSSS�j�擾
	 * @param paramList Params of report
	 * @throws Exception ��O
	 */
	private void exportPDF(CommonDAO dao, String timeStr, String trkTime, List<Map<String, Object>> paramList)
			throws Exception {
		//�o�͐�t�H���_
		String outFolder = Constants.CHOHY_DIR_PATH + File.separator + REPORT_ID + File.separator + timeStr;

		//���[�i�[�t�H���_�����݂��Ȃ��ꍇ�쐬
		CommonModule.createFolder(outFolder);

		// �o�͐�t�@�C�����w�肷��B
		String outFile = outFolder + File.separator + getFileID(timeStr);

		// �e���v���[�g�t�@�C�������擾����B
		String templateFileName = Constants.TEMPLATE_DIR_PATH + File.separator + TEMPLATE_FILE_NAME;

		// �o�̓t�@�C��������ɍ쐬�ł��Ă��邱�ƁB
		JasperPrint jasper = JasperFillManager.fillReport(templateFileName,
				new HashMap<String, Object>(), new JRBeanCollectionDataSource(paramList));

		// ����C���[�W��PDF�t�@�C���ɏo�͂���B
		JasperExportManager.exportReportToPdfFile(jasper, outFile + ".pdf");

		//DB�o�^
		Map<String, Object> repInfo = new HashMap<String, Object>();
		repInfo.put("CHOHY_ID"		, REPORT_ID);
		repInfo.put("CHOHY_PASS"	, outFile + ".pdf");
		repInfo.put("TOK_DATE"		, trkTime);
		repInfo.put("KKSH_CD"		, "QA");
		repInfo.put("SFSK_CD"		, "QA");
		repInfo.put("CHOHY_SBT"		, CHOHY_SBT);
		repInfo.put("BATCH_ID"		, "QA");
		CommonModule.creMakeRep(dao, repInfo);
	}

	/**
	 * ���o�������擾���܂��B.
	 * @param record SQL01 record
	 * @param currPage Current page
	 * @param totalPage Total page
 	 * @return ���o����
	 */
	private Map<String, Object> getTitlePart(Map<String, Object> record, int currPage, int totalPage) {
		Map<String, Object> titlePart = new HashMap<String, Object>();

		// ���t��
		titlePart.put("FKSR015_001", record.get("SFSK_CD"));
		// ���t�於
		titlePart.put("FKSR015_002", record.get("SFSK_NAME"));
		// �䒠�Ǘ��ӏ�
		titlePart.put("FKSR015_003", record.get("DAI_KKSH_NAME"));
		// �����Ǘ��ӏ�
		titlePart.put("FKSR015_004", record.get("GNB_KKSH_NAME"));
		// ����^�C�v���
		titlePart.put("FKSR015_005", record.get("TRHK_TYP_SBT_NAME"));
		// �����Z���^�R�[�h
		titlePart.put("FKSR015_006", record.get("SEKN_GENK_CTR_NAME"));
		// ���ݔN��
		titlePart.put("FKSR018_007", CommonModule.formatJPKanjiMonth(CommonModule.cnvStr(record.get("NOW_DATE"))));
		// ���ݕ�
		titlePart.put("FKSR015_008", Integer.toString(currPage));
		// �S��
		titlePart.put("FKSR015_009", Integer.toString(totalPage));

		return titlePart;
	}

	/**
	 * ���ו����擾���܂��B.
	 * @param sql02Result ���ו���
	 * @return ���ו�
	 */
	private Map<String, Object> getDetailPart(List<Map<String, Object>> sql02Result) {
		// Detail map
		Map<String, Object> detailPart = new HashMap<String, Object>();

		// Init 0
		for (int i = 101; i <= 580; i++) {
			detailPart.put("FKSR015_" + i, "0");
		}

		// �S�؃R���N���[�g�E�ЗL
		List<Map<String, Object>> ownedConcreteBuildingInfo = new ArrayList<Map<String, Object>>();
		// �S�؃R���N���[�g�E�ЗL
		List<Map<String, Object>> ownedRengazouBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> ownedKinzokuzouBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> ownedMokuzouBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> usedConcreteBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> usedRengazouBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> usedKinzokuzouBuildingInfo = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> usedMokuzouBuildingInfo = new ArrayList<Map<String, Object>>();

		for (Map<String, Object> sql02Row : sql02Result) {
			String syuSykyKbn = CommonModule.cnvStr(sql02Row.get("SYU_SYKY_KBN"));
			String buldKozKbn = CommonModule.cnvStr(sql02Row.get("BULD_KOZ_KBN"));
			switch (syuSykyKbn) {
				case "1":
					switch (buldKozKbn) {
						case "1":
							ownedConcreteBuildingInfo.add(sql02Row);
							break;
						case "2":
							ownedRengazouBuildingInfo.add(sql02Row);
							break;
						case "3":
							ownedKinzokuzouBuildingInfo.add(sql02Row);
							break;
						case "4":
							ownedMokuzouBuildingInfo.add(sql02Row);
							break;
						default:
							break;
					}
					break;
				case "2":
					switch (buldKozKbn) {
						case "1":
							usedConcreteBuildingInfo.add(sql02Row);
							break;
						case "2":
							usedRengazouBuildingInfo.add(sql02Row);
							break;
						case "3":
							usedKinzokuzouBuildingInfo.add(sql02Row);
							break;
						case "4":
							usedMokuzouBuildingInfo.add(sql02Row);
							break;
						default:
							break;
					}
					break;
				default:
					break;
			}
		}

		// �S�؃R���N���[�g�E�����E�ЗL
		getOwnedConcreteBuildingNoInfo(detailPart, ownedConcreteBuildingInfo);
		// �S�؃R���N���[�g�E�����E�ؗp
		getUsedConcreteBuildingNoInfo(detailPart, usedConcreteBuildingInfo);

		return detailPart;
	}

//	private Map<String, Object> getConcreteBuildingAreaInfo(
//			List<Map<String, Object>> ownedConcreteBuildingInfo,
//			List<Map<String, Object>> usedConcreteBuildingInfo) {
//		editDetailCol_2_Part_1();
//		editDetailCol_2_Part_2();
//		return null;
//	}

	/**
	 * �S�؃R���N���[�g�E�����E�ЗL.
	 * @param detailInfo ���ו�
	 * @param ownedConcreteBuildingInfo �S�؃R���N���[�g�E�ЗL
	 */
	private void getOwnedConcreteBuildingNoInfo(
						Map<String, Object> detailInfo,
						List<Map<String, Object>> ownedConcreteBuildingInfo) {
		for (Map<String, Object> row : ownedConcreteBuildingInfo) {
			// ���d�敪
			String htdnKbn = CommonModule.cnvStr(row.get("HTDN_KBN"));

			// ��������
			BigDecimal valueBuldToSu = new BigDecimal(CommonModule.cnvStr(row.get("BULD_TO_SU")));
			String strBuldToSu = CommonModule.decimalFormat(valueBuldToSu, NUM_FORMAT);

			switch (htdnKbn) {
				case "01":
					// �S�؃R���N���[�g�E�����E�ЗL�E���͔��d�ݔ�
					detailInfo.put("FKSR015_101", strBuldToSu);
					break;
				case "03":
					// �S�؃R���N���[�g�E�����E�ЗL�E�D�͔��d�ݔ�
					detailInfo.put("FKSR015_102", strBuldToSu);
					break;
				case "04":
					// �S�؃R���N���[�g�E�����E�ЗL�E���q�͔��d�ݔ�
					detailInfo.put("FKSR015_103", strBuldToSu);
					break;
				case "05":
					// �S�؃R���N���[�g�E�����E�ЗL�E���R���d�ݔ�
					detailInfo.put("FKSR015_104", strBuldToSu);
					break;
				case "06":
					// �S�؃R���N���[�g�E�����E�ЗL�E���d�ݔ�
					detailInfo.put("FKSR015_105", strBuldToSu);
					break;
				case "07":
					// �S�؃R���N���[�g�E�����E�ЗL�E�ϓd�ݔ�
					detailInfo.put("FKSR015_106", strBuldToSu);
					break;
				case "08":
					// �S�؃R���N���[�g�E�����E�ЗL�E�z�d�ݔ�
					detailInfo.put("FKSR015_107", strBuldToSu);
					break;
				case "09":
					// �S�؃R���N���[�g�E�����E�ЗL�E�V�G�l�ݔ�
					detailInfo.put("FKSR015_108", strBuldToSu);
					break;
				case "10":
					// �S�؃R���N���[�g�E�����E�ЗL�E�Ɩ��ݔ�
					detailInfo.put("FKSR015_109", strBuldToSu);
					break;
				case "11":
					// �S�؃R���N���[�g�E�����E�ЗL�E�x�~�ݔ�
					detailInfo.put("FKSR015_110", strBuldToSu);
					break;
				case "12":
					// �S�؃R���N���[�g�E�����E�ЗL�E���ƊO�Œ莑�Y
					detailInfo.put("FKSR015_111", strBuldToSu);
					break;
				case "14":
					// �S�؃R���N���[�g�E�����E�ЗL�E���ю��ƌŒ莑�Y
					detailInfo.put("FKSR015_112", strBuldToSu);
					break;
				default:
					break;
			}

			// �S�؃R���N���[�g�E�����E�ЗL�E���v
			BigDecimal total = new BigDecimal(CommonModule.cnvStr(detailInfo.get("FKSR015_113")));
			detailInfo.put("FKSR015_113", CommonModule.decimalFormat(total.add(valueBuldToSu), NUM_FORMAT));
		}

		// �S�؃R���N���[�g�E�����E�ЗL�E���v
		detailInfo.put("FKSR015_113", CommonModule.decimalFormat(
				new BigDecimal(CommonModule.cnvStr(detailInfo.get("FKSR015_113"))), NUM_FORMAT));
	}

	/**
	 * �S�؃R���N���[�g�E�����E�ؗp.
	 * @param detailInfo ���ו�
	 * @param usedConcreteBuildingInfo �S�؃R���N���[�g�E�ؗp
	 */
	private void getUsedConcreteBuildingNoInfo(
						Map<String, Object> detailInfo,
						List<Map<String, Object>> usedConcreteBuildingInfo) {
	}

	/**
	 * ���o�������擾���܂��B.
	 * @param record SQL01 record
 	 * @return ���o����
	 */
	private Map<String, Object> getFooterPart(Map<String, Object> record) {
		Map<String, Object> footerPart = new HashMap<String, Object>();

		// ���t��
		footerPart.put("FKSR015_601", record.get("CMPY_NAME"));

		return footerPart;
	}

	/**
	 * �t�@�C��ID���쐬���܂��B.
	 * �t�@�C��ID = ���[ID_���t(�N���������b)
	 * @param timeStr ���[�쐬����
	 * @return �t�@�C��ID
	 */
	private String getFileID(String timeStr) {
		String fileId = REPORT_ID + "_" + timeStr;
		return fileId;
	}
}



//getConcreteBuildingAreaInfo(ownedConcreteBuildingInfo, usedConcreteBuildingInfo);
//getRengazouBuildingNoInfo(ownedRengazouBuildingInfo, usedRengazouBuildingInfo);
//getRengazouBuildingAreaInfo(ownedRengazouBuildingInfo, usedRengazouBuildingInfo);
//getKinzokuzouBuildingNoInfo(ownedKinzokuzouBuildingInfo, usedKinzokuzouBuildingInfo);
//getKinzokuzouBuildingAreaInfo(ownedKinzokuzouBuildingInfo, usedKinzokuzouBuildingInfo);
//getMokuzouBuildingNoInfo(ownedMokuzouBuildingInfo, usedMokuzouBuildingInfo);
//getMokuzouBuildingAreaInfo(ownedMokuzouBuildingInfo, usedMokuzouBuildingInfo);
//private void getUsedConcreteBuildingInfo(
//Map<String, Object> detailInfo,
//List<Map<String, Object>> usedConcreteBuildingInfo) {
//
//}
//
//private Map<String, Object> getRengazouBuildingNoInfo(
//List<Map<String, Object>> ownedRengazouBuildingInfo,
//List<Map<String, Object>> usedRengazouBuildingInfo) {
//editDetailCol_3_Part_1();
//editDetailCol_3_Part_2();
//return null;
//}
//
//private Map<String, Object> getRengazouBuildingAreaInfo(
//List<Map<String, Object>> ownedRengazouBuildingInfo,
//List<Map<String, Object>> usedRengazouBuildingInfo) {
//editDetailCol_4_Part_1();
//editDetailCol_4_Part_2();
//return null;
//}
//
//private Map<String, Object> getKinzokuzouBuildingNoInfo(
//List<Map<String, Object>> ownedKinzokuzouBuildingInfo,
//List<Map<String, Object>> usedKinzokuzouBuildingInfo) {
//editDetailCol_5_Part_1();
//editDetailCol_5_Part_2();
//return null;
//}
//
//private Map<String, Object> getKinzokuzouBuildingAreaInfo(
//List<Map<String, Object>> ownedKinzokuzouBuildingInfo,
//List<Map<String, Object>> usedKinzokuzouBuildingInfo) {
//editDetailCol_6_Part_1();
//editDetailCol_6_Part_2();
//return null;
//}
//
//private Map<String, Object> getMokuzouBuildingNoInfo(
//List<Map<String, Object>> ownedMokuzouBuildingInfo,
//List<Map<String, Object>> usedMokuzouBuildingInfo) {
//editDetailCol_9_Part_1();
//editDetailCol_9_Part_2();
//return null;
//}
//
//private Map<String, Object> getMokuzouBuildingAreaInfo(
//List<Map<String, Object>> ownedMokuzouBuildingInfo,
//List<Map<String, Object>> usedMokuzouBuildingInfo) {
//editDetailCol_10_Part_1();
//editDetailCol_10_Part_2();
//return null;
//}
//
//private void editDetailCol_2_Part_1() {
//
//}
//
//private void editDetailCol_2_Part_2() {
//
//}
//
//private void editDetailCol_3_Part_1() {
//
//}
//
//private void editDetailCol_3_Part_2() {
//
//}
//
//private void editDetailCol_4_Part_1() {
//
//}
//
//private void editDetailCol_4_Part_2() {
//
//}
//
//private void editDetailCol_5_Part_1() {
//
//}
//
//private void editDetailCol_5_Part_2() {
//
//}
//
//private void editDetailCol_6_Part_1() {
//
//}
//
//private void editDetailCol_6_Part_2() {
//
//}
//
//private void editDetailCol_9_Part_1() {
//
//}
//
//private void editDetailCol_9_Part_2() {
//
//}
//
//private void editDetailCol_10_Part_1() {
//
//}
//
//private void editDetailCol_10_Part_2() {
//
//}

//private Map<String, Object> editDetailCol_1(List<Map<String, Object>> detailList) {
//
//	Map<String, Object> detailPart = new HashMap<String, Object>();
//	detailPart.put("FKSR015_114", "123");
//	detailPart.put("FKSR015_115", "123");
//	detailPart.put("FKSR015_116", "123");
//	detailPart.put("FKSR015_117", "123");
//	detailPart.put("FKSR015_118", "123");
//	detailPart.put("FKSR015_119", "123");
//	detailPart.put("FKSR015_120", "123");
//	detailPart.put("FKSR015_121", "123");
//	detailPart.put("FKSR015_122", "123");
//	detailPart.put("FKSR015_123", "123");
//	detailPart.put("FKSR015_124", "123");
//	detailPart.put("FKSR015_125", "123");
//	detailPart.put("FKSR015_126", "123");
//	detailPart.put("FKSR015_127", "123");
//	detailPart.put("FKSR015_128", "123");
//	detailPart.put("FKSR015_129", "123");
//	detailPart.put("FKSR015_130", "123");
//	detailPart.put("FKSR015_131", "123");
//	detailPart.put("FKSR015_132", "123");
//	detailPart.put("FKSR015_133", "123");
//	detailPart.put("FKSR015_134", "123");
//	detailPart.put("FKSR015_135", "123");
//	detailPart.put("FKSR015_136", "123");
//	detailPart.put("FKSR015_137", "123");
//	detailPart.put("FKSR015_138", "123");
//	detailPart.put("FKSR015_139", "123");
//	detailPart.put("FKSR015_140", "123");
//
//	return detailPart_1_1;
//}

//		{
//			Map<String, Object> detailPart = new HashMap<String, Object>();
//			detailPart.put("FKSR015_141", "123");
//			detailPart.put("FKSR015_142", "123");
//			detailPart.put("FKSR015_143", "123");
//			detailPart.put("FKSR015_144", "123");
//			detailPart.put("FKSR015_145", "123");
//			detailPart.put("FKSR015_146", "123");
//			detailPart.put("FKSR015_147", "123");
//			detailPart.put("FKSR015_148", "123");
//			detailPart.put("FKSR015_149", "123");
//			detailPart.put("FKSR015_150", "123");
//			detailPart.put("FKSR015_151", "123");
//			detailPart.put("FKSR015_152", "123");
//			detailPart.put("FKSR015_153", "123");
//			detailPart.put("FKSR015_154", "123");
//			detailPart.put("FKSR015_155", "123");
//			detailPart.put("FKSR015_156", "123");
//			detailPart.put("FKSR015_157", "123");
//			detailPart.put("FKSR015_158", "123");
//			detailPart.put("FKSR015_159", "123");
//			detailPart.put("FKSR015_160", "123");
//			detailPart.put("FKSR015_161", "123");
//			detailPart.put("FKSR015_162", "123");
//			detailPart.put("FKSR015_163", "123");
//			detailPart.put("FKSR015_164", "123");
//			detailPart.put("FKSR015_165", "123");
//			detailPart.put("FKSR015_166", "123");
//			detailPart.put("FKSR015_167", "123");
//			detailPart.put("FKSR015_168", "123");
//			detailPart.put("FKSR015_169", "123");
//			detailPart.put("FKSR015_170", "123");
//			detailPart.put("FKSR015_171", "123");
//			detailPart.put("FKSR015_172", "123");
//			detailPart.put("FKSR015_173", "123");
//			detailPart.put("FKSR015_174", "123");
//			detailPart.put("FKSR015_175", "123");
//			detailPart.put("FKSR015_176", "123");
//			detailPart.put("FKSR015_177", "123");
//			detailPart.put("FKSR015_178", "123");
//			detailPart.put("FKSR015_179", "123");
//			detailPart.put("FKSR015_180", "123");
//			detailPart.put("FKSR015_181", "123");
//			detailPart.put("FKSR015_182", "123");
//			detailPart.put("FKSR015_183", "123");
//			detailPart.put("FKSR015_184", "123");
//			detailPart.put("FKSR015_185", "123");
//			detailPart.put("FKSR015_186", "123");
//			detailPart.put("FKSR015_187", "123");
//			detailPart.put("FKSR015_188", "123");
//			detailPart.put("FKSR015_189", "123");
//			detailPart.put("FKSR015_190", "123");
//			detailPart.put("FKSR015_191", "123");
//			detailPart.put("FKSR015_192", "123");
//			detailPart.put("FKSR015_193", "123");
//			detailPart.put("FKSR015_194", "123");
//			detailPart.put("FKSR015_195", "123");
//			detailPart.put("FKSR015_196", "123");
//			detailPart.put("FKSR015_197", "123");
//			detailPart.put("FKSR015_198", "123");
//			detailPart.put("FKSR015_199", "123");
//			detailPart.put("FKSR015_200", "123");
//			detailPart.put("FKSR015_201", "123");
//			detailPart.put("FKSR015_202", "123");
//			detailPart.put("FKSR015_203", "123");
//			detailPart.put("FKSR015_204", "123");
//			detailPart.put("FKSR015_205", "123");
//			detailPart.put("FKSR015_206", "123");
//			detailPart.put("FKSR015_207", "123");
//			detailPart.put("FKSR015_208", "123");
//			detailPart.put("FKSR015_209", "123");
//			detailPart.put("FKSR015_210", "123");
//			detailPart.put("FKSR015_211", "123");
//			detailPart.put("FKSR015_212", "123");
//			detailPart.put("FKSR015_213", "123");
//			detailPart.put("FKSR015_214", "123");
//			detailPart.put("FKSR015_215", "123");
//			detailPart.put("FKSR015_216", "123");
//			detailPart.put("FKSR015_217", "123");
//			detailPart.put("FKSR015_218", "123");
//			detailPart.put("FKSR015_219", "123");
//			detailPart.put("FKSR015_220", "123");
//			detailPart.put("FKSR015_221", "123");
//			detailPart.put("FKSR015_222", "123");
//			detailPart.put("FKSR015_223", "123");
//			detailPart.put("FKSR015_224", "123");
//			detailPart.put("FKSR015_225", "123");
//			detailPart.put("FKSR015_226", "123");
//			detailPart.put("FKSR015_227", "123");
//			detailPart.put("FKSR015_228", "123");
//			detailPart.put("FKSR015_229", "123");
//			detailPart.put("FKSR015_230", "123");
//			detailPart.put("FKSR015_231", "123");
//			detailPart.put("FKSR015_232", "123");
//			detailPart.put("FKSR015_233", "123");
//			detailPart.put("FKSR015_234", "123");
//			detailPart.put("FKSR015_235", "123");
//			detailPart.put("FKSR015_236", "123");
//			detailPart.put("FKSR015_237", "123");
//			detailPart.put("FKSR015_238", "123");
//			detailPart.put("FKSR015_239", "123");
//			detailPart.put("FKSR015_240", "123");
//			detailPart.put("FKSR015_241", "123");
//			detailPart.put("FKSR015_242", "123");
//			detailPart.put("FKSR015_243", "123");
//			detailPart.put("FKSR015_244", "123");
//			detailPart.put("FKSR015_245", "123");
//			detailPart.put("FKSR015_246", "123");
//			detailPart.put("FKSR015_247", "123");
//			detailPart.put("FKSR015_248", "123");
//			detailPart.put("FKSR015_249", "123");
//			detailPart.put("FKSR015_250", "123");
//			detailPart.put("FKSR015_251", "123");
//			detailPart.put("FKSR015_252", "123");
//			detailPart.put("FKSR015_253", "123");
//			detailPart.put("FKSR015_254", "123");
//			detailPart.put("FKSR015_255", "123");
//			detailPart.put("FKSR015_256", "123");
//			detailPart.put("FKSR015_257", "123");
//			detailPart.put("FKSR015_258", "123");
//			detailPart.put("FKSR015_259", "123");
//			detailPart.put("FKSR015_260", "123");
//			detailPart.put("FKSR015_261", "123");
//			detailPart.put("FKSR015_262", "123");
//			detailPart.put("FKSR015_263", "123");
//			detailPart.put("FKSR015_264", "123");
//			detailPart.put("FKSR015_265", "123");
//			detailPart.put("FKSR015_266", "123");
//			detailPart.put("FKSR015_267", "123");
//			detailPart.put("FKSR015_268", "123");
//			detailPart.put("FKSR015_269", "123");
//			detailPart.put("FKSR015_270", "123");
//			detailPart.put("FKSR015_271", "123");
//			detailPart.put("FKSR015_272", "123");
//			detailPart.put("FKSR015_273", "123");
//			detailPart.put("FKSR015_274", "123");
//			detailPart.put("FKSR015_275", "123");
//			detailPart.put("FKSR015_276", "123");
//			detailPart.put("FKSR015_277", "123");
//			detailPart.put("FKSR015_278", "123");
//			detailPart.put("FKSR015_279", "123");
//			detailPart.put("FKSR015_280", "123");
//			detailPart.put("FKSR015_281", "123");
//			detailPart.put("FKSR015_282", "123");
//			detailPart.put("FKSR015_283", "123");
//			detailPart.put("FKSR015_284", "123");
//			detailPart.put("FKSR015_285", "123");
//			detailPart.put("FKSR015_286", "123");
//			detailPart.put("FKSR015_287", "123");
//			detailPart.put("FKSR015_288", "123");
//			detailPart.put("FKSR015_289", "123");
//			detailPart.put("FKSR015_290", "123");
//			detailPart.put("FKSR015_291", "123");
//			detailPart.put("FKSR015_292", "123");
//			detailPart.put("FKSR015_293", "123");
//			detailPart.put("FKSR015_294", "123");
//			detailPart.put("FKSR015_295", "123");
//			detailPart.put("FKSR015_296", "123");
//			detailPart.put("FKSR015_297", "123");
//			detailPart.put("FKSR015_298", "123");
//			detailPart.put("FKSR015_299", "123");
//			detailPart.put("FKSR015_300", "123");
//			detailPart.put("FKSR015_301", "123");
//			detailPart.put("FKSR015_302", "123");
//			detailPart.put("FKSR015_303", "123");
//			detailPart.put("FKSR015_304", "123");
//			detailPart.put("FKSR015_305", "123");
//			detailPart.put("FKSR015_306", "123");
//			detailPart.put("FKSR015_307", "123");
//			detailPart.put("FKSR015_308", "123");
//			detailPart.put("FKSR015_309", "123");
//			detailPart.put("FKSR015_310", "123");
//			detailPart.put("FKSR015_311", "123");
//			detailPart.put("FKSR015_312", "123");
//			detailPart.put("FKSR015_313", "123");
//			detailPart.put("FKSR015_314", "123");
//			detailPart.put("FKSR015_315", "123");
//			detailPart.put("FKSR015_316", "123");
//			detailPart.put("FKSR015_317", "123");
//			detailPart.put("FKSR015_318", "123");
//			detailPart.put("FKSR015_319", "123");
//			detailPart.put("FKSR015_320", "123");
//			detailPart.put("FKSR015_321", "123");
//			detailPart.put("FKSR015_322", "123");
//			detailPart.put("FKSR015_323", "123");
//			detailPart.put("FKSR015_324", "123");
//			detailPart.put("FKSR015_325", "123");
//			detailPart.put("FKSR015_326", "123");
//			detailPart.put("FKSR015_327", "123");
//			detailPart.put("FKSR015_328", "123");
//			detailPart.put("FKSR015_329", "123");
//			detailPart.put("FKSR015_330", "123");
//			detailPart.put("FKSR015_331", "123");
//			detailPart.put("FKSR015_332", "123");
//			detailPart.put("FKSR015_333", "123");
//			detailPart.put("FKSR015_334", "123");
//			detailPart.put("FKSR015_335", "123");
//			detailPart.put("FKSR015_336", "123");
//			detailPart.put("FKSR015_337", "123");
//			detailPart.put("FKSR015_338", "123");
//			detailPart.put("FKSR015_339", "123");
//			detailPart.put("FKSR015_340", "123");
//			detailPart.put("FKSR015_341", "123");
//			detailPart.put("FKSR015_342", "123");
//			detailPart.put("FKSR015_343", "123");
//			detailPart.put("FKSR015_344", "123");
//			detailPart.put("FKSR015_345", "123");
//			detailPart.put("FKSR015_346", "123");
//			detailPart.put("FKSR015_347", "123");
//			detailPart.put("FKSR015_348", "123");
//			detailPart.put("FKSR015_349", "123");
//			detailPart.put("FKSR015_350", "123");
//			detailPart.put("FKSR015_351", "123");
//			detailPart.put("FKSR015_352", "123");
//			detailPart.put("FKSR015_353", "123");
//			detailPart.put("FKSR015_354", "123");
//			detailPart.put("FKSR015_355", "123");
//			detailPart.put("FKSR015_356", "123");
//			detailPart.put("FKSR015_357", "123");
//			detailPart.put("FKSR015_358", "123");
//			detailPart.put("FKSR015_359", "123");
//			detailPart.put("FKSR015_360", "123");
//			detailPart.put("FKSR015_361", "123");
//			detailPart.put("FKSR015_362", "123");
//			detailPart.put("FKSR015_363", "123");
//			detailPart.put("FKSR015_364", "123");
//			detailPart.put("FKSR015_365", "123");
//			detailPart.put("FKSR015_366", "123");
//			detailPart.put("FKSR015_367", "123");
//			detailPart.put("FKSR015_368", "123");
//			detailPart.put("FKSR015_369", "123");
//			detailPart.put("FKSR015_370", "123");
//			detailPart.put("FKSR015_371", "123");
//			detailPart.put("FKSR015_372", "123");
//			detailPart.put("FKSR015_373", "123");
//			detailPart.put("FKSR015_374", "123");
//			detailPart.put("FKSR015_375", "123");
//			detailPart.put("FKSR015_376", "123");
//			detailPart.put("FKSR015_377", "123");
//			detailPart.put("FKSR015_378", "123");
//			detailPart.put("FKSR015_379", "123");
//			detailPart.put("FKSR015_380", "123");
//			detailPart.put("FKSR015_381", "123");
//			detailPart.put("FKSR015_382", "123");
//			detailPart.put("FKSR015_383", "123");
//			detailPart.put("FKSR015_384", "123");
//			detailPart.put("FKSR015_385", "123");
//			detailPart.put("FKSR015_386", "123");
//			detailPart.put("FKSR015_387", "123");
//			detailPart.put("FKSR015_388", "123");
//			detailPart.put("FKSR015_389", "123");
//			detailPart.put("FKSR015_390", "123");
//			detailPart.put("FKSR015_391", "123");
//			detailPart.put("FKSR015_392", "123");
//			detailPart.put("FKSR015_393", "123");
//			detailPart.put("FKSR015_394", "123");
//			detailPart.put("FKSR015_395", "123");
//			detailPart.put("FKSR015_396", "123");
//			detailPart.put("FKSR015_397", "123");
//			detailPart.put("FKSR015_398", "123");
//			detailPart.put("FKSR015_399", "123");
//			detailPart.put("FKSR015_400", "123");
//			detailPart.put("FKSR015_401", "123");
//			detailPart.put("FKSR015_402", "123");
//			detailPart.put("FKSR015_403", "123");
//			detailPart.put("FKSR015_404", "123");
//			detailPart.put("FKSR015_405", "123");
//			detailPart.put("FKSR015_406", "123");
//			detailPart.put("FKSR015_407", "123");
//			detailPart.put("FKSR015_408", "123");
//			detailPart.put("FKSR015_409", "123");
//			detailPart.put("FKSR015_410", "123");
//			detailPart.put("FKSR015_411", "123");
//			detailPart.put("FKSR015_412", "123");
//			detailPart.put("FKSR015_413", "123");
//			detailPart.put("FKSR015_414", "123");
//			detailPart.put("FKSR015_415", "123");
//			detailPart.put("FKSR015_416", "123");
//			detailPart.put("FKSR015_417", "123");
//			detailPart.put("FKSR015_418", "123");
//			detailPart.put("FKSR015_419", "123");
//			detailPart.put("FKSR015_420", "123");
//			detailPart.put("FKSR015_421", "123");
//			detailPart.put("FKSR015_422", "123");
//			detailPart.put("FKSR015_423", "123");
//			detailPart.put("FKSR015_424", "123");
//			detailPart.put("FKSR015_425", "123");
//			detailPart.put("FKSR015_426", "123");
//			detailPart.put("FKSR015_427", "123");
//			detailPart.put("FKSR015_428", "123");
//			detailPart.put("FKSR015_429", "123");
//			detailPart.put("FKSR015_430", "123");
//			detailPart.put("FKSR015_431", "123");
//			detailPart.put("FKSR015_432", "123");
//			detailPart.put("FKSR015_433", "123");
//			detailPart.put("FKSR015_434", "123");
//			detailPart.put("FKSR015_435", "123");
//			detailPart.put("FKSR015_436", "123");
//			detailPart.put("FKSR015_437", "123");
//			detailPart.put("FKSR015_438", "123");
//			detailPart.put("FKSR015_439", "123");
//			detailPart.put("FKSR015_440", "123");
//			detailPart.put("FKSR015_441", "123");
//			detailPart.put("FKSR015_442", "123");
//			detailPart.put("FKSR015_443", "123");
//			detailPart.put("FKSR015_444", "123");
//			detailPart.put("FKSR015_445", "123");
//			detailPart.put("FKSR015_446", "123");
//			detailPart.put("FKSR015_447", "123");
//			detailPart.put("FKSR015_448", "123");
//			detailPart.put("FKSR015_449", "123");
//			detailPart.put("FKSR015_450", "123");
//			detailPart.put("FKSR015_451", "123");
//			detailPart.put("FKSR015_452", "123");
//			detailPart.put("FKSR015_453", "123");
//			detailPart.put("FKSR015_454", "123");
//			detailPart.put("FKSR015_455", "123");
//			detailPart.put("FKSR015_456", "123");
//			detailPart.put("FKSR015_457", "123");
//			detailPart.put("FKSR015_458", "123");
//			detailPart.put("FKSR015_459", "123");
//			detailPart.put("FKSR015_460", "123");
//			detailPart.put("FKSR015_461", "123");
//			detailPart.put("FKSR015_462", "123");
//			detailPart.put("FKSR015_463", "123");
//			detailPart.put("FKSR015_464", "123");
//			detailPart.put("FKSR015_465", "123");
//			detailPart.put("FKSR015_466", "123");
//			detailPart.put("FKSR015_467", "123");
//			detailPart.put("FKSR015_468", "123");
//			detailPart.put("FKSR015_469", "123");
//			detailPart.put("FKSR015_470", "123");
//			detailPart.put("FKSR015_471", "123");
//			detailPart.put("FKSR015_472", "123");
//			detailPart.put("FKSR015_473", "123");
//			detailPart.put("FKSR015_474", "123");
//			detailPart.put("FKSR015_475", "123");
//			detailPart.put("FKSR015_476", "123");
//			detailPart.put("FKSR015_477", "123");
//			detailPart.put("FKSR015_478", "123");
//			detailPart.put("FKSR015_479", "123");
//			detailPart.put("FKSR015_480", "123");
//			detailPart.put("FKSR015_481", "123");
//			detailPart.put("FKSR015_482", "123");
//			detailPart.put("FKSR015_483", "123");
//			detailPart.put("FKSR015_484", "123");
//			detailPart.put("FKSR015_485", "123");
//			detailPart.put("FKSR015_486", "123");
//			detailPart.put("FKSR015_487", "123");
//			detailPart.put("FKSR015_488", "123");
//			detailPart.put("FKSR015_489", "123");
//			detailPart.put("FKSR015_490", "123");
//			detailPart.put("FKSR015_491", "123");
//			detailPart.put("FKSR015_492", "123");
//			detailPart.put("FKSR015_493", "123");
//			detailPart.put("FKSR015_494", "123");
//			detailPart.put("FKSR015_495", "123");
//			detailPart.put("FKSR015_496", "123");
//			detailPart.put("FKSR015_497", "123");
//			detailPart.put("FKSR015_498", "123");
//			detailPart.put("FKSR015_499", "123");
//			detailPart.put("FKSR015_500", "123");
//			detailPart.put("FKSR015_501", "123");
//			detailPart.put("FKSR015_502", "123");
//			detailPart.put("FKSR015_503", "123");
//			detailPart.put("FKSR015_504", "123");
//			detailPart.put("FKSR015_505", "123");
//			detailPart.put("FKSR015_506", "123");
//			detailPart.put("FKSR015_507", "123");
//			detailPart.put("FKSR015_508", "123");
//			detailPart.put("FKSR015_509", "123");
//			detailPart.put("FKSR015_510", "123");
//			detailPart.put("FKSR015_511", "123");
//			detailPart.put("FKSR015_512", "123");
//			detailPart.put("FKSR015_513", "123");
//			detailPart.put("FKSR015_514", "123");
//			detailPart.put("FKSR015_515", "123");
//			detailPart.put("FKSR015_516", "123");
//			detailPart.put("FKSR015_517", "123");
//			detailPart.put("FKSR015_518", "123");
//			detailPart.put("FKSR015_519", "123");
//			detailPart.put("FKSR015_520", "123");
//			detailPart.put("FKSR015_521", "123");
//			detailPart.put("FKSR015_522", "123");
//			detailPart.put("FKSR015_523", "123");
//			detailPart.put("FKSR015_524", "123");
//			detailPart.put("FKSR015_525", "123");
//			detailPart.put("FKSR015_526", "123");
//			detailPart.put("FKSR015_527", "123");
//			detailPart.put("FKSR015_528", "123");
//			detailPart.put("FKSR015_529", "123");
//			detailPart.put("FKSR015_530", "123");
//			detailPart.put("FKSR015_531", "123");
//			detailPart.put("FKSR015_532", "123");
//			detailPart.put("FKSR015_533", "123");
//			detailPart.put("FKSR015_534", "123");
//			detailPart.put("FKSR015_535", "123");
//			detailPart.put("FKSR015_536", "123");
//			detailPart.put("FKSR015_537", "123");
//			detailPart.put("FKSR015_538", "123");
//			detailPart.put("FKSR015_539", "123");
//			detailPart.put("FKSR015_540", "123");
//			detailPart.put("FKSR015_541", "123");
//			detailPart.put("FKSR015_542", "123");
//			detailPart.put("FKSR015_543", "123");
//			detailPart.put("FKSR015_544", "123");
//			detailPart.put("FKSR015_545", "123");
//			detailPart.put("FKSR015_546", "123");
//			detailPart.put("FKSR015_547", "123");
//			detailPart.put("FKSR015_548", "123");
//			detailPart.put("FKSR015_549", "123");
//			detailPart.put("FKSR015_550", "123");
//			detailPart.put("FKSR015_551", "123");
//			detailPart.put("FKSR015_552", "123");
//			detailPart.put("FKSR015_553", "123");
//			detailPart.put("FKSR015_554", "123");
//			detailPart.put("FKSR015_555", "123");
//			detailPart.put("FKSR015_556", "123");
//			detailPart.put("FKSR015_557", "123");
//			detailPart.put("FKSR015_558", "123");
//			detailPart.put("FKSR015_559", "123");
//			detailPart.put("FKSR015_560", "123");
//			detailPart.put("FKSR015_561", "123");
//			detailPart.put("FKSR015_562", "123");
//			detailPart.put("FKSR015_563", "123");
//			detailPart.put("FKSR015_564", "123");
//			detailPart.put("FKSR015_565", "123");
//			detailPart.put("FKSR015_566", "123");
//			detailPart.put("FKSR015_567", "123");
//			detailPart.put("FKSR015_568", "123");
//			detailPart.put("FKSR015_569", "123");
//			detailPart.put("FKSR015_570", "123");
//			detailPart.put("FKSR015_571", "123");
//			detailPart.put("FKSR015_572", "123");
//			detailPart.put("FKSR015_573", "123");
//			detailPart.put("FKSR015_574", "123");
//			detailPart.put("FKSR015_575", "123");
//			detailPart.put("FKSR015_576", "123");
//			detailPart.put("FKSR015_577", "123");
//			detailPart.put("FKSR015_578", "123");
//			detailPart.put("FKSR015_579", "123");
//			detailPart.put("FKSR015_580", "123");
//		}
